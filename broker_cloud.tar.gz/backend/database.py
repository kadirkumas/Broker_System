import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'bot_data.db')


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # 1. Açık İşlemler
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS active_trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            trade_type TEXT NOT NULL,
            total_vol REAL NOT NULL,
            avg_price REAL NOT NULL,
            dca_count INTEGER DEFAULT 0,
            entry_time INTEGER NOT NULL
        )
    ''')

    # 2. İşlem Geçmişi
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS trade_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            trade_type TEXT NOT NULL,
            total_vol REAL NOT NULL,
            entry_price REAL NOT NULL,
            exit_price REAL NOT NULL,
            pnl_amount REAL NOT NULL,
            pnl_pct REAL NOT NULL,
            entry_time INTEGER NOT NULL,
            exit_time INTEGER NOT NULL
        )
    ''')

    # 3. Sinyaller
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            signal_id TEXT UNIQUE NOT NULL,
            symbol TEXT NOT NULL,
            strategy_name TEXT,
            signal TEXT NOT NULL,
            price REAL NOT NULL,
            qty REAL,
            total_usdt REAL,
            candle_time INTEGER,
            created_at INTEGER NOT NULL
        )
    ''')

    # MIGRATION: active_trades
    cols_at = [row[1] for row in cursor.execute("PRAGMA table_info(active_trades)").fetchall()]
    migrations_at = {
        "strategy_name": "ALTER TABLE active_trades ADD COLUMN strategy_name TEXT",
        "initial_price": "ALTER TABLE active_trades ADD COLUMN initial_price REAL",
        "initial_vol": "ALTER TABLE active_trades ADD COLUMN initial_vol REAL",
        "leverage": "ALTER TABLE active_trades ADD COLUMN leverage INTEGER DEFAULT 1",
        "pt_enabled": "ALTER TABLE active_trades ADD COLUMN pt_enabled INTEGER DEFAULT 0",
        "pt_percent": "ALTER TABLE active_trades ADD COLUMN pt_percent REAL DEFAULT 50",
        "pt_done": "ALTER TABLE active_trades ADD COLUMN pt_done INTEGER DEFAULT 0",
        "pt_volume": "ALTER TABLE active_trades ADD COLUMN pt_volume REAL DEFAULT 0",
        "pt_pnl": "ALTER TABLE active_trades ADD COLUMN pt_pnl REAL DEFAULT 0",
        "pt_keep_dca": "ALTER TABLE active_trades ADD COLUMN pt_keep_dca INTEGER DEFAULT 1",
        "entry_is_maker": "ALTER TABLE active_trades ADD COLUMN entry_is_maker INTEGER DEFAULT 0",
    }
    for col, sql in migrations_at.items():
        if col not in cols_at:
            try:
                cursor.execute(sql)
                print(f"[DB] active_trades + {col}")
            except Exception as e:
                print(f"[DB] Migration hatası ({col}): {e}")

    # MIGRATION: trade_history
    cols_th = [row[1] for row in cursor.execute("PRAGMA table_info(trade_history)").fetchall()]
    migrations_th = {
        "strategy_name": "ALTER TABLE trade_history ADD COLUMN strategy_name TEXT",
        "dca_count": "ALTER TABLE trade_history ADD COLUMN dca_count INTEGER DEFAULT 0",
        "close_reason": "ALTER TABLE trade_history ADD COLUMN close_reason TEXT",
        "leverage": "ALTER TABLE trade_history ADD COLUMN leverage INTEGER DEFAULT 1",
        "funding_fee": "ALTER TABLE trade_history ADD COLUMN funding_fee REAL DEFAULT 0",
        "is_partial": "ALTER TABLE trade_history ADD COLUMN is_partial INTEGER DEFAULT 0",
        "commission": "ALTER TABLE trade_history ADD COLUMN commission REAL DEFAULT 0",
    }
    for col, sql in migrations_th.items():
        if col not in cols_th:
            try:
                cursor.execute(sql)
                print(f"[DB] trade_history + {col}")
            except Exception as e:
                print(f"[DB] Migration hatası ({col}): {e}")

    # MIGRATION: signals
    cols_sig = [row[1] for row in cursor.execute("PRAGMA table_info(signals)").fetchall()]
    migrations_sig = {
        "opened_position": "ALTER TABLE signals ADD COLUMN opened_position INTEGER DEFAULT 0",
        "skip_reason": "ALTER TABLE signals ADD COLUMN skip_reason TEXT",
    }
    for col, sql in migrations_sig.items():
        if col not in cols_sig:
            try:
                cursor.execute(sql)
                print(f"[DB] signals + {col}")
            except Exception as e:
                print(f"[DB] Migration hatası ({col}): {e}")

    # ⚡ DUPLICATE PREVENTION: symbol bazlı UNIQUE index
    # Önce mevcut duplicate'leri temizle (en eskisini tut)
    try:
        cursor.execute("""
            DELETE FROM active_trades
            WHERE id NOT IN (
                SELECT MIN(id) FROM active_trades GROUP BY symbol
            )
        """)
        deleted = cursor.rowcount
        if deleted > 0:
            print(f"[DB] {deleted} duplicate aktif pozisyon temizlendi")
    except Exception as e:
        print(f"[DB] Duplicate temizleme hatası: {e}")
    
    # UNIQUE index ekle (varsa atla)
    try:
        cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_active_symbol ON active_trades(symbol)")
        print("[DB] UNIQUE index aktif: symbol")
    except Exception as e:
        print(f"[DB] UNIQUE index hatası: {e}")
    
    conn.commit()
    conn.close()


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn