// =========================================================================
// BROKER SYSTEM - V6.54 (ULTIMATE MULTI-STRATEGY DCA ENGINE + API FIX)
// =========================================================================


// =============================================================
// İŞLEM SİLME - KESİN TANIM (dosyanın en başı)
// =============================================================
window.deleteTradePermanently = function(id, event) {
    console.log('[DELETE] deleteTradePermanently cagrildi:', id);
    
    if (event) event.stopPropagation();
    
    // Confirm modal - showConfirm yoksa fallback native confirm
    const proceed = async () => {
        const doDelete = async () => {
            try {
                const res = await fetch('/api/trade/history/' + id, { method: 'DELETE' });
                const data = await res.json();
                
                if (data.status === 'success') {
                    if (window.showToast) window.showToast('✅ ' + data.symbol + ' işlemi silindi', 'success', 2000);
                    
                    window.lastHistoryHash = '';
                    window.lastDailyHash = '';
                    
                    if (window.refreshBottomPanel) window.refreshBottomPanel();
                    if (window.updateTabCounts) window.updateTabCounts();
                    
                    const activeSym = chartsData && chartsData[activeChartId] ? chartsData[activeChartId].symbol : null;
                    if (activeSym && window.showSymbolTrades) {
                        const cleanSym = activeSym.replace('.P', '');
                        setTimeout(function() { window.showSymbolTrades(cleanSym); }, 200);
                    }
                } else {
                    if (window.showToast) window.showToast('❌ Silinemedi: ' + (data.message || 'Bilinmeyen hata'), 'error');
                    else alert('Silinemedi: ' + (data.message || 'Hata'));
                }
            } catch(e) {
                console.error('[DELETE] Hata:', e);
                if (window.showToast) window.showToast('❌ Hata: ' + e.message, 'error');
                else alert('Hata: ' + e.message);
            }
        };
        
        // showConfirm varsa kullan, yoksa native confirm
        if (typeof window.showConfirm === 'function') {
            const ok = await window.showConfirm(
                '🗑️ İŞLEM SİL',
                'İşlem ID: #' + id + '\n\nBu işlem KALICI olarak silinecek!\n\nDevam edilsin mi?',
                '🗑️ SİL',
                'İPTAL',
                'danger'
            );
            if (ok) await doDelete();
        } else {
            if (confirm('İşlem #' + id + ' kalıcı olarak silinsin mi?')) {
                await doDelete();
            }
        }
    };
    
    proceed();
};

let futuresData = [], spotData = [];
let oldPrices = new Map(), fWsList = null, sWsList = null, pumpDumpMemory = new Map();

let activeTab = localStorage.getItem('cryptoActiveTab') || 'futures';
let radarModeActive = localStorage.getItem('cryptoRadarMode') === 'true';
let sortCol = 'change', sortDir = 'desc', watchlistSearchQuery = '';

let activeFuturesSymbols = new Set(), activeSpotSymbols = new Set();
let hasExchangeInfoFutures = false, hasExchangeInfoSpot = false;

let dailyOpensQueue = [], isFetchingDaily = false, attemptedOpens = new Set();
let dailyOpensStr = localStorage.getItem('cryptoDailyOpens_v10');
let dailyOpens = { date: '', futures: {}, spot: {} };
if (dailyOpensStr) { try { let p = JSON.parse(dailyOpensStr); if (p) { if (p.date) dailyOpens.date = p.date; if (p.futures) dailyOpens.futures = p.futures; if (p.spot) dailyOpens.spot = p.spot; } } catch(e) {} }

let wsWatchlistLastUpdate = Date.now();
let chartCount = parseInt(localStorage.getItem('cryptoLayoutCount')) || 1;
let activeChartId = 0, maximizedChartId = null;

let botConfig = JSON.parse(localStorage.getItem('cryptoBotConfig_v1')) || {
    active: false, selectedStrategy: 'RSI_SCALPER',
    strategies: {
        'RSI_SCALPER': { useDCA: true, baseOrder: 10, volMultiplier: 1.2, steps: "1.5, 3, 5", takeProfit: 1.5, trailing: 0.3 },
        'HULL_SRP': { useDCA: false, baseOrder: 10, volMultiplier: 1.0, steps: "2, 4, 6", takeProfit: 2.0, trailing: 0.5 },
        'GRIDBOT': { useDCA: true, baseOrder: 10, volMultiplier: 1.5, steps: "1, 2, 3", takeProfit: 1.0, trailing: 0.2 }
    },
    useDCA: true, baseOrder: 10, volMultiplier: 1.0, steps: "3, 5, 10", takeProfit: 1.5, trailing: 0.3
};

if (!botConfig.strategies) { botConfig.strategies = { 'RSI_SCALPER': { useDCA: true, baseOrder: 10, volMultiplier: 1.2, steps: "1.5, 3, 5", takeProfit: 1.5, trailing: 0.3 }, 'HULL_SRP': { useDCA: false, baseOrder: 10, volMultiplier: 1.0, steps: "2, 4, 6", takeProfit: 2.0, trailing: 0.5 }, 'GRIDBOT': { useDCA: true, baseOrder: 10, volMultiplier: 1.5, steps: "1, 2, 3", takeProfit: 1.0, trailing: 0.2 } }; }
if (!botConfig.selectedStrategy) botConfig.selectedStrategy = 'RSI_SCALPER';

window.getStrategyBotConfig = function(strategyType, params = {}) {
    let strat = (botConfig.strategies && botConfig.strategies[strategyType]) ? botConfig.strategies[strategyType] : botConfig;
    return { useDCA: params.useDCA !== undefined ? params.useDCA : (strat.useDCA !== undefined ? strat.useDCA : botConfig.useDCA), baseOrder: parseFloat(params.baseOrder || strat.baseOrder || botConfig.baseOrder) || 10, volMultiplier: parseFloat(params.volMultiplier || strat.volMultiplier || botConfig.volMultiplier) || 1.0, steps: params.steps || strat.steps || botConfig.steps || "3, 5, 10", takeProfit: parseFloat(params.takeProfit || strat.takeProfit || botConfig.takeProfit) || 1.5, trailing: parseFloat(params.trailing || strat.trailing || botConfig.trailing) || 0.3 };
};

let signalLogData = JSON.parse(localStorage.getItem('cryptoSignals_v1')) || [];
let historicalTradesMap = JSON.parse(localStorage.getItem('cryptoTradeHistory_v2')) || {};
let deletedTradesSet = new Set(JSON.parse(localStorage.getItem('cryptoDeletedTrades_v2')) || []);

let bootHistArray = Object.values(historicalTradesMap).sort((a,b) => b.exitTime - a.exitTime);
if (bootHistArray.length > 2000) { historicalTradesMap = {}; bootHistArray.slice(0, 2000).forEach(t => historicalTradesMap[t.id] = t); localStorage.setItem('cryptoTradeHistory_v2', JSON.stringify(historicalTradesMap)); }

let globalPositions = new Map();
try { let savedPos = localStorage.getItem('cryptoGlobalPos_v1'); if (savedPos) globalPositions = new Map(JSON.parse(savedPos)); } catch(e) { localStorage.removeItem('cryptoGlobalPos_v1'); }

let scanQueue = [], historySortDir = localStorage.getItem('cryptoHistorySortDir_v2') || 'desc';
let savedInterval = localStorage.getItem('cryptoInterval') || '5d', savedChartType = localStorage.getItem('cryptoChartType') || 'candles';

let defaultChartsData = [
    { id: 0, symbol: 'BTCUSDT.P', interval: savedInterval, chartType: savedChartType, chart: null, series: null, ws: null, lastClose: 0, lastCandleTime: 0, currentCandleCloseTime: 0, candleMap: new Map(), rawCandles: [], haCandles: [], crosshairActive: false, hasInitialData: false, lastWsUpdate: Date.now(), indicators: new Map(), strategyMarkers: [], tradeLabels: [], tradeLineSeriesArr: [], lastTrade: null, userTrades: { markers: [], labels: [], lines: [] } },
    { id: 1, symbol: 'ETHUSDT.P', interval: savedInterval, chartType: savedChartType, chart: null, series: null, ws: null, lastClose: 0, lastCandleTime: 0, currentCandleCloseTime: 0, candleMap: new Map(), rawCandles: [], haCandles: [], crosshairActive: false, hasInitialData: false, lastWsUpdate: Date.now(), indicators: new Map(), strategyMarkers: [], tradeLabels: [], tradeLineSeriesArr: [], lastTrade: null, userTrades: { markers: [], labels: [], lines: [] } },
    { id: 2, symbol: 'SOLUSDT.P', interval: savedInterval, chartType: savedChartType, chart: null, series: null, ws: null, lastClose: 0, lastCandleTime: 0, currentCandleCloseTime: 0, candleMap: new Map(), rawCandles: [], haCandles: [], crosshairActive: false, hasInitialData: false, lastWsUpdate: Date.now(), indicators: new Map(), strategyMarkers: [], tradeLabels: [], tradeLineSeriesArr: [], lastTrade: null, userTrades: { markers: [], labels: [], lines: [] } },
    { id: 3, symbol: 'BNBUSDT.P', interval: savedInterval, chartType: savedChartType, chart: null, series: null, ws: null, lastClose: 0, lastCandleTime: 0, currentCandleCloseTime: 0, candleMap: new Map(), rawCandles: [], haCandles: [], crosshairActive: false, hasInitialData: false, lastWsUpdate: Date.now(), indicators: new Map(), strategyMarkers: [], tradeLabels: [], tradeLineSeriesArr: [], lastTrade: null, userTrades: { markers: [], labels: [], lines: [] } }
];
let chartsData = [...defaultChartsData];

const savedCharts = localStorage.getItem('cryptoChartsData');
if (savedCharts) { try { const parsed = JSON.parse(savedCharts); parsed.forEach((c, i) => { if (chartsData[i]) { chartsData[i].symbol = c.symbol; chartsData[i].interval = savedInterval; chartsData[i].chartType = savedChartType; if (c.savedIndicators && Array.isArray(c.savedIndicators)) { c.savedIndicators.forEach(ind => { chartsData[i].indicators.set(ind.key, { type: ind.type, params: ind.params, color: ind.color, isMarker: ind.isMarker, name: ind.name, hidden: !!ind.hidden, series: null, bullSeries: null, bearSeries: null }); }); } } }); } catch(e) {} }

window.saveChartsState = function() { const stateToSave = chartsData.map(c => { let indArray = []; c.indicators.forEach((val, key) => { indArray.push({ key: key, type: val.type, params: val.params, color: val.color, isMarker: val.isMarker, name: val.name, hidden: !!val.hidden }); }); return { symbol: c.symbol, interval: c.interval, chartType: c.chartType, savedIndicators: indArray }; }); localStorage.setItem('cryptoChartsData', JSON.stringify(stateToSave)); };

const chartResizeObserver = new ResizeObserver(entries => { for (let entry of entries) { const { width, height } = entry.contentRect; if (width === 0 || height === 0) continue; const idMatch = entry.target.id.match(/tvchart-(\d+)/); if (idMatch) { const i = parseInt(idMatch[1]); if (chartsData[i] && chartsData[i].chart) { chartsData[i].chart.applyOptions({ width, height }); window.syncTradeLabels(i); } } } });

// ==============================
// 1. ZAMAN ÇEVİRİCİ VE YARDIMCILAR
// ==============================
window.getBinanceInterval = function(uiInterval) {
    if (!uiInterval) return '5m';
    const map = {
        '1d': '1m', '3d': '3m', '5d': '5m', '15d': '15m', '30d': '30m',
        '1S': '1h', '2S': '2h', '4S': '4h', '1G': '1d', '1H': '1w',
        '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m',
        '1h': '1h', '2h': '2h', '4h': '4h', '1w': '1w'
    };
    return map[uiInterval] || uiInterval;
};

window.formatDateTime = function(ts) { if (!ts) return "--"; const d = new Date(ts * 1000); return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
window.formatShortDateTime = function(ts) { if (!ts) return "--"; const d = new Date(ts * 1000); return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
window.getPrecision = function(price) { if (isNaN(price) || price === 0) return 2; const absPrice = Math.abs(price); if (absPrice < 0.00001) return 8; if (absPrice < 0.001) return 7; if (absPrice < 0.1) return 6; if (absPrice < 1) return 5; if (absPrice < 10) return 4; if (absPrice < 50) return 3; return 2; };
window.formatPrice = function(price) { if (isNaN(price)) return '0.00'; let prec = window.getPrecision(price); let parts = price.toFixed(prec).split("."); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ","); return parts.join("."); };
window.formatVolume = function(v) { if (isNaN(v)) return '0.00'; if (v >= 1e9) return (v / 1e9).toFixed(2) + 'B'; if (v >= 1e6) return (v / 1e6).toFixed(2) + 'M'; if (v >= 1e3) return (v / 1e3).toFixed(2) + 'K'; return v.toFixed(2); };

window.getIntervalSeconds = function(interval) { 
    let bTf = window.getBinanceInterval(interval);
    let val = parseInt(bTf); 
    if (bTf.endsWith('m')) return val * 60; 
    if (bTf.endsWith('h')) return val * 3600; 
    if (bTf.endsWith('d')) return val * 86400; 
    if (bTf.endsWith('w')) return val * 604800; 
    return 300; 
};

window.updateChartPrecision = function(idx, price) { if (isNaN(price)) return; let prec = window.getPrecision(price); let minM = parseFloat((1 / Math.pow(10, prec)).toFixed(prec)); chartsData[idx].series.applyOptions({ priceFormat: { type: 'price', precision: prec, minMove: minM } }); };

window.renderOHLCV = function(idx, data) {
    const el = document.getElementById(`ohlcv-${idx}`); if (!el || !data) return;
    try {
        const {o, h, l, c, v} = data; const isUp = c >= o; const cClass = isUp ? 'up' : 'down'; const sign = isUp ? '+' : ''; const diff = c - o; const pct = o > 0 ? (diff / o) * 100 : 0;
        const oStr = window.formatPrice(o); const hStr = window.formatPrice(h); const lStr = window.formatPrice(l); const cStr = window.formatPrice(c);
        let diffPrec = window.getPrecision(c); const diffStr = isNaN(diff) ? '0.00' : diff.toFixed(diffPrec); const pctStr = isNaN(pct) ? '0.00' : pct.toFixed(2); const vStr = window.formatVolume(v);
        let timerHTML = ''; let timerBadge = document.getElementById(`dyn-timer-${idx}`);
        if(timerBadge) { timerHTML = ` <span style="margin-left:15px; padding:3px 8px; background:rgba(41,98,255,0.2); color:#2962ff; border-radius:4px; font-weight:bold; font-size:12px;" id="dyn-timer-wrap-${idx}">Kapanış: <span id="dyn-timer-${idx}">${timerBadge.innerText}</span></span>`; }
        el.innerHTML = `<span class="ohlcv-label">A</span><span class="ohlcv-val ${cClass}">${oStr}</span><span class="ohlcv-label">Y</span><span class="ohlcv-val ${cClass}">${hStr}</span><span class="ohlcv-label">D</span><span class="ohlcv-val ${cClass}">${lStr}</span><span class="ohlcv-label">K</span><span class="ohlcv-val ${cClass}">${cStr}</span><span class="ohlcv-val ${cClass}" style="margin-left:4px;">${sign}${diffStr} (${sign}${pctStr}%)</span><span class="ohlcv-label" style="margin-left:4px;">Hacim</span><span class="ohlcv-val ${cClass}">${vStr}</span>${timerHTML}`;
    } catch(e) {}
};

// ==============================
// 2. SAYFALAMA VE PANELLER (PAGINATION)
// ==============================
window.posPage = 1; window.histPage = 1; window.dailyPage = 1;
window.ROWS_PER_PAGE = 50;

window.changePage = function(tab, dir) {
    if(tab === 'positions') { window.posPage += dir; window.renderBottomTrades(); }
    if(tab === 'history') { window.histPage += dir; window.renderHistoricalTrades(); }
    if(tab === 'daily') { window.dailyPage += dir; window.renderDailyTrades(); }
};

window.getPaginationHTML = function(tab, currentPage, totalRows) {
    let totalPages = Math.ceil(totalRows / window.ROWS_PER_PAGE) || 1;
    if (totalPages <= 1) return ''; 
    if (currentPage > totalPages) currentPage = totalPages;
    if (currentPage < 1) currentPage = 1;
    
    let prevDisabled = currentPage === 1 ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : `onclick="window.changePage('${tab}', -1)" style="cursor:pointer; color:#2962ff;"`;
    let nextDisabled = currentPage === totalPages ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : `onclick="window.changePage('${tab}', 1)" style="cursor:pointer; color:#2962ff;"`;
    
    return `
        <tr class="pagination-row" style="background: transparent;">
            <td colspan="10" style="text-align: center; padding: 15px; border:none;">
                <div style="display:inline-flex; align-items:center; gap:20px; background:#1e222d; padding:8px 20px; border-radius:6px; border:1px solid #2b3139;">
                    <span ${prevDisabled}>◀ Önceki</span>
                    <span style="color:#EAECEF; font-weight:bold;">Sayfa ${currentPage} / ${totalPages}</span>
                    <span ${nextDisabled}>Sonraki ▶</span>
                </div>
            </td>
        </tr>
    `;
};

window._lastTabCountsFetch = 0;
window.updateTabCounts = async function() {
    const now = Date.now();
    if (now - window._lastTabCountsFetch < 3000) return;
    window._lastTabCountsFetch = now;
    
    try {
        const res = await fetch('/api/stats/signals');
        const stats = await res.json();
        
        const histTab = document.getElementById('tab-history');
        if (histTab) histTab.innerText = `İşlem Geçmişi(${stats.closed_positions})`;
        
        const posTab = document.getElementById('tab-positions');
        if (posTab) posTab.innerText = `Pozisyonlar(${stats.active_positions})`;
        
        // Günlük için ayrı endpoint
        const dailyRes = await fetch('/api/stats/daily?days=1');
        const dailyData = await dailyRes.json();
        
        // ⚡ SADECE bugünün satırını al (TR saati)
        let todayCount = 0, todayPnl = 0;
        if (Array.isArray(dailyData) && dailyData.length > 0) {
            // TR saatine göre bugünün tarihi (YYYY-MM-DD)
            const _now = new Date();
            const _trNow = new Date(_now.getTime() + (3 * 60 * 60 * 1000));
            const todayKey = _trNow.getUTCFullYear() + '-' +
                             String(_trNow.getUTCMonth() + 1).padStart(2, '0') + '-' +
                             String(_trNow.getUTCDate()).padStart(2, '0');
            
            const todayRow = dailyData.find(r => r.date === todayKey);
            if (todayRow) {
                todayCount = todayRow.trades || 0;
                todayPnl = todayRow.net_pnl || 0;
            }
            // Bugün hiç işlem yoksa 0'da kalır (dünün değeri gösterilmez)
        }
        
        const dailyTab = document.getElementById('tab-daily');
        if (dailyTab) dailyTab.innerText = `Günlük İşlemler(${todayCount})`;
        
        // ⚡ "Bugün" kutucuğunu her zaman güncelle
        const pnlEl = document.getElementById('daily-total-pnl');
        if (pnlEl) {
            const sign = todayPnl >= 0 ? '+' : '';
            pnlEl.innerText = `${sign}${todayPnl.toFixed(2)}$`;
            pnlEl.style.color = todayPnl >= 0 ? '#0ECB81' : '#F6465D';
        }
        
    } catch(e) {
        console.error('Tab counts error:', e);
    }
};

window.clearTradeLabels = function(idx) { let container = document.getElementById(`labels-container-${idx}`); if (container) container.innerHTML = ''; if (chartsData[idx]) chartsData[idx].tradeLabels = []; };
window.syncTradeLabels = function(idx) {
    let cObj = chartsData[idx]; if (!cObj || !cObj.tradeLabels) return;
    let container = document.getElementById(`labels-container-${idx}`); if (!container) return;
    const userLabels = (cObj.userTrades && cObj.userTrades.labels) ? cObj.userTrades.labels : [];
    const allLabels = cObj.tradeLabels.concat(userLabels);
    if (container.children.length !== allLabels.length * 2) { container.innerHTML = ''; allLabels.forEach(lbl => { lbl.el = null; lbl.lineEl = null; }); }
    allLabels.forEach((lbl) => {
        if (!lbl.el) { let div = document.createElement('div'); div.className = `trade-label ${lbl.colorClass}`; div.innerHTML = lbl.text; container.appendChild(div); lbl.el = div; let line = document.createElement('div'); line.className = `trade-line ${lbl.colorClass}`; container.appendChild(line); lbl.lineEl = line; }
        let x = cObj.chart.timeScale().timeToCoordinate(lbl.time); let yText = cObj.series.priceToCoordinate(lbl.price); let yLine = cObj.series.priceToCoordinate(lbl.linePrice);
        if (x === null || yText === null || yLine === null) { lbl.el.style.display = 'none'; lbl.lineEl.style.display = 'none'; return; }
        lbl.el.style.display = 'block'; lbl.lineEl.style.display = 'block';
        let w = lbl.el.offsetWidth, h = lbl.el.offsetHeight, finalX = x - (w / 2), finalY;
        if (lbl.position === 'aboveBar') { finalY = yText - h - 30; lbl.lineEl.style.left = (x - 15) + 'px'; lbl.lineEl.style.top = (yLine - 1) + 'px'; } 
        else if (lbl.position === 'belowBar') { finalY = yText + 30; lbl.lineEl.style.left = (x - 15) + 'px'; lbl.lineEl.style.top = (yLine - 1) + 'px'; } 
        else if (lbl.position === 'onLine') { finalY = yText - h - 4; finalX = x + 8; lbl.lineEl.style.display = 'none'; }
        lbl.el.style.left = finalX + 'px'; lbl.el.style.top = finalY + 'px';
    });
};

window.BotUI = { clearAll: function(idx) { let cObj = chartsData[idx]; if (!cObj) return; cObj.strategyMarkers = []; window.clearTradeLabels(idx); if (cObj.series) cObj.series.setMarkers([]); } };
window.toggleBottomTradePanel = function() { const panel = document.getElementById('bottom-trade-panel'); const btn = document.getElementById('btp-toggle-btn'); if (panel.classList.contains('collapsed')) { panel.classList.remove('collapsed'); if (btn) btn.innerHTML = '▼ Gizle'; } else { panel.classList.add('collapsed'); if (btn) btn.innerHTML = '▲ Göster'; } };

window.switchBtpTab = function(target) {
    document.getElementById('tab-positions').classList.remove('active'); document.getElementById('tab-history').classList.remove('active'); document.getElementById('tab-daily').classList.remove('active');
    document.getElementById(`tab-${target}`).classList.add('active');
    document.getElementById('table-positions').style.display = target === 'positions' ? '' : 'none'; document.getElementById('table-history').style.display = target === 'history' ? '' : 'none'; document.getElementById('table-daily').style.display = target === 'daily' ? '' : 'none';
    document.getElementById('daily-pnl-header').style.display = 'inline-block';
    window.refreshBottomPanel();
};

window.toggleHistorySort = function() { historySortDir = historySortDir === 'desc' ? 'asc' : 'desc'; localStorage.setItem('cryptoHistorySortDir_v2', historySortDir); window.lastHistoryHash = ""; window.histPage = 1; window.renderHistoricalTrades(); };

window.syncHistoricalTrades = function(newTradesArray) {
    let updated = false;
    newTradesArray.forEach(t => { if (!deletedTradesSet.has(t.id) && !historicalTradesMap[t.id]) { historicalTradesMap[t.id] = t; updated = true; } });
    if (updated) {
        let arr = Object.values(historicalTradesMap).sort((a,b) => b.exitTime - a.exitTime);
        if (arr.length > 2000) { historicalTradesMap = {}; arr.slice(0, 2000).forEach(t => historicalTradesMap[t.id] = t); }
        localStorage.setItem('cryptoTradeHistory_v2', JSON.stringify(historicalTradesMap));
        window.lastHistoryHash = ""; window.lastDailyHash = ""; window.updateTabCounts();
    }
};

window.deleteHistoricalTrade = function(id, event) {
    if (event) event.stopPropagation();
    if (historicalTradesMap[id]) { delete historicalTradesMap[id]; deletedTradesSet.add(id); localStorage.setItem('cryptoTradeHistory_v2', JSON.stringify(historicalTradesMap)); localStorage.setItem('cryptoDeletedTrades_v2', JSON.stringify(Array.from(deletedTradesSet))); window.lastHistoryHash = ""; window.lastDailyHash = ""; window.refreshBottomPanel(); window.updateTabCounts(); }
};

window.refreshBottomPanel = function() {
    window.updateTabCounts();
    if (document.getElementById('tab-positions') && document.getElementById('tab-positions').classList.contains('active')) window.renderBottomTrades();
    if (document.getElementById('tab-history') && document.getElementById('tab-history').classList.contains('active')) window.renderHistoricalTrades();
    if (document.getElementById('tab-daily') && document.getElementById('tab-daily').classList.contains('active')) window.renderDailyTrades();
};

window.lastHistoryHash = ""; window.lastDailyHash = ""; window.lastPosHash = "";

document.addEventListener('DOMContentLoaded', () => {
    let sInput = document.getElementById('btp-search-input');
    if(sInput) sInput.addEventListener('input', () => { window.posPage = 1; window.histPage = 1; window.dailyPage = 1; window.refreshBottomPanel(); });
});

window.renderHistoricalTrades = async function() {
    const tbody = document.getElementById('btp-tbody-history'); 
    const iconEl = document.getElementById('hist-sort-icon'); 
    if (!tbody) return;
    
    const searchQ = document.getElementById('btp-search-input') ? document.getElementById('btp-search-input').value.toUpperCase() : '';
    const activeSymbol = chartsData[activeChartId] ? chartsData[activeChartId].symbol : null;
    
    try {
        const res = await fetch('/api/trade/history?limit=1000');
        let trades = await res.json();
        
        if (!Array.isArray(trades)) trades = [];
        if (searchQ) trades = trades.filter(t => t.symbol.toUpperCase().includes(searchQ));
        
        // Sıralama
        trades.sort((a, b) => historySortDir === 'asc' ? a.exit_time - b.exit_time : b.exit_time - a.exit_time);
        if (iconEl) iconEl.innerText = historySortDir === 'desc' ? '↓' : '↑';
        
        const totalRows = trades.length;
        if (totalRows === 0) {
            tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; color:#848e9c; padding:40px; border-bottom:none;">Geçmiş işlem bulunmuyor.</td></tr>`;
            return;
        }
        
        const paginatedArray = trades.slice((window.histPage - 1) * window.ROWS_PER_PAGE, window.histPage * window.ROWS_PER_PAGE);
        
        let html = '';
        paginatedArray.forEach(t => {
            const isLong = t.trade_type === 'BUY';
            const tagClass = isLong ? 'pos-long' : 'pos-short';
            const tagText = isLong ? '▲ LONG' : '▼ SHORT';
            const pnlColor = t.pnl_amount >= 0 ? '#0ECB81' : '#F6465D';
            const sign = t.pnl_amount >= 0 ? '+' : '';
            const comm = (t.commission !== undefined && t.commission !== null && t.commission > 0)
                ? t.commission
                : (t.total_vol * getDisplayCommission(t.symbol));
            
            const diffSec = Math.max(0, t.exit_time - t.entry_time);
            const d = Math.floor(diffSec / 86400), h = Math.floor((diffSec % 86400) / 3600), m = Math.floor((diffSec % 3600) / 60);
            const timeStr = `${d > 0 ? d + "g " : ""}${h > 0 ? h + "s " : ""}${m}dk`;
            
            // ⚡ Kapanış sebebi kısa etiketi
            let reasonShort = '-';
            let reasonFull = t.close_reason || 'Bilinmiyor';
            if (reasonFull.includes('PARTIAL')) reasonShort = 'PT';
            else if (reasonFull.includes('TRAILING')) reasonShort = 'T';
            else if (reasonFull.includes('STOP')) reasonShort = 'SL';
            else if (reasonFull.includes('TAKE')) reasonShort = 'TP';
            
            // ⚡ DCA rozeti
            const volCell = t.dca_count > 0
                ? `<span style="display:inline-flex; align-items:center; justify-content:flex-end; gap:6px;"><span>${t.total_vol.toFixed(2)} USDT</span><span style="font-size:10px; color:#fcd535; font-weight:600; padding:1px 5px; background:rgba(252,213,53,0.12); border-radius:3px; white-space:nowrap;">DCA:${t.dca_count}</span></span>`
                : `${t.total_vol.toFixed(2)} USDT`;
            
            const isActiveRow = ((t.symbol + '.P') === activeSymbol) ? 'active-coin-row' : '';
            const isPartialRow = t.is_partial == 1;
            const delCellHTML = isPartialRow
                ? '<span title="Kısmi TP kapanışı - ana işleme bağlıdır" style="font-size:11px; color:#5d6471; cursor:help;">🔗</span>'
                : `<span class="btn-del-trade" onclick="window.deleteTradePermanently(${t.id}, event)" title="Bu işlemi kalıcı sil">✖</span>`;
            
            html += `<tr class="${isActiveRow}">
                <td class="center">
                    ${delCellHTML}
                    <span title="${reasonFull}" style="font-size:10px; padding:2px 5px; background:rgba(252,213,53,0.1); color:#fcd535; border-radius:3px; cursor:help; margin-left:4px;">${reasonShort}</span>
                </td>
                <td class="left" style="font-weight:600; cursor:pointer; color:#79a0ff;" onclick="window.jumpToSymbolWithTrades('${t.symbol}.P')">${t.symbol}</td>
                <td class="left ${tagClass}">${tagText}</td>
                <td class="right">${volCell}</td>
                <td class="right" style="color:#848e9c;">${window.formatPrice(t.initial_price || t.entry_price)}</td>
                <td class="right" style="color:#fcd535; font-weight:600;">${window.formatPrice(t.entry_price)}</td>
                <td class="right">${window.formatPrice(t.exit_price)}</td>
                <td class="right" style="color:${pnlColor}; font-weight:bold;">${sign}${t.pnl_pct.toFixed(2)}% (${sign}${t.pnl_amount.toFixed(2)}$)</td>
                <td class="right" style="color:#848e9c;">-${comm.toFixed(4)}$</td>
                <td class="right" style="color:#EAECEF; font-size:11px;">${window.formatShortDateTime(t.entry_time)} - ${window.formatShortDateTime(t.exit_time)}</td>
                <td class="right" style="color:#848e9c;">${timeStr}</td>
            </tr>`;
        });
        html += window.getPaginationHTML('history', window.histPage, totalRows);
        tbody.innerHTML = html;
    } catch(e) {
        console.error('İşlem geçmişi yüklenemedi:', e);
        tbody.innerHTML = `<tr><td colspan="11" style="text-align:center; color:#f23645; padding:40px; border-bottom:none;">Backend bağlantı hatası: ${e.message}</td></tr>`;
    }
};

// =============================================================
// GÜNLÜK İŞLEM SIRALAMA
// =============================================================
window.dailySortCol = 'exitTime';
window.dailySortDir = 'desc';

window.toggleDailySort = function(col) {
    if (window.dailySortCol === col) {
        window.dailySortDir = window.dailySortDir === 'desc' ? 'asc' : 'desc';
    } else {
        window.dailySortCol = col;
        window.dailySortDir = 'desc';
    }
    window.updateDailySortIcons();
    window.renderDailyTrades();
};

window.updateDailySortIcons = function() {
    const cols = ['symbol', 'type', 'totalVol', 'entryPrice', 'exitPrice', 'pnl', 'exitTime'];
    cols.forEach(c => {
        const el = document.getElementById(`dsort-${c}`);
        if (el) {
            el.innerText = (c === window.dailySortCol)
                ? (window.dailySortDir === 'desc' ? '↓' : '↑')
                : '';
        }
        const th = el ? el.closest('th') : null;
        if (th) {
            if (c === window.dailySortCol) th.classList.add('active');
            else th.classList.remove('active');
        }
    });
};

// =============================================================
// GÜNLÜK İŞLEMLER RENDER
// =============================================================
window.renderDailyTrades = async function() {
    const tbody = document.getElementById('btp-tbody-daily');
    const pnlEl = document.getElementById('daily-total-pnl');
    if (!tbody || !pnlEl) return;

    const searchQ = document.getElementById('btp-search-input') ? document.getElementById('btp-search-input').value.toUpperCase() : '';
    const activeSymbol = chartsData[activeChartId] ? chartsData[activeChartId].symbol : null;

    try {
        const res = await fetch('/api/trade/history?limit=1000');
        let trades = await res.json();
        if (!Array.isArray(trades)) trades = [];

        const todayStr = new Date().toDateString();
        let dailyTrades = trades.filter(t => new Date(t.exit_time * 1000).toDateString() === todayStr);

        if (searchQ) dailyTrades = dailyTrades.filter(t => t.symbol.toUpperCase().includes(searchQ));

        const col = window.dailySortCol;
        const dir = window.dailySortDir === 'asc' ? 1 : -1;
        dailyTrades.sort((a, b) => {
            let va, vb;
            switch (col) {
                case 'symbol':     va = a.symbol; vb = b.symbol; break;
                case 'type':       va = a.trade_type; vb = b.trade_type; break;
                case 'totalVol':   va = a.total_vol; vb = b.total_vol; break;
                case 'entryPrice': va = a.entry_price; vb = b.entry_price; break;
                case 'exitPrice':  va = a.exit_price; vb = b.exit_price; break;
                case 'pnl':        va = a.pnl_amount; vb = b.pnl_amount; break;
                case 'exitTime':   va = a.exit_time; vb = b.exit_time; break;
                default:           va = a.exit_time; vb = b.exit_time;
            }
            if (typeof va === 'string') return va.localeCompare(vb) * dir;
            return (va - vb) * dir;
        });

        let totalPnl = 0;
        dailyTrades.forEach(t => totalPnl += t.pnl_amount);
        const totalSign = totalPnl >= 0 ? '+' : '';
        pnlEl.innerText = `${totalSign}${totalPnl.toFixed(2)}$`;
        pnlEl.style.color = totalPnl >= 0 ? '#0ECB81' : '#F6465D';

        if (window.updateDailySortIcons) window.updateDailySortIcons();

        if (dailyTrades.length === 0) {
            tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; color:#848e9c; padding:40px; border-bottom:none;">Bugün kapalı işlem bulunmuyor.</td></tr>`;
            return;
        }

        let html = '';
        dailyTrades.forEach(t => {
            const isActiveRow = ((t.symbol + '.P') === activeSymbol) ? 'active-coin-row' : '';
            const isLong = t.trade_type === 'BUY';
            const tagClass = isLong ? 'pos-long' : 'pos-short';
            const tagText = isLong ? '▲ LONG' : '▼ SHORT';
            const pnlColor = t.pnl_amount >= 0 ? '#0ECB81' : '#F6465D';
            const sign = t.pnl_amount >= 0 ? '+' : '';
            // ⚡ Komisyon: DB'de varsa onu kullan, yoksa fallback tahmin
            const comm = (t.commission !== undefined && t.commission !== null && t.commission > 0)
                ? t.commission
                : (t.total_vol * getDisplayCommission(t.symbol));
            const diffSec = Math.max(0, t.exit_time - t.entry_time);
            const d = Math.floor(diffSec / 86400), h = Math.floor((diffSec % 86400) / 3600), m = Math.floor((diffSec % 3600) / 60);
            const timeStr = `${d > 0 ? d + "g " : ""}${h > 0 ? h + "s " : ""}${m}dk`;
            const volCell = t.dca_count > 0
                ? `<span style="display:inline-flex; align-items:center; justify-content:flex-end; gap:6px;"><span>${t.total_vol.toFixed(2)} USDT</span><span style="font-size:10px; color:#fcd535; font-weight:600; padding:1px 5px; background:rgba(252,213,53,0.12); border-radius:3px; white-space:nowrap;">DCA:${t.dca_count}</span></span>`
                : `${t.total_vol.toFixed(2)} USDT`;

            html += `<tr class="${isActiveRow}">
                <td class="center">${(t.is_partial == 1) ? '<span title="Kısmi TP kapanışı - ana işleme bağlıdır" style="font-size:11px; color:#5d6471; cursor:help;">🔗</span>' : `<span class="btn-del-trade" onclick="window.deleteTradePermanently(${t.id}, event)" title="Sil">✖</span>`}</td>
                <td class="left" style="font-weight:600; cursor:pointer; color:#79a0ff;" onclick="window.changeSymbol('${t.symbol}.P')">${t.symbol}</td>
                <td class="left ${tagClass}">${tagText}</td>
                <td class="right">${volCell}</td>
                <td class="right" style="color:#848e9c;">${window.formatPrice(t.initial_price || t.entry_price)}</td>
                <td class="right" style="color:#fcd535; font-weight:600;">${window.formatPrice(t.entry_price)}</td>
                <td class="right">${window.formatPrice(t.exit_price)}</td>
                <td class="right" style="color:${pnlColor}; font-weight:bold;">${sign}${t.pnl_pct.toFixed(2)}% (${sign}${t.pnl_amount.toFixed(2)}$)</td>
                <td class="right" style="color:#848e9c;">-${comm.toFixed(4)}$</td>
                <td class="right" style="color:#EAECEF; font-size:11px;">${window.formatShortDateTime(t.entry_time)} - ${window.formatShortDateTime(t.exit_time)}</td>
                <td class="right" style="color:#848e9c;">${timeStr}</td>
            </tr>`;
        });
        tbody.innerHTML = html;
    } catch(e) {
        console.error('Günlük işlemler yüklenemedi:', e);
    }
};


// =============================================================
// POZİSYON SIRALAMA
// =============================================================
window.positionsSortCol = 'entryTime';   // Varsayılan sütun
window.positionsSortDir = 'desc';        // Varsayılan yön (büyükten küçüğe)

window.togglePosSort = function(col) {
    if (window.positionsSortCol === col) {
        // Aynı sütuna tıklandı → yön değiştir
        window.positionsSortDir = window.positionsSortDir === 'desc' ? 'asc' : 'desc';
    } else {
        // Yeni sütun → varsayılan desc
        window.positionsSortCol = col;
        window.positionsSortDir = 'desc';
    }
    window.updatePosSortIcons();
    window.renderBottomTrades();
};

window.updatePosSortIcons = function() {
    const cols = ['symbol', 'type', 'totalVol', 'avgPrice', 'currentPrice', 'pnl', 'entryTime'];
    cols.forEach(c => {
        const el = document.getElementById(`psort-${c}`);
        if (el) {
            el.innerText = (c === window.positionsSortCol) 
                ? (window.positionsSortDir === 'desc' ? '↓' : '↑') 
                : '';
        }
        // Sütun başlığının active sınıfını güncelle
        const th = el ? el.closest('th') : null;
        if (th) {
            if (c === window.positionsSortCol) th.classList.add('active');
            else th.classList.remove('active');
        }
    });
};

// =============================================================
// POZİSYON TABLOSU RENDER
// =============================================================
window.renderBottomTrades = async function() {
    const tbody = document.getElementById('btp-tbody-positions'); 
    if (!tbody) return;
    
    const hideOtherCheckbox = document.querySelector('.btp-hide-other input');
    const showOnlyActive = hideOtherCheckbox ? hideOtherCheckbox.checked : false;
    const activeSymbol = chartsData[activeChartId] ? chartsData[activeChartId].symbol : null;
    const searchQ = document.getElementById('btp-search-input') ? document.getElementById('btp-search-input').value.toUpperCase() : '';
    
    try {
        const res = await fetch('/api/trade/active');
        const trades = await res.json();
        
        const priceMap = {};
        futuresData.forEach(item => { priceMap[item.symbol] = item.lastPrice; });
        spotData.forEach(item => { priceMap[item.symbol] = item.lastPrice; });
        
        let posArray = [];
        trades.forEach(t => {
            const symbol = t.symbol;
            const displaySymbol = symbol + '.P';
            
            if (showOnlyActive && displaySymbol !== activeSymbol) return;
            if (searchQ && !symbol.toUpperCase().includes(searchQ)) return;
            
            let currentPrice = priceMap[symbol] || t.avg_price;
            
            const ratio = currentPrice / t.avg_price;
            let priceValid = (ratio >= 0.75 && ratio <= 1.35);
            
            const timeDiff = Math.floor(Date.now() / 1000) - t.entry_time;
            if (priceValid && timeDiff < 300) {
                const quickPnl = Math.abs((ratio - 1) * 100);
                if (quickPnl > 15) priceValid = false;
            }
            
            if (!priceValid) currentPrice = t.avg_price;
            
            const pnlPct = priceValid ? (((currentPrice - t.avg_price) / t.avg_price) * 100 * (t.trade_type === 'BUY' ? 1 : -1)) : 0;
            const netPnl = (t.total_vol * (pnlPct / 100)) - (t.total_vol * 0.0008);  // taker x2 (giris+cikis)
            
            posArray.push({
                priceValid: priceValid,
                symbol: symbol,
                displaySymbol: displaySymbol,
                type: t.trade_type === 'BUY' ? 'LONG' : 'SHORT',
                typeRaw: t.trade_type,
                totalVol: t.total_vol,
                avgPrice: t.avg_price,
                entryTime: t.entry_time,
                dcaCount: t.dca_count || 0,
                strategyName: t.strategy_name || 'UNKNOWN',
                leverage: t.leverage || 1,
                currentPrice: currentPrice,
                pnl: netPnl,
                pnlPct: pnlPct,
                ptEnabled: t.pt_enabled || 0,
                ptDone: t.pt_done || 0,
                ptPercent: t.pt_percent || 50,
            });
        });
        
        const col = window.positionsSortCol;
        const dir = window.positionsSortDir === 'asc' ? 1 : -1;
        
        posArray.sort((a, b) => {
            let valA, valB;
            switch (col) {
                case 'symbol':       valA = a.symbol; valB = b.symbol; break;
                case 'type':         valA = a.type; valB = b.type; break;
                case 'totalVol':     valA = a.totalVol; valB = b.totalVol; break;
                case 'avgPrice':     valA = a.avgPrice; valB = b.avgPrice; break;
                case 'currentPrice': valA = a.currentPrice; valB = b.currentPrice; break;
                case 'pnl':          valA = a.pnl; valB = b.pnl; break;
                case 'entryTime':    valA = a.entryTime; valB = b.entryTime; break;
                default:             valA = a.entryTime; valB = b.entryTime;
            }
            if (typeof valA === 'string') return valA.localeCompare(valB) * dir;
            return (valA - valB) * dir;
        });
        
        let totalCurrentVol = 0, totalMargin = 0, grossProfit = 0, grossLoss = 0;
        let activeCount = posArray.length;
        
        posArray.forEach(p => {
            totalCurrentVol += p.totalVol;
            const lev = p.leverage || 1;
            totalMargin += p.totalVol / lev;  // ⚡ Marjin hesabı
            if (p.pnl > 0) grossProfit += p.pnl; else grossLoss += p.pnl;
        });
        
        let countEl = document.getElementById('btp-count'); 
        if (countEl) countEl.innerText = activeCount;
        let thVol = document.getElementById('pos-total-vol'); 
        if (thVol) thVol.innerText = totalCurrentVol.toFixed(2) + ' USDT';
        
        // ⚡ Toplam marjin gostergeci
        let thMargin = document.getElementById('pos-total-margin');
        if (thMargin) thMargin.innerText = totalMargin.toFixed(2) + ' USDT';
        let thGrossProfit = document.getElementById('pos-gross-profit'); 
        if (thGrossProfit) thGrossProfit.innerText = '+' + grossProfit.toFixed(2) + '$';
        let thGrossLoss = document.getElementById('pos-gross-loss'); 
        if (thGrossLoss) thGrossLoss.innerText = grossLoss.toFixed(2) + '$';
        
        if (window.updatePosSortIcons) window.updatePosSortIcons();
        
        if (activeCount === 0) {
            tbody.innerHTML = `<tr><td colspan="11" style="text-align:center; color:#848e9c; padding:40px; border-bottom:none;">Açık işlem bulunmuyor.</td></tr>`;
            return;
        }
        
        let html = '';
        posArray.forEach(p => {
            const isActiveRow = (p.displaySymbol === activeSymbol) ? 'active-coin-row' : '';
            
            // ⚡ LIQ fiyatı hesabı (kaldıraç bazlı, yaklaşık)
            const _lev = p.leverage || 1;
            const _MAINT = 0.005;  // %0.5 maintenance margin (yaklaşık)
            let liqPrice = 0;
            if (_lev > 1 && p.avgPrice > 0) {
                if (p.type === 'LONG') {
                    liqPrice = p.avgPrice * (1 - 1/_lev + _MAINT);
                } else {
                    liqPrice = p.avgPrice * (1 + 1/_lev - _MAINT);
                }
                if (liqPrice <= 0) liqPrice = 0;
            }
            
            const diffSec = Math.max(0, Math.floor(Date.now() / 1000) - p.entryTime);
            const d = Math.floor(diffSec / 86400), h = Math.floor((diffSec % 86400) / 3600), m = Math.floor((diffSec % 3600) / 60);
            const timeStr = `${d > 0 ? d + "g " : ""}${h > 0 ? h + "s " : ""}${m}dk`;
            const pnlColor = p.pnl >= 0 ? '#0ECB81' : '#F6465D';
            const sign = p.pnl >= 0 ? '+' : '';
            const tagClass = p.type === 'LONG' ? 'pos-long' : 'pos-short';
            const typeIcon = p.type === 'LONG' ? '▲' : '▼';
            
            const leverage = p.leverage || 1;
            const margin = p.totalVol / leverage;
            
            const dcaBg = p.dcaCount > 0 ? 'color:#fcd535; background:rgba(252,213,53,0.1);' : 'color:#848e9c;';
            const ptBadge = p.ptDone ? `<span title="Kısmi TP alındı" style="min-width:34px; text-align:center; font-size:10px; font-weight:600; padding:1px 4px; border-radius:3px; background:rgba(252,213,53,0.15); color:#fcd535;">PT✓</span>` : '';
            const volCell = `<span style="display:inline-flex; align-items:center; justify-content:flex-end; gap:6px;"><span style="min-width:68px; text-align:right; color:#EAECEF; font-weight:600;">${p.totalVol.toFixed(2)} USDT</span><span style="min-width:26px; text-align:right; color:#fcd535; font-weight:600; font-size:10px;">${leverage}x</span><span style="min-width:82px; text-align:right; color:#0ECB81; font-weight:600; font-size:10px;">Marjin: ${margin.toFixed(2)}</span><span style="min-width:44px; text-align:center; font-size:10px; font-weight:600; padding:1px 4px; border-radius:3px; ${dcaBg}">${p.dcaCount > 0 ? 'DCA:' + p.dcaCount : 'Ana'}</span>${ptBadge}</span>`;
            
            html += `<tr class="${isActiveRow}" onclick="window.changeSymbol('${p.displaySymbol}')"><td class="center" style="color:#5d6471; font-size:11px;">${posArray.indexOf(p) + 1}</td><td class="left" style="font-weight:600; cursor:pointer;">${p.displaySymbol}</td><td class="left ${tagClass}">${typeIcon} ${p.type}</td><td class="right" style="font-size:11px;">${volCell}</td><td class="right" style="color:#848e9c;">${window.formatPrice(p.initialPrice || p.avgPrice)}</td><td class="right" style="color:#fcd535; font-weight:600;">${window.formatPrice(p.avgPrice)}</td><td class="right">${window.formatPrice(p.currentPrice)}</td><td class="right" style="color:#F6465D; font-weight:600; font-size:11px;">${liqPrice > 0 ? window.formatPrice(liqPrice) : '—'}</td><td class="right" style="color:${pnlColor}; font-weight:bold;">${sign}${p.pnlPct.toFixed(2)}% (${sign}${p.pnl.toFixed(2)}$)</td><td class="right" style="color:#848e9c;">-${(p.totalVol * getDisplayCommission(p.symbol)).toFixed(4)}$</td><td class="right" style="color:#EAECEF; font-size:11px;">${window.formatDateTime(p.entryTime)}</td><td class="right" style="color:#848e9c;">${timeStr}</td></tr>`;
        });
        tbody.innerHTML = html;
        
    } catch(e) {
        console.error('Pozisyonlar yüklenemedi:', e);
        tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; color:#f23645; padding:40px; border-bottom:none;">Backend bağlantı hatası: ${e.message}</td></tr>`;
    }
};


// --- 3. UI KONTROLLERİ VE EVENTLER ---
const sidebar = document.getElementById('sidebar'), vResizer = document.getElementById('drag-me'), hResizer = document.getElementById('h-drag-me'), wlModule = document.getElementById('watchlist-module'), btModule = document.getElementById('bottom-module');
let isVResizing = false, isHResizing = false;
const savedWidth = localStorage.getItem('sidebarWidth'); if (savedWidth && sidebar) sidebar.style.width = savedWidth;
const savedHFlex = localStorage.getItem('watchlistFlexBasis'); if (savedHFlex && wlModule && btModule) { wlModule.style.flex = `1 1 ${savedHFlex}%`; btModule.style.flex = `1 1 ${100 - savedHFlex}%`; }
window.toggleSidebar = function() { const btn = document.getElementById('sidebar-toggle'); if (sidebar.classList.contains('collapsed')) { sidebar.classList.remove('collapsed'); if (btn) btn.innerText = '〉'; } else { sidebar.classList.add('collapsed'); if (btn) btn.innerText = '〈'; } };
if (vResizer) { vResizer.addEventListener('mousedown', (e) => { if (e.target.id === 'sidebar-toggle') return; isVResizing = true; vResizer.classList.add('active'); document.body.style.cursor = 'col-resize'; document.getElementById('charts-grid').style.pointerEvents = 'none'; }); }
if (hResizer) { hResizer.addEventListener('mousedown', (e) => { isHResizing = true; hResizer.classList.add('active'); document.body.style.cursor = 'row-resize'; }); }
document.addEventListener('mousemove', (e) => { if (isVResizing) { const newWidth = document.body.clientWidth - e.clientX - 26; if (newWidth >= 250 && newWidth <= 600) sidebar.style.width = `${newWidth}px`; } if (isHResizing) { const sidebarRect = sidebar.getBoundingClientRect(); let newFlexBasis = ((e.clientY - sidebarRect.top) / sidebarRect.height) * 100; if (newFlexBasis > 15 && newFlexBasis < 85) { wlModule.style.flex = `1 1 ${newFlexBasis}%`; btModule.style.flex = `1 1 ${100 - newFlexBasis}%`; } } });
document.addEventListener('mouseup', () => { if (isVResizing) { isVResizing = false; vResizer.classList.remove('active'); document.body.style.cursor = 'default'; document.getElementById('charts-grid').style.pointerEvents = 'auto'; localStorage.setItem('sidebarWidth', sidebar.style.width); } if (isHResizing) { isHResizing = false; hResizer.classList.remove('active'); document.body.style.cursor = 'default'; const flexStr = wlModule.style.flex; if (flexStr) { const flexParts = flexStr.split(' '); const basisVal = parseFloat(flexParts[flexParts.length - 1]); if (!isNaN(basisVal)) localStorage.setItem('watchlistFlexBasis', parseInt(basisVal)); } } });

window.toggleRadarMode = function() { radarModeActive = !radarModeActive; localStorage.setItem('cryptoRadarMode', radarModeActive); const btn = document.getElementById('radar-toggle-btn'); if (btn) { if (radarModeActive) btn.classList.add('active'); else btn.classList.remove('active'); } window.renderActiveList(); };
window.switchTab = function(tab) { activeTab = tab; localStorage.setItem('cryptoActiveTab', tab); document.querySelectorAll('.tabs')[0].querySelectorAll('.tab-btn').forEach(btn => { if (btn.id !== 'radar-toggle-btn') btn.classList.remove('active'); }); document.querySelectorAll('.watchlist').forEach(ul => ul.style.display = 'none'); if (tab === 'futures') { document.querySelectorAll('.tabs')[0].children[0].classList.add('active'); document.getElementById('watchlist-futures').style.display = 'block'; } else { document.querySelectorAll('.tabs')[0].children[1].classList.add('active'); document.getElementById('watchlist-spot').style.display = 'block'; } window.renderActiveList(); };
window.filterWatchlist = function(val) { watchlistSearchQuery = val.toUpperCase(); window.renderActiveList(); };
window.sortBy = function(col) { if (sortCol === col) sortDir = sortDir === 'desc' ? 'asc' : 'desc'; else { sortCol = col; sortDir = 'desc'; } document.querySelectorAll('.sort-icon').forEach(el => el.innerHTML = ''); document.getElementById(`sort-${col}`).innerHTML = sortDir === 'desc' ? '↓' : '↑'; window.renderActiveList(); };
window.switchBottomTab = function(tab) {
    // Alt panel (Detaylar / İşlemler) tamamen kaldırıldı
    // Bu fonksiyon geriye uyumluluk için boş bırakıldı
    return;
};

// --- 4. BİNANCE APİ VE İZLEME LİSTESİ ---
window.fetchExchangeInfo = async function() {
    let knownCoins = JSON.parse(localStorage.getItem('cryptoKnownCoins_v3')); if (!knownCoins) knownCoins = { futures: [], spot: [] }; let changed = false;
    try {
        const fRes = await fetch('https://fapi.binance.com/fapi/v1/exchangeInfo');
        if (fRes.ok) {
            const fInfo = await fRes.json(); let currentF = fInfo.symbols.filter(s => s.status === 'TRADING' && s.quoteAsset === 'USDT').map(s => s.symbol);
            activeFuturesSymbols = new Set(currentF); hasExchangeInfoFutures = true; futuresData = futuresData.filter(item => activeFuturesSymbols.has(item.symbol));
            const fTab = document.querySelector('button[onclick*="futures"]'); if (fTab) fTab.innerText = `Vadeli-${activeFuturesSymbols.size}`;
            let newF = currentF.filter(s => !knownCoins.futures.includes(s));
            if (newF.length > 0) { if (knownCoins.futures.length > 0) newF.forEach(s => window.addSignal(`🚀 YENİ LİSTELEME: ${s}`, 'new-listing', s.replace('USDT','USDT.P'))); knownCoins.futures = [...new Set([...knownCoins.futures, ...currentF])]; changed = true; }
        }
    } catch(e) {}
    try {
        const sRes = await fetch('https://api.binance.com/api/v3/exchangeInfo');
        if (sRes.ok) {
            const sInfo = await sRes.json(); let currentS = sInfo.symbols.filter(s => s.status === 'TRADING' && s.quoteAsset === 'USDT' && s.isSpotTradingAllowed).map(s => s.symbol);
            activeSpotSymbols = new Set(currentS); hasExchangeInfoSpot = true; spotData = spotData.filter(item => activeSpotSymbols.has(item.symbol));
            const sTab = document.querySelector('button[onclick*="spot"]'); if (sTab) sTab.innerText = `Spot-${activeSpotSymbols.size}`;
            let newS = currentS.filter(s => !knownCoins.spot.includes(s));
            if (newS.length > 0) { if (knownCoins.spot.length > 0) newS.forEach(s => window.addSignal(`🚀 YENİ LİSTELEME: ${s}`, 'new-listing', s)); knownCoins.spot = [...new Set([...knownCoins.spot, ...currentS])]; changed = true; }
        }
    } catch(e) {}
    if (changed) localStorage.setItem('cryptoKnownCoins_v3', JSON.stringify(knownCoins));
};

window.updateWatchlistsRest = async function() {
    const todayUTC = new Date().toISOString().split('T')[0];
    if (dailyOpens.date !== todayUTC) { dailyOpens = { date: todayUTC, futures: {}, spot: {} }; localStorage.setItem('cryptoDailyOpens_v10', JSON.stringify(dailyOpens)); }
    fetch('https://fapi.binance.com/fapi/v1/ticker/24hr').then(r => r.json()).then(fData => { if (!Array.isArray(fData)) return; if (hasExchangeInfoFutures) fData = fData.filter(d => activeFuturesSymbols.has(d.symbol)); else fData = fData.filter(d => d.symbol.endsWith('USDT')); const mappedF = fData.map(d => ({ s: d.symbol, c: d.lastPrice, P: d.priceChangePercent, v: d.quoteVolume, h: d.highPrice, l: d.lowPrice, p: d.priceChange })); window.processTicker(mappedF, 'futures'); }).catch(e => {});
    fetch('https://api.binance.com/api/v3/ticker/24hr').then(r => r.json()).then(sData => { if (!Array.isArray(sData)) return; if (hasExchangeInfoSpot) sData = sData.filter(d => activeSpotSymbols.has(d.symbol)); else sData = sData.filter(d => d.symbol.endsWith('USDT')); const mappedS = sData.map(d => ({ s: d.symbol, c: d.lastPrice, P: d.priceChangePercent, v: d.quoteVolume, h: d.highPrice, l: d.lowPrice, p: d.priceChange })); window.processTicker(mappedS, 'spot'); }).catch(e => {});
};

window.processTicker = function(dataArr, type) {
    wsWatchlistLastUpdate = Date.now(); let memoryArray = type === 'futures' ? futuresData : spotData; let needsRender = false;
    dataArr.forEach(tick => {
        if (!tick.s || !tick.s.endsWith('USDT')) return; let symbol = tick.s;
        if (type === 'futures' && hasExchangeInfoFutures && !activeFuturesSymbols.has(symbol)) return;
        if (type === 'spot' && hasExchangeInfoSpot && !activeSpotSymbols.has(symbol)) return;
        let newPrice = parseFloat(tick.c), pctChange = parseFloat(tick.P), volume = parseFloat(tick.v), highPrice = parseFloat(tick.h || 0), lowPrice = parseFloat(tick.l || 0);
        let item = memoryArray.find(i => i.symbol === symbol);
        if (item) {
            if (newPrice !== item.lastPrice) item.tickDirection = newPrice > item.lastPrice ? 'up' : 'down';
            item.lastPrice = newPrice; item.priceChangePercent = pctChange; item.quoteVolume = volume;
            if (highPrice > 0) item.high = highPrice; if (lowPrice > 0) item.low = lowPrice;
        } else {
            memoryArray.push({ symbol: symbol, lastPrice: newPrice, priceChangePercent: pctChange, quoteVolume: volume, high: highPrice, low: lowPrice, tickDirection: 'neutral' }); needsRender = true;
        }
    });
    if (needsRender) { if (!window.renderDebounce) window.renderDebounce = {}; if (!window.renderDebounce[type]) { window.renderDebounce[type] = setTimeout(() => { window.renderActiveList(); window.renderDebounce[type] = null; }, 1000); } } else { window.renderActiveListPriceUpdateOnly(type); }
};

window.renderActiveListPriceUpdateOnly = function(type) {
    if (activeTab !== type) return; let dataToRender = type === 'futures' ? futuresData : spotData;
    dataToRender.forEach(item => {
        let displaySymbol = type === 'futures' ? item.symbol.replace('USDT', 'USDT.P') : item.symbol;
        let priceEl = document.getElementById(`price-${displaySymbol}`), pctEl = document.getElementById(`pct-${displaySymbol}`), pct03El = document.getElementById(`pct03-${displaySymbol}`);
        if (priceEl && pctEl) {
            priceEl.innerText = window.formatPrice(item.lastPrice); priceEl.className = `price ${item.tickDirection || 'neutral'}`;
            pctEl.innerText = (item.priceChangePercent > 0 ? '+' : '') + item.priceChangePercent.toFixed(2) + '%'; pctEl.className = `pct ${item.priceChangePercent >= 0 ? 'up' : 'down'}`;
            if (pct03El) { let change03 = item.change03 !== undefined && item.change03 !== null ? parseFloat(item.change03) : item.priceChangePercent; pct03El.innerText = (change03 > 0 ? '+' : '') + change03.toFixed(2) + '%'; pct03El.className = `pct ${change03 >= 0 ? 'up' : 'down'}`; }
        }
    });
};

window.renderActiveList = function() {
    let dataToRender = activeTab === 'futures' ? [...futuresData] : [...spotData];
    const ulId = activeTab === 'futures' ? 'watchlist-futures' : 'watchlist-spot';
    if (watchlistSearchQuery) dataToRender = dataToRender.filter(item => item.symbol.toUpperCase().includes(watchlistSearchQuery));
    if (radarModeActive) dataToRender = dataToRender.filter(item => item.change03 !== null && Math.abs(item.change03) >= 10);
    dataToRender.sort((a, b) => {
        if (a.symbol === 'BTCUSDT' && !watchlistSearchQuery && !radarModeActive) return -1; if (b.symbol === 'BTCUSDT' && !watchlistSearchQuery && !radarModeActive) return 1;
        let valA, valB; if (sortCol === 'symbol') { valA = a.symbol; valB = b.symbol; } else if (sortCol === 'price') { valA = parseFloat(a.lastPrice); valB = parseFloat(b.lastPrice); } else if (sortCol === 'change') { valA = parseFloat(a.priceChangePercent); valB = parseFloat(b.priceChangePercent); } else { valA = parseFloat(a.quoteVolume); valB = parseFloat(b.quoteVolume); }
        if (valA < valB) return sortDir === 'asc' ? -1 : 1; if (valA > valB) return sortDir === 'asc' ? 1 : -1; return 0;
    });
    const ul = document.getElementById(ulId); if (!ul) return; let html = '', activeSym = chartsData[activeChartId] ? chartsData[activeChartId].symbol : '';
    dataToRender.forEach(item => {
        const price = parseFloat(item.lastPrice), change = parseFloat(item.priceChangePercent); let pctColorClass = change > 0 ? 'up' : (change < 0 ? 'down' : 'neutral');
        let change03 = item.change03 !== undefined && item.change03 !== null ? parseFloat(item.change03) : change; let pct03ColorClass = change03 > 0 ? 'up' : (change03 < 0 ? 'down' : 'neutral');
        let displaySymbol = activeTab === 'futures' ? item.symbol.replace('USDT', 'USDT.P') : item.symbol, activeClass = displaySymbol === activeSym ? 'active-row' : '', tickColor = item.tickDirection || 'neutral';
        html += `<li id="item-${displaySymbol}" class="${activeClass}" onclick="window.changeSymbol('${displaySymbol}')"><span class="symbol" title="${displaySymbol}">${displaySymbol}</span><span id="price-${displaySymbol}" class="price ${tickColor}">${window.formatPrice(price)}</span><span id="pct-${displaySymbol}" class="pct ${pctColorClass}">${change>0?'+':''}${change.toFixed(2)}%</span><span id="pct03-${displaySymbol}" class="pct ${pct03ColorClass}" style="text-align:right;">${change03>0?'+':''}${change03.toFixed(2)}%</span></li>`;
    });
    ul.innerHTML = html;
};

// --- 5. CÜZDAN ENTEGRASYONU ---
window.syncWalletWithBackend = async function() {
    try {
        const res = await fetch('/api/wallet'); 
        const data = await res.json();
        let walletBtn = document.querySelector('button[onclick*="WalletModal"]') || Array.from(document.querySelectorAll('button')).find(b => b.innerText.includes('Cüzdan'));
        if (data.status === 'success') { 
            if(walletBtn) walletBtn.innerHTML = `🛡️ Cüzdan: <span style="color:#0ECB81; font-weight:bold;">$${data.balance.toFixed(2)}</span>`; 
        } else {
            if(walletBtn) walletBtn.innerHTML = `🛡️ Cüzdan: <span style="color:#f23645; font-size:12px; font-weight:bold;" title="${data.message}">API HATASI</span>`;
            console.error("Binance Reddi:", data.message);
        }
    } catch(e) {}
};

window.openWalletModal = function() { document.getElementById('wallet-modal').classList.add('active'); window.loadRealWalletData(); };
window.closeWalletModal = function() { document.getElementById('wallet-modal').classList.remove('active'); };

window.loadRealWalletData = async function() {
    const tbody = document.getElementById('wallet-tbody'); if (!tbody) return;
    document.querySelectorAll('#wallet-modal table th').forEach(th => { const text = th.innerText.trim().toLowerCase(); if (text.startsWith('balance')) th.innerText = 'Bakiye'; else if (text.startsWith('available')) th.innerText = 'Kullanılabilir Bakiye'; });
    tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#848e9c; padding: 25px;">Binance gerçek bakiyeleri yükleniyor...</td></tr>`;
    try {
        const res = await fetch('/api/wallet'); const data = await res.json();
        if (data.status === 'success' && data.assets) {
            if (data.assets.length === 0) { tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#848e9c; padding:25px;">0'dan büyük bakiyesi olan varlık bulunamadı.</td></tr>`; return; }
            let html = ''; const coinColors = { 'USDT': '#26A17B', 'BTC': '#F7931A', 'ETH': '#627EEA', 'BNB': '#F3BA2F', 'SOL': '#14F195' };
            data.assets.forEach(item => {
                const color = coinColors[item.coin] || '#848e9c', isFutures = item.wallet_type.includes('Vadeli'), badgeColor = isFutures ? 'rgba(41, 98, 255, 0.2)' : 'rgba(255, 152, 0, 0.2)', badgeTextColor = isFutures ? '#2962ff' : '#ff9800';
                html += `<tr style="border-bottom: 1px solid #2b3139;"><td class="left" style="display:flex; align-items:center; gap:10px; padding: 12px 15px;"><div style="width:26px; height:26px; border-radius:50%; background:${color}; color:#fff; display:flex; align-items:center; justify-content:center; font-size:11px; font-weight:bold;">${item.coin.charAt(0)}</div><div><div style="font-weight:bold; color:#EAECEF; display:flex; align-items:center; gap:8px;"><span>${item.coin}</span><span style="font-size:10px; padding:2px 6px; border-radius:3px; background:${badgeColor}; color:${badgeTextColor}; font-weight:bold;">${item.wallet_type}</span></div></div></td><td class="right" style="font-weight:bold; color:#EAECEF; padding: 12px 15px;">${item.balance}</td><td class="right" style="font-weight:bold; color:#0ECB81; padding: 12px 15px;">${item.available}</td></tr>`;
            }); tbody.innerHTML = html;
        } else { tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#f23645; padding:25px;">Hata: ${data.message || 'Veri alınamadı'}</td></tr>`; }
    } catch (e) { tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#f23645; padding:25px;">Bağlantı hatası: ${e}</td></tr>`; }
};

window.filterWallet = function() { const query = document.getElementById('wallet-search').value.toUpperCase(); const rows = document.querySelectorAll('#wallet-tbody tr'); rows.forEach(row => { const coinEl = row.querySelector('.left div:nth-child(2) div:first-child'); if (!coinEl) return; row.style.display = coinEl.innerText.toUpperCase().includes(query) ? '' : 'none'; }); };

// =============================================================
// BOT CONFIG MODAL
// =============================================================

window.openBotConfigModal = async function() {
    document.getElementById('bot-config-modal').classList.add('active');
    
    try {
        const res = await fetch('/api/engine/config');
        const cfg = await res.json();
        
        document.getElementById('cfg-scan-interval').value = cfg.scan_interval_seconds || 30;
        document.getElementById('cfg-position-interval').value = cfg.position_check_seconds || 3;
        document.getElementById('cfg-max-symbols').value = cfg.max_symbols || 30;
        document.getElementById('cfg-auto-close-delisted').checked = cfg.auto_close_delisted !== false;
        document.getElementById('cfg-daily-max-loss').value = cfg.daily_max_loss || 0;
        document.getElementById('cfg-max-open-positions').value = cfg.max_open_positions || 0;
        document.getElementById('cfg-use-limit-order').checked = cfg.useLimitOrder !== false;
        document.getElementById('cfg-limit-timeout').value = cfg.limitTimeoutSec || 3;
        document.getElementById('cfg-fallback-market').checked = cfg.fallbackToMarket !== false;
        
        ['RSI_SCALPER', 'HULL_SRP', 'GRIDBOT'].forEach(strat => {
            const s = (cfg.strategies || {})[strat] || {};
            
            const en = document.querySelector(`.strat-enabled[data-strategy="${strat}"]`);
            if (en) en.checked = !!s.enabled;
            
            const iv = document.querySelector(`.strat-interval[data-strategy="${strat}"]`);
            if (iv) iv.value = s.interval || '5m';
            
            document.querySelectorAll(`.strat-param[data-strategy="${strat}"]`).forEach(input => {
                const p = input.dataset.param;
                if (s[p] === undefined) return;
                
                if (input.type === 'checkbox') {
                    input.checked = !!s[p];
                } else {
                    input.value = s[p];
                }
            });
        });
        
        const statusRes = await fetch('/api/engine/status');
        const status = await statusRes.json();
        updateBotModalStatus(status.running && status.config.active);
        
                const tradesRes = await fetch('/api/trade/active');
        const trades = await tradesRes.json();
        document.getElementById('bot-modal-active-count').innerText = trades.length;
        
        // ⚡ Marjin önizlemelerini güncelle
        setTimeout(() => window.updateAllMarginPreviews(), 50);
        
    } catch(e) {
        console.error('Bot config yüklenirken hata:', e);
    }
};

window.closeBotConfigModal = function() {
    document.getElementById('bot-config-modal').classList.remove('active');
};
window.updateBotModalStatus = function(isRunning) {
    const pill = document.getElementById('bot-modal-status-pill');
    const dot = document.getElementById('bot-modal-status-dot');
    const text = document.getElementById('bot-modal-status-text');
    const startBtn = document.getElementById('btn-start-bot');
    const stopBtn = document.getElementById('btn-stop-bot');
    
    if (isRunning) {
        if (pill) pill.classList.add('running');
        if (dot) dot.style.background = '#0ECB81';
        if (text) text.innerText = 'AKTİF';
        if (startBtn) startBtn.disabled = true;
        if (stopBtn) stopBtn.disabled = false;
    } else {
        if (pill) pill.classList.remove('running');
        if (dot) dot.style.background = '#f23645';
        if (text) text.innerText = 'KAPALI';
        if (startBtn) startBtn.disabled = false;
        if (stopBtn) stopBtn.disabled = true;
    }
};

window.saveBotConfig = async function() {
    try {
        let currentlyActive = false;
        try {
            const statusRes = await fetch('/api/engine/status');
            const statusData = await statusRes.json();
            currentlyActive = statusData.running && statusData.config.active;
        } catch(e) {
            console.warn('Durum alınamadı, active=false kabul edildi');
        }
        
        const newCfg = {
            active: currentlyActive,
            scan_interval_seconds: parseInt(document.getElementById('cfg-scan-interval').value) || 30,
            position_check_seconds: parseInt(document.getElementById('cfg-position-interval').value) || 3,
            max_symbols: parseInt(document.getElementById('cfg-max-symbols').value) || 30,
            auto_close_delisted: document.getElementById('cfg-auto-close-delisted').checked,
            daily_max_loss: parseFloat(document.getElementById('cfg-daily-max-loss').value) || 0,
            max_open_positions: parseInt(document.getElementById('cfg-max-open-positions').value) || 0,
            useLimitOrder: document.getElementById('cfg-use-limit-order').checked,
            limitTimeoutSec: parseInt(document.getElementById('cfg-limit-timeout').value) || 3,
            fallbackToMarket: document.getElementById('cfg-fallback-market').checked,
            strategies: {}
        };
        
        ['RSI_SCALPER', 'HULL_SRP', 'GRIDBOT'].forEach(strat => {
            const s = {};
            
            const en = document.querySelector(`.strat-enabled[data-strategy="${strat}"]`);
            s.enabled = en ? en.checked : false;
            
            const iv = document.querySelector(`.strat-interval[data-strategy="${strat}"]`);
            s.interval = iv ? iv.value : '5m';
            
            document.querySelectorAll(`.strat-param[data-strategy="${strat}"]`).forEach(input => {
                const p = input.dataset.param;
                if (input.type === 'checkbox') {
                    s[p] = input.checked;
                } else if (input.type === 'number') {
                    s[p] = parseFloat(input.value) || 0;
                } else {
                    s[p] = input.value;
                }
            });
            
            newCfg.strategies[strat] = s;
        });
        
        const res = await fetch('/api/engine/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newCfg)
        });
        const result = await res.json();
        
        console.log('[💾 KAYDET] Config kaydedildi:', result);
        window.addSignal('💾 Bot ayarları kaydedildi', 'new-listing', null);
        window.showToast(
            currentlyActive ? '✅ Ayarlar kaydedildi (bot çalışıyor)' : '✅ Ayarlar kaydedildi (bot kapalı)', 
            'success'
        );
        
    } catch(e) {
        console.error('[💾 KAYDET] Hata:', e);
        window.showToast('❌ Kaydetme başarısız: ' + e.message, 'error');
    }
};

window.startBot = async function() {
    try {
        await window.saveBotConfig();
        
        const res = await fetch('/api/engine/toggle?active=true', { method: 'POST' });
        const result = await res.json();
        
        if (result.status === 'success') {
            window.updateBotModalStatus(true);
            window.updateBotUI();
            window.showToast('▶ Bot başlatıldı!', 'success');
            window.addSignal('▶ Bot BAŞLATILDI', 'new-listing', null);
        }
    } catch(e) {
        window.showToast('❌ Başlatma hatası: ' + e.message, 'error');
    }
};

window.stopBot = async function() {
    try {
        const tradesRes = await fetch('/api/trade/active');
        const trades = await tradesRes.json();
        
        let closePositions = false;
        
        if (trades.length > 0) {
            const preview = trades.slice(0, 8).map(t => `  • ${t.symbol} (${t.trade_type})`).join('\n');
            const more = trades.length > 8 ? `\n  ... ve ${trades.length - 8} tane daha` : '';
            
            const msg =
                `Şu an ${trades.length} adet açık pozisyonunuz var:\n\n` +
                preview + more + `\n\n` +
                `Bot durdurulduğunda:\n` +
                `  ✓ Yeni sinyaller ÜRETİLMEZ\n` +
                `  ✓ Açık pozisyonlar DA KAPATILACAK\n` +
                `  ✓ TP/SL/Trailing izlemesi DURACAK\n\n` +
                `Pozisyonlar kapatılsın ve bot dursun mu?`;
            
            const ok = await window.showConfirm(
                'BOT DURDURMA ONAYI',
                msg,
                'POZİSYONLARI KAPAT',
                'İPTAL',
                'warning'
            );
            
            if (!ok) return;
            closePositions = true;
        } else {
            const ok = await window.showConfirm(
                'BOT DURDUR',
                'Bot durdurulsun mu?\n\nAçık pozisyon bulunmuyor.',
                'DURDUR',
                'İPTAL',
                'warning'
            );
            if (!ok) return;
        }
        
        if (closePositions) {
            window.showToast('⏳ Pozisyonlar kapatılıyor...', 'info');
            try {
                const closeRes = await fetch('/api/trade/close-all', { method: 'POST' });
                const closeResult = await closeRes.json();
                window.showToast(`✅ ${closeResult.closed} pozisyon kapatıldı`, 'success');
            } catch(e) {
                window.showToast('❌ Pozisyonlar kapatılamadı', 'error');
            }
        }
        
        const res = await fetch('/api/engine/toggle?active=false&force=true', { method: 'POST' });
        const result = await res.json();
        
        if (result.status === 'success') {
            window.updateBotModalStatus(false);
            window.updateBotUI();
            window.showToast('⏹ Bot durduruldu', 'info');
            window.addSignal('⏹ Bot DURDURULDU', 'dump', null);
            
            const countEl = document.getElementById('bot-modal-active-count');
            if (countEl) countEl.innerText = '0';
        }
    } catch(e) {
        window.showToast('❌ Durdurma hatası: ' + e.message, 'error');
    }
};

window.refreshSymbolsFromModal = async function() {
    try {
        const res = await fetch('/api/engine/symbols/refresh', { method: 'POST' });
        const result = await res.json();
        window.showToast(`🔄 Semboller yenilendi (${result.symbols_count} sembol)`, 'success');
    } catch(e) {
        window.showToast('❌ Sembol yenileme hatası', 'error');
    }
};

// =============================================================
// TOAST
// =============================================================
window.showToast = function(message, type = 'info', duration = 4000, customTitle = null) {
    // ⚡ Deduplication: ayni mesaj 4 saniye icinde tekrar gelirse yoksay
    const msgStr = String(message || '');
    const dedupeKey = type + '|' + msgStr;
    const now = Date.now();
    
    if (!window._toastDedupeCache) window._toastDedupeCache = {};
    
    if (window._toastDedupeCache[dedupeKey]) {
        const elapsed = now - window._toastDedupeCache[dedupeKey];
        if (elapsed < 4000) return;
    }
    window._toastDedupeCache[dedupeKey] = now;
    
    // 30 sn'den eski kayitlari temizle
    Object.keys(window._toastDedupeCache).forEach(function(k) {
        if (now - window._toastDedupeCache[k] > 30000) delete window._toastDedupeCache[k];
    });
    
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }
    
    // Maks 5 toast
    while (container.children.length >= 5) {
        container.removeChild(container.firstChild);
    }
    
    const icons = {
        success: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>',
        error: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>',
        warning: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path></svg>',
        info: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line><circle cx="12" cy="12" r="10"></circle></svg>'
    };
    
    const titles = { success: 'Başarılı', error: 'Hata', warning: 'Uyarı', info: 'Bilgi' };
    
    // Bastaki emojiyi temizle
    let cleanMessage = msgStr.replace(/^[\u2705\u274C\u26A0\uFE0F\u2139\uFE0F\uD83D\uDCB0\uD83D\uDCCA\u25B6\u23F9\uD83D\uDDD1\uFE0F\uD83E\uDDF9\uD83D\uDD04\u26A1\uD83D\uDCBE\u2713\u2717\uD83D\uDEAB\uD83C\uDFAF\uD83D\uDD35\uD83D\uDFE2\uD83D\uDD34\uD83D\uDFE1]\s*/u, '').trim();
    if (!cleanMessage) cleanMessage = msgStr;
    
    const title = customTitle || titles[type] || 'Bilgi';
    const icon = icons[type] || icons.info;
    
    const toast = document.createElement('div');
    toast.className = 'toast toast-v2 toast-v2-' + type;
    
    toast.innerHTML = '<div class="toast-v2-icon">' + icon + '</div>'
        + '<div class="toast-v2-content">'
        + '<div class="toast-v2-title">' + title + '</div>'
        + '<div class="toast-v2-message">' + cleanMessage + '</div>'
        + '</div>'
        + '<button class="toast-v2-close" type="button">×</button>'
        + '<div class="toast-v2-progress" style="animation-duration: ' + duration + 'ms;"></div>';
    
    container.appendChild(toast);
    requestAnimationFrame(function() { toast.classList.add('show'); });
    
    const closeBtn = toast.querySelector('.toast-v2-close');
    const timer = setTimeout(function() {
        toast.classList.remove('show');
        setTimeout(function() { toast.remove(); }, 600);
    }, duration);
    
    closeBtn.addEventListener('click', function() {
        clearTimeout(timer);
        toast.classList.remove('show');
        setTimeout(function() { toast.remove(); }, 600);
    });
};

// =============================================================
// CUSTOM CONFIRM MODAL
// =============================================================
window.showConfirm = function(title, message, okText = 'TAMAM', cancelText = 'İPTAL', variant = 'info') {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.className = 'confirm-overlay';
        
        let headerClass = '';
        let okClass = '';
        let icon = '❓';
        
        if (variant === 'warning') { headerClass = 'warning'; icon = '⚠️'; }
        else if (variant === 'danger') { headerClass = 'danger'; okClass = 'danger'; icon = '🚨'; }
        
        overlay.innerHTML = `
            <div class="confirm-box">
                <div class="confirm-header ${headerClass}">
                    <span>${icon}</span>
                    <span>${title}</span>
                </div>
                <div class="confirm-body">${message}</div>
                <div class="confirm-footer">
                    <button class="confirm-cancel">${cancelText}</button>
                    <button class="confirm-ok ${okClass}">${okText}</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(overlay);
        requestAnimationFrame(() => overlay.classList.add('active'));
        
        const cleanup = (result) => {
            overlay.classList.remove('active');
            setTimeout(() => overlay.remove(), 200);
            resolve(result);
        };
        
        overlay.querySelector('.confirm-cancel').onclick = () => cleanup(false);
        overlay.querySelector('.confirm-ok').onclick = () => cleanup(true);
        overlay.onclick = (e) => { if (e.target === overlay) cleanup(false); };
        
        const escHandler = (e) => {
            if (e.key === 'Escape') {
                document.removeEventListener('keydown', escHandler);
                cleanup(false);
            }
        };
        document.addEventListener('keydown', escHandler);
    });
};

// =============================================================
// SCANNER BADGE
// =============================================================
window.updateScannerBadge = function(status) {
    const badge = document.getElementById('scanner-status');
    if (!badge) return;
    
    const isRunning = status.running && status.config && status.config.active;
    
    if (!isRunning) {
        badge.style.display = 'none';
        return;
    }
    
    badge.style.display = 'inline-flex';
    badge.classList.remove('passive');
    
    const symbolsEl = document.getElementById('scanner-symbols');
    if (symbolsEl) symbolsEl.innerText = `${status.symbols_count || 0} sembol`;
    
    const lastScanEl = document.getElementById('scanner-last-scan');
    if (lastScanEl) {
        if (status.stats && status.stats.scans > 0) {
            lastScanEl.innerText = `${status.stats.scans} tarama`;
        } else {
            lastScanEl.innerText = 'bekleniyor...';
        }
    }
    
    const signalsEl = document.getElementById('scanner-signals');
    const signalsSep = document.getElementById('scanner-signals-sep');
    if (signalsEl && status.stats) {
        const count = status.stats.signals_found || 0;
        if (count > 0) {
            signalsEl.innerText = `${count} sinyal`;
            signalsEl.style.display = 'inline';
            if (signalsSep) signalsSep.style.display = 'inline';
        } else {
            signalsEl.style.display = 'none';
            if (signalsSep) signalsSep.style.display = 'none';
        }
    }
};

window.startScannerPolling = function() {
    const fetchStatus = async () => {
        try {
            const res = await fetch('/api/engine/status');
            const status = await res.json();
            window.updateScannerBadge(status);
        } catch(e) {}
    };
    
    fetchStatus();
    setInterval(fetchStatus, 30000);
};

// =============================================================
// GLOBAL SCANNER (arka plan simülasyon)
// =============================================================
window.globalScannerLoop = async function() {
    if (!botConfig.active) { setTimeout(window.globalScannerLoop, 3000); return; }
    let targetList = activeTab === 'futures' ? futuresData : spotData; if (targetList.length === 0) { setTimeout(window.globalScannerLoop, 3000); return; }
    if (scanQueue.length === 0) { scanQueue = targetList.map(item => activeTab === 'futures' ? item.symbol.replace('USDT', 'USDT.P') : item.symbol); }
    
    let batch = scanQueue.splice(0, 2); 
    let strategyInds = chartsData[activeChartId] && chartsData[activeChartId].indicators ? chartsData[activeChartId].indicators : new Map(); 
    let interval = chartsData[activeChartId] ? chartsData[activeChartId].interval : savedInterval;
    let bInt = window.getBinanceInterval(interval);
    
    await Promise.all(batch.map(async (sym) => {
        let hasStrategy = false; strategyInds.forEach(v => { if (v.isMarker) hasStrategy = true; }); if (!hasStrategy) { globalPositions.delete(sym); return; }
        let isForeground = false; for (let i=0; i<chartCount; i++) { if (chartsData[i] && chartsData[i].symbol === sym) isForeground = true; } if (isForeground) return; 

        try {
            let apiSym = sym.replace('.P', ''); let baseUrl = sym.endsWith('.P') ? 'https://fapi.binance.com/fapi/v1/klines' : 'https://api.binance.com/api/v3/klines';
            let res = await fetch(`${baseUrl}?symbol=${apiSym}&interval=${bInt}&limit=500`); if (!res.ok) return; let data = await res.json();
            let rawCandles = data.map(d => ({ time: Math.floor(d[0]/1000), open: parseFloat(d[1]), high: parseFloat(d[2]), low: parseFloat(d[3]), close: parseFloat(d[4]), volume: parseFloat(d[5]) }));
            let simulatedObj = { symbol: sym, tradeLineSeriesArr: [], tradeLabels: [], chart: null }; let activeTrade = null;
            strategyInds.forEach((val) => {
                if (val.type === 'HULL_SRP') { let r = window.calcHullSRP(rawCandles, val.params, simulatedObj, true); if (r && r.lastTrade) activeTrade = r.lastTrade; } 
                else if (val.type === 'GRIDBOT') { let r = window.calcGridbotScalper(rawCandles, val.params, simulatedObj, true); if (r && r.lastTrade) activeTrade = r.lastTrade; } 
                else if (val.type === 'RSI_SCALPER') { let r = window.calcRSIScalper(rawCandles, val.params, simulatedObj, true); if (r && r.lastTrade) activeTrade = r.lastTrade; }
            });
            if (activeTrade) globalPositions.set(sym, activeTrade); else globalPositions.delete(sym);
        } catch(e) {}
    }));
    let minimalPos = Array.from(globalPositions.entries()).map(([k, t]) => [k, { type: t.type, entryPrice: t.entryPrice, avgPrice: t.avgPrice, entryTime: t.entryTime, totalVol: t.totalVol, dcaCount: t.dcaCount }]); try { localStorage.setItem('cryptoGlobalPos_v1', JSON.stringify(minimalPos)); } catch(e) {}
    setTimeout(window.globalScannerLoop, 2000); 
};

// =============================================================
// SİNYAL LOG
// =============================================================
window.renderSignals = async function() {
    const logContainer = document.getElementById('signal-log');
    if (!logContainer) return;
    
    try {
        const res = await fetch('/api/engine/recent-signals?limit=50');
        const events = await res.json();
        
        if (!Array.isArray(events) || events.length === 0) {
            logContainer.innerHTML = '<li class="loading">Henüz bir sinyal yok.</li>';
            return;
        }
        
        // Hash kontrolü — sadece değiştiyse render et
        const newHash = events.map(e => e.event_type + '_' + e.id).join('|');
        if (window._signalHash === newHash) return;
        window._signalHash = newHash;
        
        // Yeni event tespit → toast göster
        if (!window._seenSignalIds) window._seenSignalIds = new Set();
        if (window._signalInitialized) {
            events.forEach(evt => {
                const uid = evt.event_type + '_' + evt.id;
                if (!window._seenSignalIds.has(uid)) {
                    if (evt.event_type === 'signal') {
                        const isLong = evt.signal === 'LONG';
                        window.showToast(
                            `${evt.symbol} [${evt.strategy}] ${evt.signal}`,
                            isLong ? 'success' : 'error',
                            5000
                        );
                    } else {
                        // Kapanış toast
                        const sign = evt.pnl_amount >= 0 ? '+' : '';
                        window.showToast(
                            `${evt.symbol} KAPANDI ${sign}${evt.pnl_amount.toFixed(4)} USDT`,
                            evt.pnl_amount >= 0 ? 'success' : 'error',
                            5000
                        );
                    }
                }
            });
        }
        events.forEach(evt => window._seenSignalIds.add(evt.event_type + '_' + evt.id));
        window._signalInitialized = true;
        
        const formatSignalDate = (ms) => {
            const d = new Date(ms);
            const pad = (n) => String(n).padStart(2, '0');
            return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
        };
        
        let html = '';
        events.forEach(evt => {
            if (evt.event_type === 'signal') {
                // ⚡ AÇILAN SİNYAL (mavi çerçeve)
                const isLong = evt.signal === 'LONG';
                const tagClass = isLong ? 'pos-long' : 'pos-short';
                const tagText = isLong ? 'LONG' : 'SHORT';
                const dateStr = formatSignalDate(evt.created_at);
                const priceStr = window.formatPrice(evt.price);
                
                html += `
                    <li class="signal-item" onclick="window.changeSymbol('${evt.display_symbol}')">
                        <div class="signal-line-1">
                            <span class="signal-symbol">${evt.symbol}</span>
                            <span class="signal-strategy">[${evt.strategy}]</span>
                            <span class="signal-tag ${tagClass}">${tagText}</span>
                        </div>
                        <div class="signal-line-date">${dateStr}</div>
                        <div class="signal-line-2">
                            <span class="signal-label">Giriş Fiyat:</span>
                            <span class="signal-value">${priceStr}</span>
                            <span class="signal-label" style="margin-left:12px;">Toplam:</span>
                            <span class="signal-value">${evt.total_usdt.toFixed(2)} USDT</span>
                        </div>
                    </li>
                `;
            } else {
                // ⚡ KAPANAN İŞLEM (yeşil çerçeve)
                const isProfit = evt.pnl_amount >= 0;
                const sign = isProfit ? '+' : '';
                const pnlColor = isProfit ? '#0ECB81' : '#F6465D';
                
                // Kapanış sebebi kısalt
                let reasonText = evt.close_reason || 'KAPANIŞ';
                if (reasonText.includes('TRAILING')) {
                    const match = reasonText.match(/\(([^)]+)\)/);
                    reasonText = `TRAILING ${match ? match[1] : ''}`.trim();
                } else if (reasonText.includes('STOP LOSS')) {
                    reasonText = 'STOP LOSS';
                } else if (reasonText.includes('TAKE PROFIT')) {
                    reasonText = 'TAKE PROFIT';
                }
                
                const dateStr = formatSignalDate(evt.timestamp);
                
                                // ⚡ STOP LOSS ise kırmızı, diğerleri yeşil
                const isPartial = evt.is_partial == 1;
                const isStopLoss = (evt.close_reason || '').toUpperCase().includes('STOP');
                let cardClass = 'close-item';
                if (isPartial) cardClass = 'partial-tp-item';
                else if (isStopLoss) cardClass = 'stop-item';
                
                html += `
                    <li class="signal-item ${cardClass}" onclick="window.changeSymbol('${evt.display_symbol}')">
                        <div class="signal-line-1">
                            <span class="signal-symbol">${evt.symbol}</span>
                            <span class="signal-strategy">| ${evt.is_partial ? '🎯 KISMİ TP' : reasonText} |</span>
                        </div>
                        <div class="signal-line-2">
                            <span class="signal-label">Giriş:</span>
                            <span class="signal-value">${window.formatPrice(evt.entry_price)}</span>
                            <span class="signal-label" style="margin-left:8px;">Çıkış:</span>
                            <span class="signal-value">${window.formatPrice(evt.exit_price)}</span>
                            <span class="signal-label" style="margin-left:8px;">Kâr:</span>
                            <span class="signal-value" style="color:${pnlColor};">${sign}${evt.pnl_pct.toFixed(2)}%</span>
                        </div>
                        <div class="signal-line-2">
                            <span class="signal-label" style="color:#5d6471;">${dateStr}</span>
                            <span class="signal-label" style="margin-left:8px;">Net:</span>
                            <span class="signal-value" style="color:${pnlColor};">${sign}${evt.pnl_amount.toFixed(4)} USDT</span>
                        </div>
                    </li>
                `;
            }
        });
        logContainer.innerHTML = html;
    } catch(e) {
        console.error('Sinyaller yüklenemedi:', e);
    }
};

// ⚡ Polling başlat / durdur
window.startSignalPolling = function() {
    if (window._signalPollingInterval) return;
    window.renderSignals();
    window._signalPollingInterval = setInterval(window.renderSignals, 8000);
};

window.stopSignalPolling = function() {
    if (window._signalPollingInterval) {
        clearInterval(window._signalPollingInterval);
        window._signalPollingInterval = null;
    }
};

window.addSignal = function(htmlMessage, type = 'normal', symbol = null) {
    // ⚡ Artık signal-log backend'den geliyor. Bu fonksiyon sadece bilgi amaçlı toast gösteriyor.
    const cleanMsg = String(htmlMessage).replace(/<[^>]*>/g, '');
    const toastType = (type === 'dump') ? 'error' : ((type === 'new-listing' || type === 'pump') ? 'success' : 'info');
    window.showToast(cleanMsg, toastType, 2500);
};

window.clearSignals = function() { signalLogData = []; localStorage.setItem('cryptoSignals_v1', JSON.stringify(signalLogData)); window.renderSignals(); };

// =============================================================
// DETAYLAR PANELİ
// =============================================================
window.loadCoinDetails = async function(symbol) {
    if (!symbol) return; const symEl = document.getElementById('d-sym'); if (symEl) symEl.innerText = symbol;
    
    const priceDisplay = document.querySelector('#d-price') || document.querySelector('.details-price');
    if (priceDisplay) { let activeObj = chartsData.find(c => c.symbol === symbol); if (activeObj && activeObj.lastClose) priceDisplay.innerText = window.formatPrice(activeObj.lastClose); }

    function updatePerfBox(id, val) { let box = document.getElementById(id); if (!box) return; let valSpan = box.querySelector('.p-val'); box.className = 'perf-box'; if (val === null || isNaN(val)) { valSpan.innerText = "--"; valSpan.style.color = "#848e9c"; } else { valSpan.innerText = (val > 0 ? '+' : '') + val.toFixed(2) + '%'; box.classList.add(val >= 0 ? 'up' : 'down'); valSpan.style.color = ""; } }
    updatePerfBox('p-1w', null); updatePerfBox('p-1m', null); updatePerfBox('p-3m', null); updatePerfBox('p-6m', null); updatePerfBox('p-ytd', null); updatePerfBox('p-1y', null);
    const volEl = document.getElementById('d-vol-30'); if (volEl) volEl.innerText = "--";
    const needle = document.getElementById('gauge-needle'); if (needle) needle.style.transform = `rotate(0deg)`;
    const stEl = document.getElementById('gauge-status-text'); if (stEl) { stEl.innerText = "Hesaplanıyor..."; stEl.style.color = "#848e9c"; }

    const isFutures = symbol.endsWith('.P'); const apiSymbol = symbol.replace('.P', ''); const baseUrl = isFutures ? 'https://fapi.binance.com/fapi/v1/klines' : 'https://api.binance.com/api/v3/klines';
    
    // ⚡ Funding rate badge guncelle (isFutures tanimli, simdi cagrilabilir)
    if (isFutures) {
        window.updateFundingBadge(apiSymbol);
    }
    try {
        const res = await fetch(`${baseUrl}?symbol=${apiSymbol}&interval=1d&limit=365`); if (!res.ok) return; const data = await res.json(); if (!data || data.length === 0) return;
        let volSum = 0; let count = Math.min(30, data.length); for (let i = data.length - 1; i >= data.length - count; i--) { volSum += parseFloat(data[i][5]); } if (volEl) volEl.innerText = window.formatVolume(volSum / count);
        let closes = data.map(d => parseFloat(d[4])); let curPrice = closes[closes.length - 1];

        if (priceDisplay && (!chartsData.find(c => c.symbol === symbol)?.lastClose)) priceDisplay.innerText = window.formatPrice(curPrice);

        function calcPerf(days) { if (data.length <= days) return null; let oldPrice = parseFloat(data[data.length - 1 - days][4]); return ((curPrice - oldPrice) / oldPrice) * 100; }
        function calcYTD() { let currentYear = new Date().getFullYear(); let firstDayData = data.find(d => new Date(d[0]).getFullYear() === currentYear); if (!firstDayData) return null; let oldPrice = parseFloat(firstDayData[1]); return ((curPrice - oldPrice) / oldPrice) * 100; }
        updatePerfBox('p-1w', calcPerf(7)); updatePerfBox('p-1m', calcPerf(30)); updatePerfBox('p-3m', calcPerf(90)); updatePerfBox('p-6m', calcPerf(180)); updatePerfBox('p-1y', calcPerf(364)); updatePerfBox('p-ytd', calcYTD());

        let rsi = window.calcRSI(closes.map((c)=>({close:c})), 14); let sma20 = window.calcIndicatorSMA(data.map(d => ({time: 0, close: parseFloat(d[4])})), 20); let sma50 = window.calcIndicatorSMA(data.map(d => ({time: 0, close: parseFloat(d[4])})), 50);
        let lastRsi = rsi[rsi.length - 1]; let lastSma20 = sma20[sma20.length - 1]?.value || 0; let lastSma50 = sma50[sma50.length - 1]?.value || 0;
        let score = 0; if (curPrice > lastSma20) score += 20; else score -= 20; if (curPrice > lastSma50) score += 30; else score -= 30; if (lastRsi < 30) score += 40; else if (lastRsi > 70) score -= 40; else score += ((50 - lastRsi) / 20) * 20;
        score = Math.max(-90, Math.min(90, score)); if (needle) needle.style.transform = `rotate(${score}deg)`;

        let statusText = "Nötr", statusColor = "#848e9c"; if (score <= -54) { statusText = "Güçlü Sat"; statusColor = "#f23645"; } else if (score <= -18) { statusText = "Sat"; statusColor = "#ff9800"; } else if (score < 18) { statusText = "Nötr"; statusColor = "#848e9c"; } else if (score < 54) { statusText = "Al"; statusColor = "#2962ff"; } else { statusText = "Güçlü Al"; statusColor = "#089981"; }
        if (stEl) { stEl.innerText = statusText; stEl.style.color = statusColor; }
    } catch(e) {}
};

// =============================================================
// GRAFİK YÖNETİMİ
// =============================================================
window.convertToHeikinAshi = function(rawDataArray) {
    let haData = [];
    for (let i = 0; i < rawDataArray.length; i++) {
        let raw = rawDataArray[i]; let ha = { time: raw.time }; ha.close = (raw.open + raw.high + raw.low + raw.close) / 4;
        if (i === 0) ha.open = (raw.open + raw.close) / 2; else ha.open = (haData[i - 1].open + haData[i - 1].close) / 2;
        ha.high = Math.max(raw.high, ha.open, ha.close); ha.low = Math.min(raw.low, ha.open, ha.close); haData.push(ha);
    }
    return haData;
};

window.changeChartType = function(type) {
    chartsData[activeChartId].chartType = type; localStorage.setItem('cryptoChartType', type);
    document.querySelectorAll('.type-btn').forEach(b => { if (b.dataset.type === type) b.classList.add('active'); else b.classList.remove('active'); });
    let dataObj = chartsData[activeChartId];
    if (dataObj.series && dataObj.rawCandles.length > 0) {
        let activeArray = type === 'heikin' ? dataObj.haCandles : dataObj.rawCandles;
        dataObj.series.setData(activeArray.map(c => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close })));
        let allM = [...(dataObj.strategyMarkers||[])].sort((a,b)=>a.time-b.time); dataObj.series.setMarkers(allM);
    }
    window.saveChartsState();
};

window.resetChart = function(i) {
    if (chartsData[i].chart && chartsData[i].series) { chartsData[i].chart.priceScale('right').applyOptions({ autoScale: true, scaleMargins: { top: 0.20, bottom: 0.20 } }); chartsData[i].chart.timeScale().applyOptions({ rightOffset: 5, barSpacing: 6 }); }
    window.setActiveChart(i);
};

window.setLayout = function(count) {
    if (maximizedChartId !== null) { 
        const prevWrap = document.getElementById(`chart-wrapper-${maximizedChartId}`); 
        if (prevWrap) prevWrap.classList.remove('chart-maximized'); 
        maximizedChartId = null; 
    }
    chartCount = count; 
    localStorage.setItem('cryptoLayoutCount', count);
    
    const grid = document.getElementById('charts-grid'); 
    if (grid) grid.className = `charts-grid layout-${count}`;
    
    document.querySelectorAll('.layout-btn').forEach(b => b.classList.remove('active')); 
    let btn = document.getElementById(`btn-layout-${count}`); 
    if (btn) btn.classList.add('active');

    for (let i = 0; i < 4; i++) {
        const wrap = document.getElementById(`chart-wrapper-${i}`);
        if (wrap) { 
            if (i < count) { 
                wrap.style.display = 'flex'; 
            } else { 
                wrap.style.display = 'none'; 
            } 
        }
    }
    
    requestAnimationFrame(() => {
        setTimeout(() => {
            for (let i = 0; i < count; i++) {
                const container = document.getElementById(`tvchart-${i}`);
                if (!container) continue;
                
                const rect = container.getBoundingClientRect();
                if (rect.width === 0 || rect.height === 0) continue;
                
                if (!chartsData[i].chart) {
                    window.initSingleChart(i);
                } else {
                    try {
                        chartsData[i].chart.applyOptions({ 
                            width: rect.width, 
                            height: rect.height 
                        });
                        chartsData[i].chart.timeScale().applyOptions({ rightOffset: 5 });
                    } catch(e) {
                        console.warn(`Chart ${i} resize hatası:`, e);
                    }
                }
            }
            
            window.setActiveChart(activeChartId >= count ? 0 : activeChartId);
        }, 150);
    });
};

window.setActiveChart = function(i) {
    activeChartId = i; document.querySelectorAll('.single-chart-wrap').forEach(w => w.classList.remove('active-chart')); const targetWrap = document.getElementById(`chart-wrapper-${i}`); if (targetWrap) targetWrap.classList.add('active-chart');
    const currentInt = chartsData[i].interval; document.querySelectorAll('.tf-btn').forEach(b => { if (b.dataset.tf === currentInt) b.classList.add('active'); else b.classList.remove('active'); });
    const currentType = chartsData[i].chartType || 'candles'; document.querySelectorAll('.type-btn').forEach(b => { if (b.dataset.type === currentType) b.classList.add('active'); else b.classList.remove('active'); });
    let sym = chartsData[i].symbol; document.querySelectorAll('.watchlist li').forEach(li => li.classList.remove('active-row')); let activeLi = document.getElementById(`item-${sym}`); if (activeLi) activeLi.classList.add('active-row');
    window.loadCoinDetails(sym); window.refreshBottomPanel();
};

window.changeSymbol = function(sym) {
    if (window.clearSymbolTrades) window.clearSymbolTrades(activeChartId);
    let cObj = chartsData[activeChartId]; cObj.symbol = sym; cObj.hasInitialData = false;
    if (cObj.ws) { cObj.ws.onclose = null; cObj.ws.close(); cObj.ws = null; }
    cObj.rawCandles = []; cObj.haCandles = []; cObj.candleMap.clear(); if (cObj.series) cObj.series.setData([]);
    if (cObj.tradeLineSeriesArr) { cObj.tradeLineSeriesArr.forEach(ls => { try { cObj.chart.removeSeries(ls); } catch(e){} }); cObj.tradeLineSeriesArr = []; }
    document.querySelectorAll('.watchlist li').forEach(li => li.classList.remove('active-row')); let activeLi = document.getElementById(`item-${sym}`); if (activeLi) activeLi.classList.add('active-row');
    if (window.BotUI) window.BotUI.clearAll(activeChartId); cObj.indicators.forEach((val) => { if (val.isMarker) cObj.strategyMarkers = []; else if (val.series) { cObj.chart.removeSeries(val.series); val.series = null; } });
    window.updateSingleChart(activeChartId); window.saveChartsState(); window.loadCoinDetails(sym);
    if (window.refreshBottomPanel) window.refreshBottomPanel();
};

window.changeTimeframe = function(tf) {
    let cObj = chartsData[activeChartId]; cObj.interval = tf; localStorage.setItem('cryptoInterval', tf);
    document.querySelectorAll('.tf-btn').forEach(b => { if (b.dataset.tf === tf) b.classList.add('active'); else b.classList.remove('active'); });
    if (cObj.ws) { cObj.ws.onclose = null; cObj.ws.close(); cObj.ws = null; }
    cObj.rawCandles = []; cObj.haCandles = []; cObj.candleMap.clear(); if (cObj.series) cObj.series.setData([]);
    if (cObj.tradeLineSeriesArr) { cObj.tradeLineSeriesArr.forEach(ls => { try { cObj.chart.removeSeries(ls); } catch(e){} }); cObj.tradeLineSeriesArr = []; }
    cObj.indicators.forEach((val) => { if (val.isMarker) { cObj.strategyMarkers = []; cObj.series.setMarkers([]); } else if (val.series) { cObj.chart.removeSeries(val.series); val.series = null; } });
    window.updateSingleChart(activeChartId); window.saveChartsState();
};

window.initSingleChart = function(i) {
    const container = document.getElementById(`tvchart-${i}`); if (!container) return;
    const chart = LightweightCharts.createChart(container, { layout: { background: { type: 'solid', color: '#131722' }, textColor: '#d1d4dc' }, grid: { vertLines: { color: '#2a2e39' }, horzLines: { color: '#2a2e39' } }, crosshair: { mode: LightweightCharts.CrosshairMode.Normal }, rightPriceScale: { borderColor: '#2a2e39', autoScale: true, scaleMargins: { top: 0.20, bottom: 0.20 } }, timeScale: { borderColor: '#2a2e39', timeVisible: true, rightOffset: 5, barSpacing: 6, tickMarkFormatter: (time, tickMarkType) => { const date = new Date(time * 1000); const localTime = new Date(date.getTime() + (3 * 60 * 60 * 1000)); const h = localTime.getUTCHours().toString().padStart(2, '0'); const m = localTime.getUTCMinutes().toString().padStart(2, '0'); const D = localTime.getUTCDate().toString().padStart(2, '0'); const M = (localTime.getUTCMonth() + 1).toString().padStart(2, '0'); if (tickMarkType === LightweightCharts.TickMarkType.Time) return `${h}:${m}`; return `${D}/${M}`; } }, localization: { locale: 'tr-TR', timeFormatter: (time) => { const date = new Date(time * 1000); const localTime = new Date(date.getTime() + (3 * 60 * 60 * 1000)); const D = localTime.getUTCDate().toString().padStart(2, '0'); const M = (localTime.getUTCMonth() + 1).toString().padStart(2, '0'); const Y = localTime.getUTCFullYear(); const h = localTime.getUTCHours().toString().padStart(2, '0'); const m = localTime.getUTCMinutes().toString().padStart(2, '0'); return `${D}/${M}/${Y} ${h}:${m}`; } }, handleScroll: { mouseWheel: false, pressedMouseMove: true }, handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true }, });
    const series = chart.addCandlestickSeries({ upColor: '#089981', downColor: '#f23645', borderVisible: false, wickUpColor: '#089981', wickDownColor: '#f23645' });
    chartsData[i].chart = chart; chartsData[i].series = series; chartResizeObserver.observe(container);
    chart.timeScale().subscribeVisibleLogicalRangeChange(() => window.syncTradeLabels(i));
    chart.subscribeCrosshairMove(param => { const dataObj = chartsData[i]; if (param.time) { dataObj.crosshairActive = true; const candle = dataObj.candleMap.get(param.time); if (candle) window.renderOHLCV(i, candle); } else { dataObj.crosshairActive = false; if (dataObj.rawCandles.length > 0) { const lastRaw = dataObj.rawCandles[dataObj.rawCandles.length - 1]; const candle = dataObj.candleMap.get(lastRaw.time); if (candle) window.renderOHLCV(i, candle); } } window.syncTradeLabels(i); });
    window.applyChartSettingsToNewChart(i);
	setTimeout(() => { window.updateSingleChart(i); }, i * 200);
};

window.updateSingleChart = async function(i) {
    const dataObj = chartsData[i]; const overlaySym = document.getElementById(`overlay-sym-${i}`);
    dataObj.hasInitialData = false; dataObj.lastWsUpdate = Date.now(); if (overlaySym) overlaySym.innerText = dataObj.symbol;
    const isFutures = dataObj.symbol.endsWith('.P'); const apiSymbol = dataObj.symbol.replace('.P', ''); 
    const baseUrl = isFutures ? 'https://fapi.binance.com/fapi/v1/klines' : 'https://api.binance.com/api/v3/klines';
    let bInt = window.getBinanceInterval(dataObj.interval);

    try {
        const res = await fetch(`${baseUrl}?symbol=${apiSymbol}&interval=${bInt}&limit=1500`); if (!res.ok) throw new Error("REST API Hatası"); const data = await res.json();
        dataObj.candleMap.clear(); dataObj.rawCandles = []; dataObj.haCandles = [];
        if (Array.isArray(data) && data.length > 0) {
            const cData = data.map(d => { const t = Math.floor(d[0]/1000), o = parseFloat(d[1]), h = parseFloat(d[2]), l = parseFloat(d[3]), c = parseFloat(d[4]), v = parseFloat(d[5]); dataObj.candleMap.set(t, {o, h, l, c, v}); return { time: t, open: o, high: h, low: l, close: c, volume: v }; });
            dataObj.rawCandles = cData; dataObj.haCandles = window.convertToHeikinAshi(cData);
            const activeArray = dataObj.chartType === 'heikin' ? dataObj.haCandles : dataObj.rawCandles; const lastCandle = activeArray[activeArray.length - 1];
            window.updateChartPrecision(i, lastCandle.close); dataObj.lastCandleTime = lastCandle.time; dataObj.lastClose = lastCandle.close;
            const cleanArray = activeArray.map(c => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close }));
            dataObj.series.setData(cleanArray); dataObj.hasInitialData = true; dataObj.chart.timeScale().applyOptions({ rightOffset: 5 }); window.renderOHLCV(i, dataObj.candleMap.get(lastCandle.time));
        }
        if (window.recalculateAllIndicators) window.recalculateAllIndicators(i); window.connectSingleChartWS(i);
    } catch(e) { setTimeout(() => window.updateSingleChart(i), 15000); }
};

// =============================================================
// WS BAĞLANTI + REST FALLBACK (DÜZELTİLMİŞ)
// =============================================================

window._connectWsInternal = function(i) {
    const dataObj = chartsData[i];
    if (dataObj.ws) { 
        dataObj.ws.onclose = null; 
        dataObj.ws.close(); 
    }
    
    setTimeout(() => {
        const isFutures = dataObj.symbol.endsWith('.P');
        const apiSymbol = dataObj.symbol.replace('.P', '');
        let bInt = window.getBinanceInterval(dataObj.interval);
        const streamUrl = isFutures 
            ? `wss://fstream.binance.com/ws/${apiSymbol.toLowerCase()}@kline_${bInt}`
            : `wss://stream.binance.com/ws/${apiSymbol.toLowerCase()}@kline_${bInt}`;
        
        dataObj.lastWsUpdate = Date.now();
        dataObj.ws = new WebSocket(streamUrl);
        
        dataObj.ws.onmessage = (event) => {
            try {
                const parsed = JSON.parse(event.data); 
                if (!parsed.k) return;
                dataObj.lastWsUpdate = Date.now(); 
                const k = parsed.k;
                const t = Math.floor(k.t/1000), o = parseFloat(k.o), h = parseFloat(k.h), 
                      l = parseFloat(k.l), c = parseFloat(k.c), v = parseFloat(k.v);
                if (dataObj.lastCandleTime && t < dataObj.lastCandleTime) return; 
                dataObj.lastCandleTime = t;

                let isNew = dataObj.rawCandles.length > 0 && t > dataObj.rawCandles[dataObj.rawCandles.length - 1].time;
                const rawTick = { time: t, open: o, high: h, low: l, close: c, volume: v };
                if (isNew) { 
                    dataObj.rawCandles.push(rawTick); 
                    if (dataObj.rawCandles.length > 500) dataObj.rawCandles.shift(); 
                } else if (dataObj.rawCandles.length > 0) { 
                    dataObj.rawCandles[dataObj.rawCandles.length - 1] = rawTick; 
                }

                let haTick = { time: t }; 
                haTick.close = (o + h + l + c) / 4;
                if (isNew) { 
                    let prevHa = dataObj.haCandles[dataObj.haCandles.length - 1]; 
                    haTick.open = prevHa ? (prevHa.open + prevHa.close) / 2 : o; 
                } else { 
                    let prevHa = dataObj.haCandles.length > 1 ? dataObj.haCandles[dataObj.haCandles.length - 2] : { open: o, close: c }; 
                    haTick.open = prevHa ? (prevHa.open + prevHa.close) / 2 : o; 
                }
                haTick.high = Math.max(h, haTick.open, haTick.close); 
                haTick.low = Math.min(l, haTick.open, haTick.close);
                if (isNew) { 
                    dataObj.haCandles.push(haTick); 
                    if (dataObj.haCandles.length > 500) dataObj.haCandles.shift(); 
                } else { 
                    dataObj.haCandles[dataObj.haCandles.length - 1] = haTick; 
                }

                let activeTick = dataObj.chartType === 'heikin' ? haTick : rawTick; 
                dataObj.lastClose = activeTick.close; 
                let cleanTick = { time: activeTick.time, open: activeTick.open, high: activeTick.high, low: activeTick.low, close: activeTick.close };
                if (!dataObj.hasInitialData) { 
                    dataObj.series.setData([cleanTick]); 
                    dataObj.hasInitialData = true; 
                } else { 
                    dataObj.series.update(cleanTick); 
                }
                dataObj.candleMap.set(t, {o, h, l, c, v}); 
                if (!dataObj.crosshairActive) window.renderOHLCV(i, {o, h, l, c, v});
                
                if (isNew || !dataObj.lastRecalc || Date.now() - dataObj.lastRecalc > 1500) { 
                    dataObj.lastRecalc = Date.now(); 
                    if (window.recalculateAllIndicators) window.recalculateAllIndicators(i); 
                }
                window.syncTradeLabels(i);
            } catch(err) {}
        };
        
        dataObj.ws.onclose = () => setTimeout(() => window.connectSingleChartWS(i), 5000); 
        dataObj.ws.onerror = () => { if (dataObj.ws) dataObj.ws.close(); };
    }, i * 350);
};

window.connectSingleChartWS = function(i) {
    if (window.stopRestPolling) window.stopRestPolling(i);
    window._connectWsInternal(i);
    
    setTimeout(() => {
        const cObj = chartsData[i];
        if (!cObj) return;
        
        const noData = !cObj.lastWsUpdate || (Date.now() - cObj.lastWsUpdate) > 15000;
        const notOpen = !cObj.ws || cObj.ws.readyState !== 1;
        
        if (noData || notOpen) {
            console.log(`[WS] Chart ${i} WS çalışmıyor, REST polling başlatılıyor`);
            window.startRestPolling(i);
        }
    }, 15000);
};

// =============================================================
// GÖSTERGE AYAR MODALI
// =============================================================
window.toggleIndicatorModal = function() { document.getElementById('indicator-modal').classList.toggle('active'); };

window.openIndConfig = function(type, isEdit = false, editKey = null) {
    window.editingInd = isEdit ? { type, key: editKey } : { type, key: null };
    document.getElementById('ind-config-modal').classList.add('active');

    let html = ''; let cObj = chartsData[activeChartId]; let defaultParams = {}; let defaultColor = '#2962ff';
    if (isEdit) { let ind = cObj.indicators.get(editKey); if (ind) { defaultParams = ind.params || {}; defaultColor = ind.color; } }

    if (type === 'SMA' || type === 'EMA') {
        document.getElementById('config-title').innerText = `${type} Ayarları`; let p = defaultParams.period || 20;
        html += `<div style="display:flex; justify-content:space-between; align-items:center;"><span class="cfg-label">Uzunluk (Period)</span><input type="number" id="cfg-period" class="search-input" style="width:80px;" value="${p}"></div><div style="display:flex; justify-content:space-between; align-items:center;"><span class="cfg-label">Çizgi Rengi</span><input type="color" id="cfg-color" class="cfg-color-picker" value="${defaultColor}"></div>`;
    } else if (type === 'HULL_SRP') {
        document.getElementById('config-title').innerText = `HULL/Hl2 - SRP EXIT Ayarları`; let longTrade = defaultParams.longTrade !== undefined ? defaultParams.longTrade : true; let shortTrade = defaultParams.shortTrade !== undefined ? defaultParams.shortTrade : false; let source = defaultParams.source || 'hl2'; let period = defaultParams.period || 10;
        html += `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label">Long Trade</span><input type="checkbox" id="cfg-hull-long" ${longTrade ? 'checked' : ''}></div><div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label">Short Trade</span><input type="checkbox" id="cfg-hull-short" ${shortTrade ? 'checked' : ''}></div><div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label">Kaynak</span><select id="cfg-hull-src" class="search-input" style="width:100px;"><option value="hl2" ${source === 'hl2' ? 'selected' : ''}>(Y + D)/2</option><option value="close" ${source === 'close' ? 'selected' : ''}>Kapanış</option><option value="open" ${source === 'open' ? 'selected' : ''}>Açılış</option></select></div><div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label">HMA Length</span><input type="number" id="cfg-hull-len" class="search-input" style="width:80px;" value="${period}"></div>`;
    } else if (type === 'GRIDBOT') {
        document.getElementById('config-title').innerText = `GRIDBOT Scalper Ayarları`; let lback = defaultParams.lookback || 8;
        html += `<div style="display:flex; justify-content:space-between; align-items:center;"><span class="cfg-label">Geriye Dönük Tarama</span><input type="number" id="cfg-lookback" class="search-input" style="width:80px;" value="${lback}"></div>`;
    } else if (type === 'RSI_SCALPER') {
        document.getElementById('config-title').innerText = `RSI Scalper Ayarları`; let rsiPeriod = defaultParams.period || 7; let longOp = defaultParams.longOp || '<', longVal = defaultParams.longVal || 20; let shortOp = defaultParams.shortOp || '>', shortVal = defaultParams.shortVal || 80;
        html += `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label">RSI Period</span><input type="number" id="cfg-rsi-period" class="search-input" style="width:80px;" value="${rsiPeriod}"></div><div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label" style="color:#0ECB81; font-weight:bold;">LONG Operation</span><select id="cfg-rsi-long-op" class="search-input" style="width:80px;"><option value="<" ${longOp === '<' ? 'selected' : ''}>&lt;</option><option value=">" ${longOp === '>' ? 'selected' : ''}>&gt;</option></select></div><div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label" style="color:#0ECB81;">LONG Value</span><input type="number" id="cfg-rsi-long-val" class="search-input" style="width:80px;" value="${longVal}"></div><div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;"><span class="cfg-label" style="color:#F6465D; font-weight:bold;">SHORT Operation</span><select id="cfg-rsi-short-op" class="search-input" style="width:80px;"><option value="<" ${shortOp === '<' ? 'selected' : ''}>&lt;</option><option value=">" ${shortOp === '>' ? 'selected' : ''}>&gt;</option></select></div><div style="display:flex; justify-content:space-between; align-items:center;"><span class="cfg-label" style="color:#F6465D;">SHORT Value</span><input type="number" id="cfg-rsi-short-val" class="search-input" style="width:80px;" value="${shortVal}"></div>`;
    }
	
    document.getElementById('config-body').innerHTML = html;
    let submitBtn = document.querySelector('#ind-config-modal .btn-green'); if(submitBtn) { submitBtn.onclick = function() { window.saveConfigParams(); }; }
};

window.closeConfigModal = function() { document.getElementById('ind-config-modal').classList.remove('active'); };

window.saveConfigParams = function() {
    if (!window.editingInd) return; let type = window.editingInd.type; let cObj = chartsData[activeChartId]; if (!cObj || !cObj.chart) return;
    let params = {}; let color = '#2962ff'; let isMarker = false; let nameStr = type;

    if (type === 'SMA' || type === 'EMA') {
        params.period = parseInt(document.getElementById('cfg-period').value) || 20; color = document.getElementById('cfg-color').value;
    } else if (type === 'HULL_SRP') {
        params.longTrade = document.getElementById('cfg-hull-long').checked; params.shortTrade = document.getElementById('cfg-hull-short').checked; params.source = document.getElementById('cfg-hull-src').value; params.period = parseInt(document.getElementById('cfg-hull-len').value) || 10; isMarker = true; nameStr = `HULL/Hl2 (${params.period})`;
    } else if (type === 'GRIDBOT') {
        params.lookback = parseInt(document.getElementById('cfg-lookback').value) || 8; isMarker = true; nameStr = 'GRIDBOT Scalper';
    } else if (type === 'RSI_SCALPER') {
        params.period = parseInt(document.getElementById('cfg-rsi-period').value) || 7; params.longOp = document.getElementById('cfg-rsi-long-op').value; params.longVal = parseInt(document.getElementById('cfg-rsi-long-val').value) || 20; params.shortOp = document.getElementById('cfg-rsi-short-op').value; params.shortVal = parseInt(document.getElementById('cfg-rsi-short-val').value) || 80; isMarker = true; nameStr = `RSI Scalper (L:${params.longOp}${params.longVal} S:${params.shortOp}${params.shortVal})`;
    }

    let newKey = `${type}_${Date.now()}`; if (window.editingInd.key) window.removeIndicator(activeChartId, window.editingInd.key);

    if (!isMarker) { const lineSeries = cObj.chart.addLineSeries({ color: color, lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); cObj.indicators.set(newKey, { type, params, color, series: lineSeries, isMarker: false, hidden: false }); } 
    else { cObj.indicators.set(newKey, { type: type, name: nameStr, params, isMarker: true, hidden: false }); }

    window.recalculateAllIndicators(activeChartId); window.saveChartsState(); window.closeConfigModal();
};

window.saveConfig = function() { if (typeof window.saveConfigParams === "function") { window.saveConfigParams(); } };
window.toggleIndicatorVisibility = function(chartIdx, indKey) { const cObj = chartsData[chartIdx]; if (!cObj || !cObj.indicators.has(indKey)) return; const ind = cObj.indicators.get(indKey); ind.hidden = !ind.hidden; window.recalculateAllIndicators(chartIdx); window.saveChartsState(); };

window.removeIndicator = function(chartIdx, indKey) {
    const cObj = chartsData[chartIdx]; if (!cObj || !cObj.indicators.has(indKey)) return; const ind = cObj.indicators.get(indKey);
    if (ind.isMarker) { cObj.series.setMarkers(cObj.tradeMarkers || []); cObj.strategyMarkers = []; cObj.lastTrade = null; window.clearTradeLabels(chartIdx); if (cObj.tradeLineSeriesArr) { cObj.tradeLineSeriesArr.forEach(ls => { try { cObj.chart.removeSeries(ls); } catch(e){} }); cObj.tradeLineSeriesArr = []; } } 
    else { if (ind.series) cObj.chart.removeSeries(ind.series); }
    cObj.indicators.delete(indKey); window.recalculateAllIndicators(chartIdx); window.refreshBottomPanel(); window.saveChartsState();
};

window.recalculateAllIndicators = function(idx) {
    const cObj = chartsData[idx]; if (!cObj || cObj.rawCandles.length === 0) return;
    cObj.lastTrade = null; cObj.strategyMarkers = []; cObj.tradeLabels = []; window.clearTradeLabels(idx); let hasStrategy = false;

    cObj.indicators.forEach((val) => {
        if (!val.isMarker) {
            if (!val.series) { val.series = cObj.chart.addLineSeries({ color: val.color, lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); }
            let indData = val.type === 'SMA' ? window.calcIndicatorSMA(cObj.rawCandles, val.params.period) : window.calcIndicatorEMA(cObj.rawCandles, val.params.period);
            val.series.setData(indData); val.series.applyOptions({ visible: !val.hidden });
        } else {
            hasStrategy = true; let result;
            if (val.type === 'HULL_SRP') result = window.calcHullSRP(cObj.rawCandles, val.params, cObj);
            else if (val.type === 'GRIDBOT') result = window.calcGridbotScalper(cObj.rawCandles, val.params, cObj);
            else if (val.type === 'RSI_SCALPER') result = window.calcRSIScalper(cObj.rawCandles, val.params, cObj);

            if (result) {
                if (!val.hidden) { cObj.strategyMarkers = cObj.strategyMarkers.concat(result.markers || []); cObj.tradeLabels = cObj.tradeLabels.concat(result.tradeLabels || []); }
                else { if (cObj.tradeLineSeriesArr && cObj.tradeLineSeriesArr.length > 0) { cObj.tradeLineSeriesArr.forEach(ls => { try { cObj.chart.removeSeries(ls); } catch(e){} }); cObj.tradeLineSeriesArr = []; } }
                if (result.lastTrade) cObj.lastTrade = result.lastTrade;
            }
        }
    });

    const userMarkers = (cObj.userTrades && cObj.userTrades.markers) ? cObj.userTrades.markers : [];
    let allM = [...(cObj.strategyMarkers||[]), ...(cObj.tradeMarkers||[]), ...userMarkers].sort((a,b)=>a.time - b.time);
    
    // ⚡ GRID aktif mi kontrol et
    let hasGrid = false;
    cObj.indicators.forEach(function(v) {
        if (v.type === 'GRIDBOT' && !v.hidden) hasGrid = true;
    });
    
    // Grid aktifse ve dim modu aciksa markerlari soluklastir
    if (hasGrid) {
        const dimOn = (cObj.gridDimMode !== undefined) ? cObj.gridDimMode : window._gridDimDefault;
        if (dimOn) {
            allM = allM.map(function(m) {
                return Object.assign({}, m, {
                    color: window._dimColor(m.color, 0.25)
                });
            });
        }
    }
    
    cObj.series.setMarkers(allM);
    
    // Grid toggle butonunu guncelle
    const gridBtn = document.getElementById('grid-toggle-' + idx);
    if (gridBtn) {
        if (hasGrid) {
            const dimOn = (cObj.gridDimMode !== undefined) ? cObj.gridDimMode : window._gridDimDefault;
            gridBtn.style.display = 'inline-block';
            gridBtn.style.opacity = dimOn ? '1' : '0.35';
            gridBtn.style.color = dimOn ? '#79a0ff' : '#5d6471';
            gridBtn.title = dimOn 
                ? 'Grid vurgusu AÇIK (tikla: markerlari geri getir)' 
                : 'Grid vurgusu KAPALI (tikla: markerlari soluklastir)';
        } else {
            gridBtn.style.display = 'none';
        }
    }
    
    window.syncTradeLabels(idx); window.renderActiveIndicatorsLog(idx);
    if (hasStrategy && botConfig.active) {
        if (cObj.lastTrade) globalPositions.set(cObj.symbol, cObj.lastTrade); else globalPositions.delete(cObj.symbol);
        let minimalPos = Array.from(globalPositions.entries()).map(([sym, t]) => [sym, { type: t.type, entryPrice: t.entryPrice, avgPrice: t.avgPrice, entryTime: t.entryTime, totalVol: t.totalVol, dcaCount: t.dcaCount }]); try { localStorage.setItem('cryptoGlobalPos_v1', JSON.stringify(minimalPos)); } catch(e) {}
    }
};

window.renderActiveIndicatorsLog = function(idx) {
    const cObj = chartsData[idx]; const logEl = document.getElementById(`active-inds-${idx}`); if (!logEl || !cObj) return; let html = '';
    cObj.indicators.forEach((val, key) => {
        const eyeStyle = val.hidden ? "opacity:0.35; filter:grayscale(1);" : "opacity:0.9;"; const eyeTitle = val.hidden ? "Göster" : "Gizle";
        if (!val.isMarker) {
            let lastVal = "--"; if (val.series) { const data = val.series.data(); if (data && data.length > 0) lastVal = window.formatPrice(data[data.length-1].value); }
            html += `<div class="active-ind-item" style="color:${val.color}">${val.type} ${val.params.period} <span class="active-ind-val">${lastVal}</span><span class="ind-eye" onclick="window.toggleIndicatorVisibility(${idx}, '${key}')" title="${eyeTitle}" style="cursor:pointer; margin-left:6px; font-size:12px; ${eyeStyle}">👁️</span><span class="ind-gear" onclick="window.openIndConfig('${val.type}', true, '${key}')" title="Ayarlar">⚙️</span><span class="ind-remove" onclick="window.removeIndicator(${idx}, '${key}')" title="Kaldır">✕</span></div>`;
        } else {
            html += `<div class="active-ind-item" style="color:#ff9800">${val.name} <span class="ind-eye" onclick="window.toggleIndicatorVisibility(${idx}, '${key}')" title="${eyeTitle}" style="cursor:pointer; margin-left:6px; font-size:12px; ${eyeStyle}">👁️</span><span class="ind-gear" onclick="window.openIndConfig('${val.type}', true, '${key}')" title="Ayarlar">⚙️</span><span class="ind-remove" onclick="window.removeIndicator(${idx}, '${key}')" title="Kaldır">✕</span></div>`;
        }
    });
    logEl.innerHTML = html;
};

// =============================================================
// MATEMATİK & GÖSTERGELER
// =============================================================
window.calcIndicatorSMA = function(data, period) { let result = []; for(let i=0; i < data.length; i++) { if (i < period - 1) continue; let sum = 0; for(let j=0; j < period; j++) sum += data[i-j].close; result.push({ time: data[i].time, value: sum / period }); } return result; };
window.calcIndicatorEMA = function(data, period) { let result = []; if (data.length < period) return result; let multiplier = 2 / (period + 1); let sum = 0; for(let i=0; i < period; i++) sum += data[i].close; let ema = sum / period; result.push({ time: data[period-1].time, value: ema }); for(let i=period; i < data.length; i++) { ema = (data[i].close - ema) * multiplier + ema; result.push({ time: data[i].time, value: ema }); } return result; };
window.calcWMA = function(data, period) { let result = []; let norm = (period * (period + 1)) / 2; for(let i=0; i<data.length; i++) { if (data[i] === null || data[i] === undefined) { result.push(null); continue; } let valid = true, sum = 0; for(let j=0; j<period; j++) { if (i - j < 0 || data[i - j] === null || data[i - j] === undefined) { valid = false; break; } sum += data[i - j] * (period - j); } result.push(valid ? sum / norm : null); } return result; };
window.calcHMA = function(data, period) { let halfLength = Math.round(period / 2); let sqnLength = Math.round(Math.sqrt(period)); let wmaFull = window.calcWMA(data, period); let wmaHalf = window.calcWMA(data, halfLength); let diff = []; for(let i=0; i<data.length; i++) { if (wmaFull[i] === null || wmaHalf[i] === null) diff.push(null); else diff.push((2 * wmaHalf[i]) - wmaFull[i]); } return window.calcWMA(diff, sqnLength); };
window.calcRSI = function(data, period = 14) { let rsiData = []; if (data.length <= period) return rsiData; let gains = 0, losses = 0; for (let i = 1; i <= period; i++) { let diff = data[i].close - data[i - 1].close; if (diff >= 0) gains += diff; else losses -= diff; } let avgGain = gains / period, avgLoss = losses / period; for(let i=0; i < period; i++) rsiData.push(null); let rs = avgLoss === 0 ? 100 : avgGain / avgLoss; rsiData.push(100 - (100 / (1 + rs))); for (let i = period + 1; i < data.length; i++) { let diff = data[i].close - data[i - 1].close; let gain = diff >= 0 ? diff : 0; let loss = diff < 0 ? -diff : 0; avgGain = ((avgGain * (period - 1)) + gain) / period; avgLoss = ((avgLoss * (period - 1)) + loss) / period; rs = avgLoss === 0 ? 100 : avgGain / avgLoss; rsiData.push(100 - (100 / (1 + rs))); } return rsiData; };

// =============================================================
// BACKEND SİNYAL GÖNDERİMİ
// =============================================================
let dispatchedTrades = new Set();
window.triggerBackendOpen = function(symbol, tradeType, candleTime, stratParams = null) {
    if (!symbol) return; const cleanSym = symbol.replace('.P', ''); const key = `OPEN_${cleanSym}_${tradeType}_${candleTime}`; if (dispatchedTrades.has(key)) return; dispatchedTrades.add(key);
    const side = tradeType === 'LONG' ? 'BUY' : 'SELL'; let url = `/api/trade/open?symbol=${cleanSym}&side=${side}`; if (stratParams && stratParams.baseOrder) url += `&amount=${stratParams.baseOrder}&tp=${stratParams.takeProfit || 1.5}&trailing=${stratParams.trailing || 0.3}`; fetch(url, { method: 'POST' }).then(res => res.json()).then(data => { console.log(`[BOT] Giriş:`, data); }).catch(err => {});
};
window.triggerBackendClose = function(symbol, candleTime) {
    if (!symbol) return; const cleanSym = symbol.replace('.P', ''); const key = `CLOSE_${cleanSym}_${candleTime}`; if (dispatchedTrades.has(key)) return; dispatchedTrades.add(key); fetch(`/api/trade/close?symbol=${cleanSym}`, { method: 'POST' }).then(res => res.json()).then(data => { console.log(`[BOT] Çıkış:`, data); }).catch(err => {});
};

// =============================================================
// STRATEJİ: HULL SRP
// =============================================================
window.calcHullSRP = function(data, params, cObj, isBackground = false) {
    if (!cObj.tradeLineSeriesArr) cObj.tradeLineSeriesArr = []; if (!cObj.tradeLabels) cObj.tradeLabels = []; let markers = []; let tradeLabels = []; let activeTrade = null; let tradeCounter = 1; let generatedHistory = [];
    let sCfg = window.getStrategyBotConfig('HULL_SRP', params); let tpPct = (parseFloat(sCfg.takeProfit) || 2.0) / 100; let trailingPct = (parseFloat(sCfg.trailing) || 0.5) / 100; let baseOrder = parseFloat(sCfg.baseOrder) || 10; let stepsArr = sCfg.steps ? sCfg.steps.split(',').map(s => parseFloat(s.trim())).filter(s => !isNaN(s)) : []; let useDCA = sCfg.useDCA; let volMultiplier = sCfg.volMultiplier;

    if (cObj.chart && cObj.tradeLineSeriesArr) { cObj.tradeLineSeriesArr.forEach(ls => { try { cObj.chart.removeSeries(ls); } catch(e){} }); cObj.tradeLineSeriesArr = []; }
    let srcData = data.map(d => { if (params.source === 'hl2') return (d.high + d.low) / 2; if (params.source === 'open') return d.open; return d.close; }); let hma = window.calcHMA(srcData, params.period || 10); let lineData = [];

    for (let i = 2; i < data.length; i++) {
        let candle = data[i], val = hma[i], prevVal = hma[i-1], prev2Val = hma[i-2]; if (val === null || prevVal === null || prev2Val === null) continue;
        let isRising = val > prevVal, color = isRising ? '#00ff08' : '#ff0000'; lineData.push({ time: candle.time, value: val, color: color }); let turnGreen = isRising && prevVal <= prev2Val, turnRed = !isRising && prevVal > prev2Val;

        if (activeTrade) {
            let isLong = activeTrade.type === 'LONG', profitPct = isLong ? (candle.high - activeTrade.avgPrice) / activeTrade.avgPrice : (activeTrade.avgPrice - candle.low) / activeTrade.avgPrice;
            if (!activeTrade.ttpActive && profitPct >= tpPct) { activeTrade.ttpActive = true; activeTrade.hwm = isLong ? candle.high : candle.low; }
            if (activeTrade.ttpActive) {
                let triggerPrice; if (isLong) { if (candle.high > activeTrade.hwm) activeTrade.hwm = candle.high; triggerPrice = activeTrade.hwm * (1 - trailingPct); } else { if (candle.low < activeTrade.hwm) activeTrade.hwm = candle.low; triggerPrice = activeTrade.hwm * (1 + trailingPct); }
                let isExit = false; if (isLong && candle.low <= triggerPrice) isExit = true; if (!isLong && candle.high >= triggerPrice) isExit = true;
                if (isExit) {
                    let exitPrice = triggerPrice, finalPct = isLong ? (exitPrice - activeTrade.avgPrice) / activeTrade.avgPrice : (activeTrade.avgPrice - exitPrice) / activeTrade.avgPrice, netPnl = (activeTrade.totalVol * finalPct) - (activeTrade.totalVol * 0.001), pnlSign = netPnl >= 0 ? '+' : '', pnlClass = netPnl >= 0 ? 'profit' : 'loss';
                    markers.push({ time: candle.time, position: isLong ? 'aboveBar' : 'belowBar', color: '#FCD535', shape: 'circle', size: 1 });
                    tradeLabels.push({ time: candle.time, price: isLong ? candle.high : candle.low, linePrice: exitPrice, text: `Çıkış ${window.formatPrice(exitPrice)}<br><span style="color:${netPnl >= 0 ? '#0ECB81' : '#F6465D'}; font-weight:bold;">${pnlSign}${(finalPct*100).toFixed(2)}%</span>`, type: activeTrade.type, isExit: true, pnlClass: pnlClass, position: isLong ? 'aboveBar' : 'belowBar', colorClass: 'exit' });
                    if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: exitPrice}, {time: candle.time, value: exitPrice}]); cObj.tradeLineSeriesArr.push(ls); activeTrade.avgLineData.push({time: candle.time, value: activeTrade.avgPrice}); let lsAvg = cObj.chart.addLineSeries({ color: '#848e9c', lineWidth: 1, lineStyle: 3, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); lsAvg.setData(activeTrade.avgLineData); cObj.tradeLineSeriesArr.push(lsAvg); }
                    let nowSec = Math.floor(Date.now() / 1000); if (nowSec - candle.time <= 86400 * 3) { generatedHistory.push({ id: `${cObj.symbol}_HULL_${activeTrade.entryTime}`, symbol: cObj.symbol, type: activeTrade.type, baseOrder: activeTrade.totalVol, entryPrice: activeTrade.avgPrice, exitPrice: exitPrice, pnlPct: finalPct * 100, netPnl: netPnl, entryTime: activeTrade.entryTime, exitTime: candle.time }); }
                    if (!isBackground && i === data.length - 1 && Math.abs(nowSec - candle.time) <= window.getIntervalSeconds(cObj.interval) * 2) { window.triggerBackendClose(cObj.symbol, candle.time); } activeTrade = null; continue;
                }
            }
            if (activeTrade && useDCA && activeTrade.dcaCount < stepsArr.length) {
                while (activeTrade && activeTrade.dcaCount < stepsArr.length) {
                    let nextStepThreshold = stepsArr[activeTrade.dcaCount], triggerPrice = isLong ? activeTrade.entryPrice * (1 - nextStepThreshold/100) : activeTrade.entryPrice * (1 + nextStepThreshold/100), hitDCA = false;
                    if (isLong && candle.low <= triggerPrice) hitDCA = true; if (!isLong && candle.high >= triggerPrice) hitDCA = true;
                    if (hitDCA) {
                        activeTrade.dcaCount++; let stepVol = baseOrder * Math.pow(volMultiplier, activeTrade.dcaCount), fillPrice = triggerPrice, newTotalVol = activeTrade.totalVol + stepVol; activeTrade.avgPrice = ((activeTrade.avgPrice * activeTrade.totalVol) + (fillPrice * stepVol)) / newTotalVol; activeTrade.totalVol = newTotalVol;
                        markers.push({ time: candle.time, position: isLong ? 'belowBar' : 'aboveBar', color: isLong ? '#0ECB81' : '#F6465D', shape: 'circle', size: 1 });
                        tradeLabels.push({ time: candle.time, price: isLong ? candle.low : candle.high, linePrice: fillPrice, text: `Kademe #${activeTrade.dcaCount}<br>${window.formatPrice(fillPrice)}`, type: activeTrade.type, isExit: false, position: isLong ? 'belowBar' : 'aboveBar', colorClass: isLong ? 'long-entry' : 'short-entry' });
                        if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: fillPrice}, {time: candle.time, value: fillPrice}]); cObj.tradeLineSeriesArr.push(ls); }
                        tradeLabels.push({ time: candle.time, price: activeTrade.avgPrice, linePrice: activeTrade.avgPrice, text: `Ort: ${window.formatPrice(activeTrade.avgPrice)}`, type: 'AVG', isExit: false, position: 'onLine', colorClass: 'avg-label' });
                    } else { break; }
                }
            }
            if (activeTrade) { let lastData = activeTrade.avgLineData[activeTrade.avgLineData.length - 1]; if (lastData && lastData.time === candle.time) { lastData.value = activeTrade.avgPrice; } else { activeTrade.avgLineData.push({time: candle.time, value: activeTrade.avgPrice}); } }
        }

        if (!activeTrade) {
            let triggerSignal = false; let tradeType = ''; if (turnGreen && params.longTrade) { triggerSignal = true; tradeType = 'LONG'; } else if (turnRed && params.shortTrade) { triggerSignal = true; tradeType = 'SHORT'; }
            if (triggerSignal) {
                if (tradeType === 'LONG') { markers.push({ time: candle.time, position: 'belowBar', color: '#0ECB81', shape: 'circle', size: 0.5 }); tradeLabels.push({ time: candle.time, price: candle.low, linePrice: candle.close, text: `Giriş #${tradeCounter}<br>${window.formatPrice(candle.close)}`, type: 'LONG', isExit: false, position: 'belowBar', colorClass: 'long-entry' }); } 
                else { markers.push({ time: candle.time, position: 'aboveBar', color: '#F6465D', shape: 'circle', size: 0.5 }); tradeLabels.push({ time: candle.time, price: candle.high, linePrice: candle.close, text: `Giriş #${tradeCounter}<br>${window.formatPrice(candle.close)}`, type: 'SHORT', isExit: false, position: 'aboveBar', colorClass: 'short-entry' }); }
                if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: candle.close}, {time: candle.time, value: candle.close}]); cObj.tradeLineSeriesArr.push(ls); }
                tradeLabels.push({ time: candle.time, price: candle.close, linePrice: candle.close, text: `Ort: ${window.formatPrice(candle.close)}`, type: 'AVG', isExit: false, position: 'onLine', colorClass: 'avg-label' });
                let nowSec = Math.floor(Date.now() / 1000); if (!isBackground && i === data.length - 1 && Math.abs(nowSec - candle.time) <= window.getIntervalSeconds(cObj.interval) * 2) { window.triggerBackendOpen(cObj.symbol, tradeType, candle.time, sCfg); }
                activeTrade = { type: tradeType, entryPrice: candle.close, avgPrice: candle.close, entryTime: candle.time, ttpActive: false, totalVol: baseOrder, dcaCount: 0, tradeId: tradeCounter, avgLineData: [{time: candle.time, value: candle.close}] }; tradeCounter++;
            }
        }
    }
    if (cObj.chart && !isBackground && lineData.length > 0) { let lsHma = cObj.chart.addLineSeries({ lineWidth: 3, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); lsHma.setData(lineData); cObj.tradeLineSeriesArr.push(lsHma); }
    if (activeTrade && activeTrade.avgLineData.length > 0 && cObj.chart) { let lsAvg = cObj.chart.addLineSeries({ color: '#848e9c', lineWidth: 1, lineStyle: 3, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); lsAvg.setData(activeTrade.avgLineData); cObj.tradeLineSeriesArr.push(lsAvg); }
    window.syncHistoricalTrades(generatedHistory); return { markers, lastTrade: activeTrade, tradeLabels: tradeLabels };
};

// =============================================================
// STRATEJİ: RSI SCALPER
// =============================================================
window.calcRSIScalper = function(data, params, cObj, isBackground = false) {
    if (!cObj.tradeLineSeriesArr) cObj.tradeLineSeriesArr = []; if (!cObj.tradeLabels) cObj.tradeLabels = []; let markers = []; let rsiArray = window.calcRSI(data, params.period); let activeTrade = null; let tradeCounter = 1; let generatedHistory = []; let tradeLabels = [];
    let sCfg = window.getStrategyBotConfig('RSI_SCALPER', params); let tpPct = (parseFloat(sCfg.takeProfit) || 1.5) / 100; let trailingPct = (parseFloat(sCfg.trailing) || 0.3) / 100; let baseOrder = parseFloat(sCfg.baseOrder) || 10; let stepsArr = sCfg.steps ? sCfg.steps.split(',').map(s => parseFloat(s.trim())).filter(s => !isNaN(s)) : []; let useDCA = sCfg.useDCA; let volMultiplier = sCfg.volMultiplier;
    if (cObj.chart && cObj.tradeLineSeriesArr) { cObj.tradeLineSeriesArr.forEach(ls => { try { cObj.chart.removeSeries(ls); } catch(e){} }); cObj.tradeLineSeriesArr = []; }

    for (let i = params.period; i < data.length; i++) {
        let candle = data[i];

        if (activeTrade) {
            let isLong = activeTrade.type === 'LONG', profitPct = isLong ? (candle.high - activeTrade.avgPrice) / activeTrade.avgPrice : (activeTrade.avgPrice - candle.low) / activeTrade.avgPrice;
            if (!activeTrade.ttpActive && profitPct >= tpPct) { activeTrade.ttpActive = true; activeTrade.hwm = isLong ? candle.high : candle.low; }
            if (activeTrade.ttpActive) {
                let triggerPrice; if (isLong) { if (candle.high > activeTrade.hwm) activeTrade.hwm = candle.high; triggerPrice = activeTrade.hwm * (1 - trailingPct); } else { if (candle.low < activeTrade.hwm) activeTrade.hwm = candle.low; triggerPrice = activeTrade.hwm * (1 + trailingPct); }
                let isExit = false; if (isLong && candle.low <= triggerPrice) isExit = true; if (!isLong && candle.high >= triggerPrice) isExit = true;
                if (isExit) {
                    let exitPrice = triggerPrice, finalPct = isLong ? (exitPrice - activeTrade.avgPrice) / activeTrade.avgPrice : (activeTrade.avgPrice - exitPrice) / activeTrade.avgPrice, netPnl = (activeTrade.totalVol * finalPct) - (activeTrade.totalVol * 0.001), pnlSign = netPnl >= 0 ? '+' : '', pnlClass = netPnl >= 0 ? 'profit' : 'loss';
                    markers.push({ time: candle.time, position: isLong ? 'aboveBar' : 'belowBar', color: '#FCD535', shape: 'circle', size: 1 });
                    tradeLabels.push({ time: candle.time, price: isLong ? candle.high : candle.low, linePrice: exitPrice, text: `Çıkış ${window.formatPrice(exitPrice)}<br><span style="color:${netPnl >= 0 ? '#0ECB81' : '#F6465D'}; font-weight:bold;">${pnlSign}${(finalPct*100).toFixed(2)}%</span>`, type: activeTrade.type, isExit: true, pnlClass: pnlClass, position: isLong ? 'aboveBar' : 'belowBar', colorClass: 'exit' });
                    if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: exitPrice}, {time: candle.time, value: exitPrice}]); cObj.tradeLineSeriesArr.push(ls); activeTrade.avgLineData.push({time: candle.time, value: activeTrade.avgPrice}); let lsAvg = cObj.chart.addLineSeries({ color: '#848e9c', lineWidth: 1, lineStyle: 3, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); lsAvg.setData(activeTrade.avgLineData); cObj.tradeLineSeriesArr.push(lsAvg); }
                    let nowSec = Math.floor(Date.now() / 1000); if (nowSec - candle.time <= 86400 * 3) { generatedHistory.push({ id: `${cObj.symbol}_RSIS_${activeTrade.entryTime}`, symbol: cObj.symbol, type: activeTrade.type, baseOrder: activeTrade.totalVol, entryPrice: activeTrade.avgPrice, exitPrice: exitPrice, pnlPct: finalPct * 100, netPnl: netPnl, entryTime: activeTrade.entryTime, exitTime: candle.time }); }
                    if (!isBackground && i === data.length - 1 && Math.abs(nowSec - candle.time) <= window.getIntervalSeconds(cObj.interval) * 2) { window.triggerBackendClose(cObj.symbol, candle.time); } activeTrade = null; continue;
                }
            }
            if (activeTrade && useDCA && activeTrade.dcaCount < stepsArr.length) {
                while (activeTrade && activeTrade.dcaCount < stepsArr.length) {
                    let nextStepThreshold = stepsArr[activeTrade.dcaCount], triggerPrice = isLong ? activeTrade.entryPrice * (1 - nextStepThreshold/100) : activeTrade.entryPrice * (1 + nextStepThreshold/100), hitDCA = false;
                    if (isLong && candle.low <= triggerPrice) hitDCA = true; if (!isLong && candle.high >= triggerPrice) hitDCA = true;
                    if (hitDCA) {
                        activeTrade.dcaCount++; let stepVol = baseOrder * Math.pow(volMultiplier, activeTrade.dcaCount), fillPrice = triggerPrice, newTotalVol = activeTrade.totalVol + stepVol; activeTrade.avgPrice = ((activeTrade.avgPrice * activeTrade.totalVol) + (fillPrice * stepVol)) / newTotalVol; activeTrade.totalVol = newTotalVol;
                        markers.push({ time: candle.time, position: isLong ? 'belowBar' : 'aboveBar', color: isLong ? '#0ECB81' : '#F6465D', shape: 'circle', size: 1 });
                        tradeLabels.push({ time: candle.time, price: isLong ? candle.low : candle.high, linePrice: fillPrice, text: `Kademe #${activeTrade.dcaCount}<br>${window.formatPrice(fillPrice)}`, type: activeTrade.type, isExit: false, position: isLong ? 'belowBar' : 'aboveBar', colorClass: isLong ? 'long-entry' : 'short-entry' });
                        if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: fillPrice}, {time: candle.time, value: fillPrice}]); cObj.tradeLineSeriesArr.push(ls); }
                        tradeLabels.push({ time: candle.time, price: activeTrade.avgPrice, linePrice: activeTrade.avgPrice, text: `Ort: ${window.formatPrice(activeTrade.avgPrice)}`, type: 'AVG', isExit: false, position: 'onLine', colorClass: 'avg-label' });
                    } else { break; }
                }
            }
            if (activeTrade) { let lastData = activeTrade.avgLineData[activeTrade.avgLineData.length - 1]; if (lastData && lastData.time === candle.time) { lastData.value = activeTrade.avgPrice; } else { activeTrade.avgLineData.push({time: candle.time, value: activeTrade.avgPrice}); } }
        }

        if (!activeTrade) {
            let currentRSI = rsiArray[i], previousRSI = rsiArray[i-1]; if (currentRSI === null || previousRSI === null) continue;
            let triggerSignal = false, tradeType = '', checkLong = false; if (params.longOp === '<' && currentRSI < params.longVal && previousRSI >= params.longVal) checkLong = true; if (params.longOp === '>' && currentRSI > params.longVal && previousRSI <= params.longVal) checkLong = true;
            let checkShort = false; if (params.shortOp === '<' && currentRSI < params.shortVal && previousRSI >= params.shortVal) checkShort = true; if (params.shortOp === '>' && currentRSI > params.shortVal && previousRSI <= params.shortVal) checkShort = true;
            if (checkLong) { triggerSignal = true; tradeType = 'LONG'; } else if (checkShort) { triggerSignal = true; tradeType = 'SHORT'; }

            if (triggerSignal) {
                if (tradeType === 'LONG') { markers.push({ time: candle.time, position: 'belowBar', color: '#0ECB81', shape: 'arrowUp', size: 1 }); tradeLabels.push({ time: candle.time, price: candle.low, linePrice: candle.close, text: `Giriş #${tradeCounter}<br>${window.formatPrice(candle.close)}`, type: 'LONG', isExit: false, position: 'belowBar', colorClass: 'long-entry' }); } 
                else { markers.push({ time: candle.time, position: 'aboveBar', color: '#F6465D', shape: 'arrowDown', size: 1 }); tradeLabels.push({ time: candle.time, price: candle.high, linePrice: candle.close, text: `Giriş #${tradeCounter}<br>${window.formatPrice(candle.close)}`, type: 'SHORT', isExit: false, position: 'aboveBar', colorClass: 'short-entry' }); }
                if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: candle.close}, {time: candle.time, value: candle.close}]); cObj.tradeLineSeriesArr.push(ls); }
                tradeLabels.push({ time: candle.time, price: candle.close, linePrice: candle.close, text: `Ort: ${window.formatPrice(candle.close)}`, type: 'AVG', isExit: false, position: 'onLine', colorClass: 'avg-label' });
                let nowSec = Math.floor(Date.now() / 1000); if (!isBackground && i === data.length - 1 && Math.abs(nowSec - candle.time) <= window.getIntervalSeconds(cObj.interval) * 2) { window.triggerBackendOpen(cObj.symbol, tradeType, candle.time, sCfg); }
                activeTrade = { type: tradeType, entryPrice: candle.close, avgPrice: candle.close, entryTime: candle.time, ttpActive: false, totalVol: baseOrder, dcaCount: 0, tradeId: tradeCounter, avgLineData: [{time: candle.time, value: candle.close}] }; tradeCounter++;
            }
        }
    }
    if (activeTrade && activeTrade.avgLineData.length > 0 && cObj.chart) { let lsAvg = cObj.chart.addLineSeries({ color: '#848e9c', lineWidth: 1, lineStyle: 3, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); lsAvg.setData(activeTrade.avgLineData); cObj.tradeLineSeriesArr.push(lsAvg); }
    window.syncHistoricalTrades(generatedHistory); return { markers, lastTrade: activeTrade, tradeLabels: tradeLabels };
};

// =============================================================
// STRATEJİ: GRIDBOT
// =============================================================
window.calcGridbotScalper = function(data, params, cObj, isBackground = false) {
    if (!cObj.tradeLineSeriesArr) cObj.tradeLineSeriesArr = []; if (!cObj.tradeLabels) cObj.tradeLabels = []; let markers = []; let leftLen = params.lookback || 8; let rightLen = params.lookback || 8; let activeTrade = null; let tradeCounter = 1; let generatedHistory = []; let tradeLabels = [];
    let sCfg = window.getStrategyBotConfig('GRIDBOT', params); let tpPct = (parseFloat(sCfg.takeProfit) || 1.0) / 100; let trailingPct = (parseFloat(sCfg.trailing) || 0.2) / 100; let baseOrder = parseFloat(sCfg.baseOrder) || 10; let stepsArr = sCfg.steps ? sCfg.steps.split(',').map(s => parseFloat(s.trim())).filter(s => !isNaN(s)) : []; let useDCA = sCfg.useDCA; let volMultiplier = sCfg.volMultiplier;
    if (cObj.chart && cObj.tradeLineSeriesArr) { cObj.tradeLineSeriesArr.forEach(ls => { try { cObj.chart.removeSeries(ls); } catch(e){} }); cObj.tradeLineSeriesArr = []; }

    for (let i = leftLen + rightLen; i < data.length; i++) {
        let candle = data[i];

        if (activeTrade) {
            let isLong = activeTrade.type === 'LONG', profitPct = isLong ? (candle.high - activeTrade.avgPrice) / activeTrade.avgPrice : (activeTrade.avgPrice - candle.low) / activeTrade.avgPrice;
            if (!activeTrade.ttpActive && profitPct >= tpPct) { activeTrade.ttpActive = true; activeTrade.hwm = isLong ? candle.high : candle.low; }
            if (activeTrade.ttpActive) {
                let triggerPrice; if (isLong) { if (candle.high > activeTrade.hwm) activeTrade.hwm = candle.high; triggerPrice = activeTrade.hwm * (1 - trailingPct); } else { if (candle.low < activeTrade.hwm) activeTrade.hwm = candle.low; triggerPrice = activeTrade.hwm * (1 + trailingPct); }
                let isExit = false; if (isLong && candle.low <= triggerPrice) isExit = true; if (!isLong && candle.high >= triggerPrice) isExit = true;
                if (isExit) {
                    let exitPrice = triggerPrice, finalPct = isLong ? (exitPrice - activeTrade.avgPrice) / activeTrade.avgPrice : (activeTrade.avgPrice - exitPrice) / activeTrade.avgPrice, netPnl = (activeTrade.totalVol * finalPct) - (activeTrade.totalVol * 0.001), pnlSign = netPnl >= 0 ? '+' : '', pnlClass = netPnl >= 0 ? 'profit' : 'loss';
                    markers.push({ time: candle.time, position: isLong ? 'aboveBar' : 'belowBar', color: '#FCD535', shape: 'circle', size: 1 });
                    tradeLabels.push({ time: candle.time, price: isLong ? candle.high : candle.low, linePrice: exitPrice, text: `Çıkış ${window.formatPrice(exitPrice)}<br><span style="color:${netPnl >= 0 ? '#0ECB81' : '#F6465D'}; font-weight:bold;">${pnlSign}${(finalPct*100).toFixed(2)}%</span>`, type: activeTrade.type, isExit: true, pnlClass: pnlClass, position: isLong ? 'aboveBar' : 'belowBar', colorClass: 'exit' });
                    if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: exitPrice}, {time: candle.time, value: exitPrice}]); cObj.tradeLineSeriesArr.push(ls); activeTrade.avgLineData.push({time: candle.time, value: activeTrade.avgPrice}); let lsAvg = cObj.chart.addLineSeries({ color: '#848e9c', lineWidth: 1, lineStyle: 3, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); lsAvg.setData(activeTrade.avgLineData); cObj.tradeLineSeriesArr.push(lsAvg); }
                    let nowSec = Math.floor(Date.now() / 1000); if (nowSec - candle.time <= 86400 * 3) { generatedHistory.push({ id: `${cObj.symbol}_GRID_${activeTrade.entryTime}`, symbol: cObj.symbol, type: activeTrade.type, baseOrder: activeTrade.totalVol, entryPrice: activeTrade.avgPrice, exitPrice: exitPrice, pnlPct: finalPct * 100, netPnl: netPnl, entryTime: activeTrade.entryTime, exitTime: candle.time }); }
                    activeTrade = null; continue;
                }
            }
            if (activeTrade && useDCA && activeTrade.dcaCount < stepsArr.length) {
                while (activeTrade && activeTrade.dcaCount < stepsArr.length) {
                    let nextStepThreshold = stepsArr[activeTrade.dcaCount], triggerPrice = isLong ? activeTrade.entryPrice * (1 - nextStepThreshold/100) : activeTrade.entryPrice * (1 + nextStepThreshold/100), hitDCA = false;
                    if (isLong && candle.low <= triggerPrice) hitDCA = true; if (!isLong && candle.high >= triggerPrice) hitDCA = true;
                    if (hitDCA) {
                        activeTrade.dcaCount++; let stepVol = baseOrder * Math.pow(volMultiplier, activeTrade.dcaCount), fillPrice = triggerPrice, newTotalVol = activeTrade.totalVol + stepVol; activeTrade.avgPrice = ((activeTrade.avgPrice * activeTrade.totalVol) + (fillPrice * stepVol)) / newTotalVol; activeTrade.totalVol = newTotalVol;
                        markers.push({ time: candle.time, position: isLong ? 'belowBar' : 'aboveBar', color: isLong ? '#0ECB81' : '#F6465D', shape: 'circle', size: 1 });
                        tradeLabels.push({ time: candle.time, price: isLong ? candle.low : candle.high, linePrice: fillPrice, text: `Kademe #${activeTrade.dcaCount}<br>${window.formatPrice(fillPrice)}`, type: activeTrade.type, isExit: false, position: isLong ? 'belowBar' : 'aboveBar', colorClass: isLong ? 'long-entry' : 'short-entry' });
                        if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: fillPrice}, {time: candle.time, value: fillPrice}]); cObj.tradeLineSeriesArr.push(ls); }
                        tradeLabels.push({ time: candle.time, price: activeTrade.avgPrice, linePrice: activeTrade.avgPrice, text: `Ort: ${window.formatPrice(activeTrade.avgPrice)}`, type: 'AVG', isExit: false, position: 'onLine', colorClass: 'avg-label' });
                    } else { break; }
                }
            }
            if (activeTrade) { let lastData = activeTrade.avgLineData[activeTrade.avgLineData.length - 1]; if (lastData && lastData.time === candle.time) { lastData.value = activeTrade.avgPrice; } else { activeTrade.avgLineData.push({time: candle.time, value: activeTrade.avgPrice}); } }
        }

        if (!activeTrade) {
            let pivotIdx = i - rightLen, isPivotHigh = true, isPivotLow = true;
            for (let j = 1; j <= leftLen; j++) { if (data[pivotIdx].high <= data[pivotIdx-j].high) isPivotHigh = false; if (data[pivotIdx].low >= data[pivotIdx-j].low) isPivotLow = false; }
            for (let j = 1; j <= rightLen; j++) { if (data[pivotIdx].high < data[pivotIdx+j].high) isPivotHigh = false; if (data[pivotIdx].low > data[pivotIdx+j].low) isPivotLow = false; }

            if (isPivotHigh) {
                markers.push({ time: candle.time, position: 'aboveBar', color: '#F6465D', shape: 'arrowDown', size: 1 });
                tradeLabels.push({ time: candle.time, price: candle.high, linePrice: candle.open, text: `Giriş #${tradeCounter}<br>${window.formatPrice(candle.open)}`, type: 'SHORT', isExit: false, position: 'aboveBar', colorClass: 'short-entry' });
                if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: candle.open}, {time: candle.time, value: candle.open}]); cObj.tradeLineSeriesArr.push(ls); }
                tradeLabels.push({ time: candle.time, price: candle.open, linePrice: candle.open, text: `Ort: ${window.formatPrice(candle.open)}`, type: 'AVG', isExit: false, position: 'onLine', colorClass: 'avg-label' });
                activeTrade = { type: 'SHORT', entryPrice: candle.open, avgPrice: candle.open, entryTime: candle.time, ttpActive: false, totalVol: baseOrder, dcaCount: 0, tradeId: tradeCounter, avgLineData: [{time: candle.time, value: candle.open}] }; tradeCounter++;
            }
            else if (isPivotLow && !activeTrade) {
                markers.push({ time: candle.time, position: 'belowBar', color: '#089981', shape: 'arrowUp', size: 1 });
                tradeLabels.push({ time: candle.time, price: candle.low, linePrice: candle.open, text: `Giriş #${tradeCounter}<br>${window.formatPrice(candle.open)}`, type: 'LONG', isExit: false, position: 'belowBar', colorClass: 'long-entry' });
                if (cObj.chart) { let ls = cObj.chart.addLineSeries({ color: '#FCD535', lineWidth: 2, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); ls.setData([{time: data[i-1].time, value: candle.open}, {time: candle.time, value: candle.open}]); cObj.tradeLineSeriesArr.push(ls); }
                tradeLabels.push({ time: candle.time, price: candle.open, linePrice: candle.open, text: `Ort: ${window.formatPrice(candle.open)}`, type: 'AVG', isExit: false, position: 'onLine', colorClass: 'avg-label' });
                activeTrade = { type: 'LONG', entryPrice: candle.open, avgPrice: candle.open, entryTime: candle.time, ttpActive: false, totalVol: baseOrder, dcaCount: 0, tradeId: tradeCounter, avgLineData: [{time: candle.time, value: candle.open}] }; tradeCounter++;
            }
        }
    }
    if (activeTrade && activeTrade.avgLineData.length > 0 && cObj.chart) { let lsAvg = cObj.chart.addLineSeries({ color: '#848e9c', lineWidth: 1, lineStyle: 3, crosshairMarkerVisible: false, lastValueVisible: false, priceLineVisible: false }); lsAvg.setData(activeTrade.avgLineData); cObj.tradeLineSeriesArr.push(lsAvg); }
    window.syncHistoricalTrades(generatedHistory); return { markers, lastTrade: activeTrade, tradeLabels: tradeLabels };
};

// =============================================================
// CANDLE TIMER DÖNGÜSÜ (her saniye)
// =============================================================
setInterval(() => {
    let now = Date.now();
    let activeTimeStr = '--:--';
    
    for (let i = 0; i < chartCount; i++) {
        let cObj = chartsData[i];
        if (!cObj) continue;

        // WS yenileme kontrolü
        if (cObj.ws && cObj.lastWsUpdate && (now - cObj.lastWsUpdate > 30000)) {
            if (cObj.ws.readyState === 1) {
                console.log(`[WS] Chart ${i} 30 sn mesaj almadı, yeniden başlatılıyor...`);
                cObj.lastWsUpdate = now;
                cObj.ws.onclose = null;
                try { cObj.ws.close(); } catch(e) {}
                cObj.ws = null;
                setTimeout(() => window.connectSingleChartWS(i), 1500);
            } else if (cObj.ws.readyState === 3) {
                cObj.lastWsUpdate = now;
                cObj.ws = null;
                setTimeout(() => window.connectSingleChartWS(i), 1500);
            }
        }
        
        if (!cObj.interval || !cObj.lastCandleTime) continue;
        let secPerBar = window.getIntervalSeconds(cObj.interval);
        if (secPerBar <= 0) continue;

        let nowSec = Math.floor(now / 1000);
        let endTime = cObj.lastCandleTime + secPerBar;
        let remainder = endTime - nowSec;
        if (remainder < 0) remainder = 0;

        let h = Math.floor(remainder / 3600);
        let m = Math.floor((remainder % 3600) / 60);
        let s = remainder % 60;
        let timeStr = (h > 0 ? h.toString().padStart(2, '0') + ':' : '') + m.toString().padStart(2, '0') + ':' + s.toString().padStart(2, '0');

        // ⚡ Aktif chart için ana timer
        if (i === activeChartId) {
            activeTimeStr = timeStr;
        }
    }
    
    // ⚡ Ana candle timer'ı güncelle (chart-header'da)
    const mainTimer = document.getElementById('main-candle-timer');
    if (mainTimer) mainTimer.innerText = activeTimeStr;
    
}, 1000);

// =============================================================
// SAYFA YÜKLENMESİ
// =============================================================
window.onload = async () => {
    await window.fetchExchangeInfo();
    window.setLayout(chartCount);

    document.querySelectorAll('.tf-btn').forEach(b => { if (b.dataset.tf === savedInterval) b.classList.add('active'); else b.classList.remove('active'); });
    document.querySelectorAll('.type-btn').forEach(b => { if (b.dataset.type === savedChartType) b.classList.add('active'); else b.classList.remove('active'); });

    window.switchTab(activeTab);
    if (radarModeActive) { const rBtn = document.getElementById('radar-toggle-btn'); if (rBtn) rBtn.classList.add('active'); }

    window.updateWatchlistsRest();

    if (fWsList) fWsList.close();
    fWsList = new WebSocket('wss://fstream.binance.com/ws/!ticker@arr');
    fWsList.onmessage = (e) => { try { const d = JSON.parse(e.data); if (Array.isArray(d)) window.processTicker(d, 'futures'); } catch(err) {} };
    
    if (sWsList) sWsList.close();
    sWsList = new WebSocket('wss://stream.binance.com/ws/!ticker@arr');
    sWsList.onmessage = (e) => { try { const d = JSON.parse(e.data); if (Array.isArray(d)) window.processTicker(d, 'spot'); } catch(err) {} };

    window.syncWalletWithBackend();
    window.updateBotUI();
    setTimeout(function() { if (window.resizeToastContainer) window.resizeToastContainer(); }, 1500);
    window.restoreSidebarPanels();  // ⚡ Panel toggle durumlarini yukle
    
    // ⚡ Aktif pozisyonlarin komisyon oranlarini on-yukle
    setTimeout(async () => {
        try {
            const res = await fetch('/api/trade/active');
            const trades = await res.json();
            if (Array.isArray(trades)) {
                const symbols = [...new Set(trades.map(t => t.symbol))];
                console.log(`[COMM] ${symbols.length} sembol icin komisyon orani on-yukleniyor...`);
                for (const sym of symbols.slice(0, 50)) {
                    await window.getCommissionRate(sym);
                }
                // Yukleme bitince paneli yenile
                if (window.refreshBottomPanel) window.refreshBottomPanel();
            }
        } catch(e) {
            console.warn('[COMM] Preload hatasi:', e);
        }
    }, 2000);
    window.startScannerPolling();
    window.startSignalPolling();  // ⚡ 3 saniyede bir sinyal listesini yenile
    window.updateTabCounts();
    //window.switchBottomTab('signals'); // ⚡ Default olarak Sinyaller sekmesi açılsın
    
    setInterval(window.refreshBottomPanel, 8000); 
};

setInterval(() => {
    if (Date.now() - wsWatchlistLastUpdate > 30000) window.updateWatchlistsRest();
}, 1000);

// =============================================================
// BOT UI GÜNCELLEMESİ (geç yükleme)
// =============================================================
window.updateBotUI = async function() {
    try {
        const res = await fetch('/api/engine/status');
        const status = await res.json();
        const isRunning = status.running && status.config && status.config.active;
        
        const dot = document.getElementById('ui-bot-status-dot');
        const text = document.getElementById('ui-bot-status-text');
        
        if (isRunning) {
            if (dot) { dot.style.background = '#00e676'; dot.style.boxShadow = '0 0 8px #00e676'; }
            if (text) text.innerText = 'Bot: AKTİF';
        } else {
            if (dot) { dot.style.background = '#f23645'; dot.style.boxShadow = 'none'; }
            if (text) text.innerText = 'Bot: KAPALI';
        }
    } catch(e) {
        console.error('updateBotUI hatası:', e);
    }
};

setTimeout(() => {
    if (typeof window.updateBotUI === 'function') window.updateBotUI();
    if (typeof window.startScannerPolling === 'function') window.startScannerPolling();
}, 100);

// =============================================================
// CHART SETTINGS MODAL
// =============================================================
const CHART_SETTINGS_KEY = 'cryptoChartSettings_v1';

window.defaultChartSettings = {
    marginTop: 20,
    marginBottom: 20,
    rightOffset: 5,
    bgUp: '#089981',
    bgDown: '#f23645',
    wickUp: '#089981',
    wickDown: '#f23645',
    borderUp: '#089981',
    borderDown: '#f23645',
    showBorder: true,
    showWick: true,
    showCandleBorder: true,
};

window.currentChartSettings = JSON.parse(localStorage.getItem(CHART_SETTINGS_KEY)) || { ...window.defaultChartSettings };

window.openChartSettingsModal = function() {
    const s = window.currentChartSettings;

    document.getElementById('cs-margin-top').value = s.marginTop;
    document.getElementById('cs-margin-bottom').value = s.marginBottom;
    document.getElementById('cs-right-offset').value = s.rightOffset;

    document.getElementById('cs-show-border').checked = s.showBorder;
    document.getElementById('cs-show-wick').checked = s.showWick;
    document.getElementById('cs-show-candle-border').checked = s.showCandleBorder;

    document.getElementById('cs-bg-up').value = s.bgUp;
    document.getElementById('cs-bg-down').value = s.bgDown;
    document.getElementById('cs-wick-up').value = s.wickUp;
    document.getElementById('cs-wick-down').value = s.wickDown;
    document.getElementById('cs-border-up').value = s.borderUp;
    document.getElementById('cs-border-down').value = s.borderDown;

    document.getElementById('chart-settings-modal').classList.add('active');
};

window.closeChartSettingsModal = function() {
    document.getElementById('chart-settings-modal').classList.remove('active');
};

window.applyChartSettings = function() {
    const settings = {
        marginTop: parseInt(document.getElementById('cs-margin-top').value) || 20,
        marginBottom: parseInt(document.getElementById('cs-margin-bottom').value) || 20,
        rightOffset: parseInt(document.getElementById('cs-right-offset').value) || 5,

        bgUp: document.getElementById('cs-bg-up').value,
        bgDown: document.getElementById('cs-bg-down').value,
        wickUp: document.getElementById('cs-wick-up').value,
        wickDown: document.getElementById('cs-wick-down').value,
        borderUp: document.getElementById('cs-border-up').value,
        borderDown: document.getElementById('cs-border-down').value,

        showBorder: document.getElementById('cs-show-border').checked,
        showWick: document.getElementById('cs-show-wick').checked,
        showCandleBorder: document.getElementById('cs-show-candle-border').checked,
    };

    window.currentChartSettings = settings;
    localStorage.setItem(CHART_SETTINGS_KEY, JSON.stringify(settings));

    for (let i = 0; i < 4; i++) {
        window.applyChartSettingsToChart(i);
    }

    window.showToast('✅ Grafik ayarları uygulandı', 'success');
    window.closeChartSettingsModal();
};

window.applyChartSettingsToChart = function(idx) {
    const cObj = chartsData[idx];
    if (!cObj || !cObj.chart || !cObj.series) return;

    const s = window.currentChartSettings;

    cObj.chart.priceScale('right').applyOptions({
        autoScale: true,
        scaleMargins: {
            top: s.marginTop / 100,
            bottom: s.marginBottom / 100,
        },
    });

    cObj.chart.timeScale().applyOptions({
        rightOffset: s.rightOffset,
    });

    cObj.series.applyOptions({
        upColor: s.bgUp,
        downColor: s.bgDown,
        wickUpColor: s.showWick ? s.wickUp : 'transparent',
        wickDownColor: s.showWick ? s.wickDown : 'transparent',
        borderUpColor: s.showCandleBorder ? s.borderUp : s.bgUp,
        borderDownColor: s.showCandleBorder ? s.borderDown : s.bgDown,
        borderVisible: s.showBorder,
    });
};

window.resetChartMargins = function() {
    document.getElementById('cs-margin-top').value = window.defaultChartSettings.marginTop;
    document.getElementById('cs-margin-bottom').value = window.defaultChartSettings.marginBottom;
    document.getElementById('cs-right-offset').value = window.defaultChartSettings.rightOffset;
};

window.resetChartColors = function() {
    const d = window.defaultChartSettings;
    document.getElementById('cs-bg-up').value = d.bgUp;
    document.getElementById('cs-bg-down').value = d.bgDown;
    document.getElementById('cs-wick-up').value = d.wickUp;
    document.getElementById('cs-wick-down').value = d.wickDown;
    document.getElementById('cs-border-up').value = d.borderUp;
    document.getElementById('cs-border-down').value = d.borderDown;
    document.getElementById('cs-show-border').checked = d.showBorder;
    document.getElementById('cs-show-wick').checked = d.showWick;
    document.getElementById('cs-show-candle-border').checked = d.showCandleBorder;
};

window.toggleBorderVisibility = function() {
    const checked = document.getElementById('cs-show-border').checked;
    for (let i = 0; i < 4; i++) {
        if (chartsData[i] && chartsData[i].series) {
            chartsData[i].series.applyOptions({ borderVisible: checked });
        }
    }
};

window.toggleWickVisibility = function() {
    const checked = document.getElementById('cs-show-wick').checked;
    for (let i = 0; i < 4; i++) {
        if (chartsData[i] && chartsData[i].series) {
            chartsData[i].series.applyOptions({
                wickUpColor: checked ? window.currentChartSettings.wickUp : 'transparent',
                wickDownColor: checked ? window.currentChartSettings.wickDown : 'transparent',
            });
        }
    }
};

window.toggleCandleBorder = function() {
    const checked = document.getElementById('cs-show-candle-border').checked;
    for (let i = 0; i < 4; i++) {
        if (chartsData[i] && chartsData[i].series) {
            chartsData[i].series.applyOptions({
                borderUpColor: checked ? window.currentChartSettings.borderUp : window.currentChartSettings.bgUp,
                borderDownColor: checked ? window.currentChartSettings.borderDown : window.currentChartSettings.bgDown,
            });
        }
    }
};

window.applyChartSettingsToNewChart = function(idx) {
    setTimeout(() => window.applyChartSettingsToChart(idx), 200);
};

// =============================================================
// REST POLLING FALLBACK
// =============================================================
window.restPollingIntervals = {};

window.startRestPolling = function(idx) {
    if (window.restPollingIntervals[idx]) return;
    console.log(`[REST-Polling] Chart ${idx} başlatıldı`);
    
    const fetchLatest = async () => {
        const cObj = chartsData[idx];
        if (!cObj || !cObj.chart || !cObj.series) return;
        
        try {
            const isFutures = cObj.symbol.endsWith('.P');
            const apiSymbol = cObj.symbol.replace('.P', '');
            const bInt = window.getBinanceInterval(cObj.interval);
            const baseUrl = isFutures ? 'https://fapi.binance.com/fapi/v1/klines' : 'https://api.binance.com/api/v3/klines';
            
            const res = await fetch(`${baseUrl}?symbol=${apiSymbol}&interval=${bInt}&limit=2`);
            if (!res.ok) return;
            
            const data = await res.json();
            if (!Array.isArray(data) || data.length === 0) return;
            
            const lastK = data[data.length - 1];
            const t = Math.floor(lastK[0] / 1000);
            const o = parseFloat(lastK[1]);
            const h = parseFloat(lastK[2]);
            const l = parseFloat(lastK[3]);
            const c = parseFloat(lastK[4]);
            const v = parseFloat(lastK[5]);
            
            let activeTick = { time: t, open: o, high: h, low: l, close: c };
            
            if (!cObj.hasInitialData) {
                cObj.series.setData([activeTick]);
                cObj.hasInitialData = true;
            } else {
                cObj.series.update(activeTick);
            }
            
            cObj.candleMap.set(t, { o, h, l, c, v });
            cObj.lastClose = c;
            cObj.lastCandleTime = t;
            cObj.lastWsUpdate = Date.now();
            
            if (!cObj.crosshairActive) window.renderOHLCV(idx, { o, h, l, c, v });
            
            if (!cObj._restCounter) cObj._restCounter = 0;
            cObj._restCounter++;
            if (cObj._restCounter >= 3) {
                cObj._restCounter = 0;
                if (window.recalculateAllIndicators) window.recalculateAllIndicators(idx);
            }
            
            if (window.syncTradeLabels) window.syncTradeLabels(idx);
        } catch(e) {}
    };
    
    fetchLatest();
    window.restPollingIntervals[idx] = setInterval(fetchLatest, 6000);
};

window.stopRestPolling = function(idx) {
    if (window.restPollingIntervals[idx]) {
        clearInterval(window.restPollingIntervals[idx]);
        delete window.restPollingIntervals[idx];
        console.log(`[REST-Polling] Chart ${idx} durduruldu`);
    }
};

// =============================================================
// KALDIRAÇ / MARJIN HESAPLAYICI
// =============================================================
window.updateMarginPreview = function(strategy) {
    const baseOrderInput = document.querySelector(`.strat-param[data-strategy="${strategy}"][data-param="baseOrder"]`);
    const levInput = document.querySelector(`.strat-param[data-strategy="${strategy}"][data-param="leverage"]`);
    const previewEl = document.getElementById(`margin-preview-${strategy}`);
    
    if (!baseOrderInput || !levInput || !previewEl) return;
    
    const baseOrder = parseFloat(baseOrderInput.value) || 0;
    const leverage = parseInt(levInput.value) || 1;
    
    const margin = leverage > 0 ? baseOrder / leverage : baseOrder;
    previewEl.innerText = `${margin.toFixed(2)} USDT`;
    
    // Küçük animasyon
    previewEl.style.transform = 'scale(1.1)';
    setTimeout(() => { previewEl.style.transform = 'scale(1)'; }, 150);
};

// Modal açıldığında tüm marjin önizlemelerini güncelle
window.updateAllMarginPreviews = function() {
    ['RSI_SCALPER', 'HULL_SRP', 'GRIDBOT'].forEach(s => window.updateMarginPreview(s));
};

// =============================================================
// SEMBOL ISLEM GECMISI GORSELLESTIRME
// =============================================================
window.clearSymbolTrades = function(idx) {
    const cObj = chartsData[idx];
    if (!cObj || !cObj.chart) return;
    
    if (cObj.userTrades && cObj.userTrades.lines) {
        cObj.userTrades.lines.forEach(ls => {
            try { cObj.chart.removeSeries(ls); } catch(e) {}
        });
    }
    
    cObj.userTrades = { markers: [], labels: [], lines: [] };
    
    const userMarkers = [];
    let allM = [...(cObj.strategyMarkers||[]), ...(cObj.tradeMarkers||[]), ...userMarkers].sort((a,b)=>a.time - b.time);
    if (cObj.series) cObj.series.setMarkers(allM);
    
    const container = document.getElementById(`labels-container-${idx}`);
    if (container) container.innerHTML = '';
    
    if (window.syncTradeLabels) window.syncTradeLabels(idx);
};

window.jumpToSymbolWithTrades = function(symbol) {
    window.changeSymbol(symbol);
    const cleanSym = symbol.replace('.P', '');
    setTimeout(() => {
        window.showSymbolTrades(cleanSym);
    }, 900);
};

window.showSymbolTrades = async function(symbol, idx = null) {
    if (idx === null) idx = activeChartId;
    const cObj = chartsData[idx];
    if (!cObj || !cObj.chart) return;
    
    window.clearSymbolTrades(idx);
    
    const cleanSym = symbol.replace('.P', '');
    
    try {
        const [histRes, activeRes] = await Promise.all([
            fetch('/api/trade/history?limit=500'),
            fetch('/api/trade/active')
        ]);
        
        const history = await histRes.json();
        const active = await activeRes.json();
        
        const symbolHistory = (Array.isArray(history) ? history : []).filter(t => t.symbol === cleanSym);
        const symbolActive = (Array.isArray(active) ? active : []).filter(t => t.symbol === cleanSym);
        
        if (symbolHistory.length === 0 && symbolActive.length === 0) {
            console.log(`[Symbol Trades] ${cleanSym} icin islem bulunamadi`);
            return;
        }
        
        let markers = [];
        let tradeLabels = [];
        let lines = [];
        
        const addLine = (time1, price1, time2, price2, color, width, dashed) => {
            try {
                if (price1 <= 0 || price2 <= 0) return;
                
                const firstCandleTime = cObj.rawCandles.length > 0 ? cObj.rawCandles[0].time : 0;
                const lastCandleTime = cObj.lastCandleTime || 0;
                
                let t1 = _alignTf(time1), t2 = _alignTf(time2);
                if (t1 < firstCandleTime) t1 = firstCandleTime;
                if (t2 < firstCandleTime) t2 = firstCandleTime;
                if (t1 > lastCandleTime) t1 = lastCandleTime;
                if (t2 > lastCandleTime) t2 = lastCandleTime;
                if (t1 === t2) return;
                
                const ls = cObj.chart.addLineSeries({
                    color: color,
                    lineWidth: width || 1,
                    lineStyle: dashed ? 2 : 0,
                    crosshairMarkerVisible: false,
                    lastValueVisible: false,
                    priceLineVisible: false,
                    // ⚡ KRITIK: Bu çizgi autoscale'e ETKİ ETMESİN
                    // Yani mumların Y ölçeği bu çizgiden etkilenmeyecek
                    autoscaleInfoProvider: () => null
                });
                ls.setData([
                    { time: t1, value: price1 },
                    { time: t2, value: price2 }
                ]);
                lines.push(ls);
            } catch(e) {
                console.warn('Line ekleme hatasi:', e);
            }
        };
        
        const now = Math.floor(Date.now() / 1000);
        const lastTime = (cObj.lastCandleTime && cObj.lastCandleTime > now) ? cObj.lastCandleTime : now;

        // ⚡ Marker hizalama: unix saniyeyi mum basina yuvarla
        const _tfSec = window.getIntervalSeconds(cObj.interval || '5m') || 300;
        const _alignTf = (t) => t ? Math.floor(t / _tfSec) * _tfSec : t;
        
        symbolActive.forEach(pos => {
            const entryTime = _alignTf(pos.entry_time);
            const entryPrice = pos.avg_price;
            const isLong = pos.trade_type === 'BUY';
            
            // ⚡ Anormal avg_price kontrolu (0 veya negatifse atla)
            if (!entryPrice || entryPrice <= 0) {
                console.warn(`[Symbol Trades] Aktif pozisyon atlandi: ${pos.symbol} avg_price=${entryPrice}`);
                return;
            }
            
            markers.push({
                time: entryTime,
                position: isLong ? 'belowBar' : 'aboveBar',
                color: isLong ? '#0ECB81' : '#F6465D',
                shape: 'circle',
                size: 1
            });
            
            const lineEndTime = lastTime > entryTime ? lastTime : entryTime + 60;
            addLine(entryTime - 120, entryPrice, entryTime + 120, entryPrice, 'rgba(252,213,53,0.6)', 2, true);
            
            const dcaInfo = pos.dca_count > 0 ? ` · D${pos.dca_count}` : '';
            tradeLabels.push({
                time: entryTime,
                price: entryPrice,
                linePrice: entryPrice,
                text: `${window.formatPrice(entryPrice)}${dcaInfo}`,
                type: isLong ? 'LONG' : 'SHORT',
                isExit: false,
                position: isLong ? 'belowBar' : 'aboveBar',
                colorClass: isLong ? 'long-entry' : 'short-entry'
            });
            
            // ⚡ DCA kademeleri icin ayri marker'lar
            const dcaCount = pos.dca_count || 0;
            const initialPrice = pos.initial_price || pos.avg_price;
            if (dcaCount > 0 && initialPrice > 0) {
                // Config'deki steps'i oku (varsayilan: 1.5, 3, 5)
                let stepsStr = "1.5, 3, 5";
                try {
                    const cfg = window.botConfig && window.botConfig.strategies && window.botConfig.strategies[pos.strategy_name];
                    if (cfg && cfg.steps) stepsStr = cfg.steps;
                } catch(e) {}
                
                const steps = String(stepsStr).split(',').map(s => parseFloat(s.trim())).filter(s => !isNaN(s));
                
                for (let d = 1; d <= dcaCount && d <= steps.length; d++) {
                    const pct = steps[d - 1] / 100;
                    let dcaPrice;
                    if (isLong) {
                        dcaPrice = initialPrice * (1 - pct);
                    } else {
                        dcaPrice = initialPrice * (1 + pct);
                    }
                    
                    // ⚡ KISA DCA çizgisi: giriş mumun ±2 mum
                    addLine(entryTime - 120, dcaPrice, entryTime + 120, dcaPrice, 'rgba(252,213,53,0.5)', 1, true);
                    
                    // DCA etiketi
                    tradeLabels.push({
                        time: entryTime,
                        price: dcaPrice,
                        linePrice: dcaPrice,
                        text: `D${d}`,
                        type: isLong ? 'LONG' : 'SHORT',
                        isExit: false,
                        position: 'onLine',
                        colorClass: 'avg-label'
                    });
                }
            }
        });
        
        symbolHistory.forEach(trade => {
            const entryTime = _alignTf(trade.entry_time);
            const exitTime = _alignTf(trade.exit_time);
            const entryPrice = trade.entry_price;
            const exitPrice = trade.exit_price;
            const isLong = trade.trade_type === 'BUY';
            const isProfit = trade.pnl_amount >= 0;
            
            // ⚡ TUM islemler gosterilir - filtreleme YOK
            // (Anormal testnet islemleri de gorunsun, kullanici karar verir)
            
            markers.push({
                time: entryTime,
                position: isLong ? 'belowBar' : 'aboveBar',
                color: isLong ? '#0ECB81' : '#F6465D',
                shape: 'circle',
                size: 1
            });
            
            markers.push({
                time: exitTime,
                position: isLong ? 'aboveBar' : 'belowBar',
                color: isProfit ? '#0ECB81' : '#F6465D',
                shape: 'circle',
                size: 1
            });
            
            addLine(entryTime, entryPrice, exitTime, exitPrice, isProfit ? 'rgba(14,203,129,0.35)' : 'rgba(246,70,93,0.35)', 1, true);
            
            tradeLabels.push({
                time: entryTime,
                price: entryPrice,
                linePrice: entryPrice,
                text: `${window.formatPrice(entryPrice)}`,
                type: isLong ? 'LONG' : 'SHORT',
                isExit: false,
                position: isLong ? 'belowBar' : 'aboveBar',
                colorClass: isLong ? 'long-entry' : 'short-entry'
            });
            
            const sign = isProfit ? '+' : '';
            tradeLabels.push({
                time: exitTime,
                price: exitPrice,
                linePrice: exitPrice,
                text: `${sign}${trade.pnl_pct.toFixed(2)}%`,
                type: isLong ? 'LONG' : 'SHORT',
                isExit: true,
                pnlClass: isProfit ? 'profit' : 'loss',
                position: isLong ? 'aboveBar' : 'belowBar',
                colorClass: 'exit'
            });
        });
        
        cObj.userTrades = { markers: markers, labels: tradeLabels, lines: lines };
        window._lastActiveSymbol = cObj.symbol;  // auto check icin cache
        
        const userMarkers = cObj.userTrades.markers;
        let allM = [...(cObj.strategyMarkers||[]), ...(cObj.tradeMarkers||[]), ...userMarkers].sort((a,b)=>a.time - b.time);
        cObj.series.setMarkers(allM);
        
        window.syncTradeLabels(idx);
        
        const totalTrades = symbolHistory.length + symbolActive.length;
        window.showToast(`${cleanSym}: ${totalTrades} islem gosteriliyor`, 'info', 2500);
        
        console.log(`[Symbol Trades] ${cleanSym} - Gecmis: ${symbolHistory.length}, Aktif: ${symbolActive.length}`);
        
    } catch(e) {
        console.error('[Symbol Trades] Hata:', e);
        window.showToast('Islem verisi yuklenemedi', 'error');
    }
};

// =============================================================
// SIGNAL FILTER + PAGINATION v2 (override)
// Tarih: 2026-09-18 00:18
// =============================================================

window.signalFilter = null; // Filtre butonlari kaldirildi - her zaman null
window.signalPage = 1;
window.SIGNALS_PER_PAGE = 50;

window.toggleSignalFilter = function(type) {
    if (window.signalFilter === type) {
        window.signalFilter = null;  // Ayni butona tekrar tiklandi -> filtreyi kaldir
    } else {
        window.signalFilter = type;
    }
    localStorage.setItem('cryptoSignalFilter', window.signalFilter || '');
    window.signalPage = 1;
    window._signalHash = '';
    window.renderSignals();
};

window.changeSignalPage = function(dir) {
    window.signalPage += dir;
    if (window.signalPage < 1) window.signalPage = 1;
    window._signalHash = '';
    window.renderSignals();
    const logContainer = document.getElementById('signal-log');
    if (logContainer) logContainer.scrollTop = 0;
};

window.updateSignalFilterButtons = function() {
    const btnOpen = document.getElementById('sig-filter-open');
    const btnClose = document.getElementById('sig-filter-close');
    if (btnOpen) {
        if (window.signalFilter === 'signal') btnOpen.classList.add('active');
        else btnOpen.classList.remove('active');
    }
    if (btnClose) {
        if (window.signalFilter === 'close') btnClose.classList.add('active');
        else btnClose.classList.remove('active');
    }
};

window.renderSignals = async function() {
    const logContainer = document.getElementById('signal-log');
    if (!logContainer) return;
    
    try {
        const res = await fetch('/api/engine/recent-signals?limit=500');
        let events = await res.json();
        if (!Array.isArray(events)) events = [];
        
        // ⚡ Temizlenme filtresi
        const clearedBefore = parseInt(localStorage.getItem('cryptoSignalsClearedBefore') || '0');
        events = events.filter(e => (e.timestamp || 0) > clearedBefore);
        
        // ⚡ Yeni event toast tespit
        if (!window._seenSignalIds) window._seenSignalIds = new Set();
        if (window._signalInitialized) {
            events.forEach(evt => {
                const uid = evt.event_type + '_' + evt.id;
                if (!window._seenSignalIds.has(uid)) {
                    if (evt.event_type === 'signal') {
                        const isLong = evt.signal === 'LONG';
                        window.showToast(`${evt.symbol} [${evt.strategy}] ${evt.signal}`, isLong ? 'success' : 'error', 5000, isLong ? '📈 LONG SİNYAL' : '📉 SHORT SİNYAL');
                    } else {
                        const sign = evt.pnl_amount >= 0 ? '+' : '';
                        window.showToast(`${evt.symbol} KAPANDI ${sign}${evt.pnl_amount.toFixed(4)} USDT`, evt.pnl_amount >= 0 ? 'success' : 'error', 5000, evt.pnl_amount >= 0 ? '✅ KÂR' : '🛑 ZARAR');
                    }
                }
            });
        }
        events.forEach(evt => window._seenSignalIds.add(evt.event_type + '_' + evt.id));
        window._signalInitialized = true;
        
        // ⚡ Filtreleme
        let filtered = events;
        if (window.signalFilter) {
            filtered = events.filter(e => e.event_type === window.signalFilter);
        }
        
        // Buton sayilarini guncelle
        const totalOpen = events.filter(e => e.event_type === 'signal').length;
        const totalClose = events.filter(e => e.event_type === 'close').length;
        const btnOpen = document.getElementById('sig-filter-open');
        const btnClose = document.getElementById('sig-filter-close');
        if (btnOpen) btnOpen.innerText = `Açılan (${totalOpen})`;
        if (btnClose) btnClose.innerText = `Kapanan (${totalClose})`;
        
        window.updateSignalFilterButtons();
        
        // Hash kontrol - sadece degistiyse render
        const newHash = filtered.slice(0, 20).map(e => e.event_type + '_' + e.id).join('|') 
                        + '_f' + (window.signalFilter || '') 
                        + '_p' + window.signalPage 
                        + '_c' + clearedBefore
                        + '_n' + filtered.length;
        if (window._signalHash === newHash) return;
        window._signalHash = newHash;
        
        if (filtered.length === 0) {
            logContainer.innerHTML = '<li class="loading">Bildirim yok.</li>';
            return;
        }
        
        // ⚡ Sayfalama
        const totalRows = filtered.length;
        const totalPages = Math.ceil(totalRows / window.SIGNALS_PER_PAGE);
        if (window.signalPage > totalPages) window.signalPage = totalPages;
        if (window.signalPage < 1) window.signalPage = 1;
        
        const startIdx = (window.signalPage - 1) * window.SIGNALS_PER_PAGE;
        const paginated = filtered.slice(startIdx, startIdx + window.SIGNALS_PER_PAGE);
        
        const formatSignalDate = (ms) => {
            const d = new Date(ms);
            const pad = (n) => String(n).padStart(2, '0');
            return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
        };
        
        let html = '';
        paginated.forEach(evt => {
            if (evt.event_type === 'signal') {
                const isLong = evt.signal === 'LONG';
                const tagClass = isLong ? 'pos-long' : 'pos-short';
                const tagText = isLong ? 'LONG' : 'SHORT';
                const dateStr = formatSignalDate(evt.created_at);
                const priceStr = window.formatPrice(evt.price);
                
                html += `
                    <li class="signal-item" onclick="window.changeSymbol('${evt.display_symbol}')">
                        <div class="signal-line-1">
                            <span class="signal-symbol">${evt.symbol}</span>
                            <span class="signal-strategy">[${evt.strategy}]</span>
                            <span class="signal-tag ${tagClass}">${tagText}</span>
                        </div>
                        <div class="signal-line-date">${dateStr}</div>
                        <div class="signal-line-2">
                            <span class="signal-label">Giriş Fiyat:</span>
                            <span class="signal-value">${priceStr}</span>
                            <span class="signal-label" style="margin-left:12px;">Toplam:</span>
                            <span class="signal-value">${evt.total_usdt.toFixed(2)} USDT</span>
                        </div>
                    </li>
                `;
            } else {
                const isProfit = evt.pnl_amount >= 0;
                const sign = isProfit ? '+' : '';
                const pnlColor = isProfit ? '#0ECB81' : '#F6465D';
                
                let reasonText = evt.close_reason || 'KAPANIŞ';
                if (reasonText.includes('TRAILING')) {
                    const match = reasonText.match(/\(([^)]+)\)/);
                    reasonText = `TRAILING ${match ? match[1] : ''}`.trim();
                } else if (reasonText.includes('STOP LOSS')) {
                    reasonText = 'STOP LOSS';
                } else if (reasonText.includes('TAKE PROFIT')) {
                    reasonText = 'TAKE PROFIT';
                }
                
                const dateStr = formatSignalDate(evt.timestamp);
                const isStopLoss = (evt.close_reason || '').toUpperCase().includes('STOP');
                const cardClass = isStopLoss ? 'stop-item' : 'close-item';
                
                html += `
                    <li class="signal-item ${cardClass}" onclick="window.changeSymbol('${evt.display_symbol}')">
                        <div class="signal-line-1">
                            <span class="signal-symbol">${evt.symbol}</span>
                            <span class="signal-strategy">| ${reasonText} |</span>
                        </div>
                        <div class="signal-line-2">
                            <span class="signal-label">Giriş:</span>
                            <span class="signal-value">${window.formatPrice(evt.entry_price)}</span>
                            <span class="signal-label" style="margin-left:8px;">Çıkış:</span>
                            <span class="signal-value">${window.formatPrice(evt.exit_price)}</span>
                            <span class="signal-label" style="margin-left:8px;">Kâr:</span>
                            <span class="signal-value" style="color:${pnlColor};">${sign}${evt.pnl_pct.toFixed(2)}%</span>
                        </div>
                        <div class="signal-line-2">
                            <span class="signal-label" style="color:#5d6471;">${dateStr}</span>
                            <span class="signal-label" style="margin-left:8px;">Net:</span>
                            <span class="signal-value" style="color:${pnlColor};">${sign}${evt.pnl_amount.toFixed(4)} USDT</span>
                        </div>
                    </li>
                `;
            }
        });
        
        // Sayfalama butonlari
        if (totalPages > 1) {
            html += `
                <li class="signal-pagination">
                    <button class="sig-page-btn" onclick="event.stopPropagation(); window.changeSignalPage(-1)" ${window.signalPage === 1 ? 'disabled' : ''}>◀ Önceki</button>
                    <span class="sig-page-info">Sayfa ${window.signalPage} / ${totalPages} <span style="color:#5d6471; font-size:10px; margin-left:6px;">(${totalRows} kayıt)</span></span>
                    <button class="sig-page-btn" onclick="event.stopPropagation(); window.changeSignalPage(1)" ${window.signalPage === totalPages ? 'disabled' : ''}>Sonraki ▶</button>
                </li>
            `;
        }
        
        logContainer.innerHTML = html;
    } catch(e) {
        console.error('Sinyaller yüklenemedi:', e);
    }
};

window.clearSignals = function() {
    localStorage.setItem('cryptoSignalsClearedBefore', Date.now().toString());
    window.signalPage = 1;
    window._signalHash = '';
    window._seenSignalIds = new Set();
    window.renderSignals();
    window.showToast('🧹 Tüm bildirimler temizlendi', 'info', 2000);
};

window.startSignalPolling = function() {
    if (window._signalPollingInterval) clearInterval(window._signalPollingInterval);
    window.renderSignals();
    window._signalPollingInterval = setInterval(() => window.renderSignals(), 8000);
};

// =============================================================
// TÜM VERİYİ SIFIRLA (test için)
// Tarih: 2026-09-18 00:33
// =============================================================
window.resetAllData = async function() {
    // Bot çalışıyor mu kontrol et
    let botRunning = false;
    try {
        const statusRes = await fetch('/api/engine/status');
        const status = await statusRes.json();
        botRunning = status.running && status.config && status.config.active;
    } catch(e) {}
    
    const botWarning = botRunning 
        ? '\n\n⚠️ DİKKAT: Bot şu an ÇALIŞIYOR!\nÖnce botu durdurmanız önerilir.\n' 
        : '';
    
    const ok = await window.showConfirm(
        '🗑️ TÜM VERİYİ SIFIRLA',
        'Bu işlem şunları SİLECEK:\n\n' +
        '  • Tüm sinyal kayıtları\n' +
        '  • Tüm açık pozisyonlar\n' +
        '  • Tüm işlem geçmişi\n' +
        '  • Tarayıcı localStorage verileri\n' +
        '  • Filtre + sayfa ayarları\n' +
        botWarning +
        '\nBu işlem GERİ ALINAMAZ!\n\n' +
        'Devam etmek istiyor musunuz?',
        '🗑️ EVET, SIFIRLA',
        'İPTAL',
        'danger'
    );
    
    if (!ok) return;
    
    try {
        window.showToast('⏳ Sıfırlanıyor...', 'info', 2000);
        
        // Backend'den temizle
        const res = await fetch('/api/admin/reset-all', { method: 'POST' });
        const data = await res.json();
        
        if (data.status !== 'success') {
            window.showToast('❌ Sıfırlama başarısız', 'error');
            return;
        }
        
        // localStorage temizle
        const keysToClear = [
            'cryptoGlobalPos_v1',
            'cryptoTradeHistory_v2',
            'cryptoDeletedTrades_v2',
            'cryptoSignals_v1',
            'cryptoDailyOpens_v10',
            'cryptoKnownCoins_v3',
            'cryptoSignalFilter',
            'cryptoSignalsClearedBefore',
            'cryptoChartsData',
        ];
        keysToClear.forEach(k => localStorage.removeItem(k));
        
        const c = data.cleared;
        window.showToast(
            `✅ Sıfırlandı: ${c.signals} sinyal, ${c.active_trades} pozisyon, ${c.trade_history} geçmiş`,
            'success',
            4000
        );
        
        // 2 saniye sonra sayfa yenile
        setTimeout(() => location.reload(), 2000);
        
    } catch(e) {
        console.error('[RESET] Hata:', e);
        window.showToast('❌ Hata: ' + e.message, 'error');
    }
};

// =============================================================
// FUNDING RATE GÖSTERİMİ
// Tarih: 2026-09-18 01:45
// =============================================================

window.updateFundingBadge = async function(symbol) {
    const badge = document.getElementById('main-funding-badge');
    if (!badge) return;
    
    try {
        const res = await fetch(`/api/funding/${symbol}`);
        const data = await res.json();
        
        if (data.status !== 'success') {
            badge.style.display = 'none';
            return;
        }
        
        const ratePct = data.funding_rate_pct || 0;
        const dailyPct = data.daily_funding_pct || 0;
        const rate = data.funding_rate || 0;
        
        // Renk ve etiket
        let cls = 'funding-badge';
        let icon = '💰';
        let label = `Funding: ${ratePct >= 0 ? '+' : ''}${ratePct.toFixed(4)}%`;
        
        if (rate > 0.0005) {
            // Yuksek pozitif funding (>0.05%) -> long maliyeti yuksek
            cls += ' high';
            icon = '⚠️';
            label += ` (Long: -${Math.abs(dailyPct).toFixed(2)}%/gun)`;
        } else if (rate < -0.0005) {
            // Negatif funding -> long bonus
            cls += ' negative';
            icon = '✅';
            label += ` (Long: +${Math.abs(dailyPct).toFixed(2)}%/gun)`;
        }
        
        badge.className = cls;
        badge.innerHTML = `${icon} ${label}`;
        badge.style.display = 'inline-flex';
        
        // Sonraki funding zamani
        const nextTime = data.next_funding_time;
        if (nextTime > 0) {
            const d = new Date(nextTime);
            const pad = (n) => String(n).padStart(2, '0');
            const timeStr = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
            badge.title = `Sonraki funding: ${timeStr} (Türkiye saati)`;
        }
        
    } catch(e) {
        console.warn('[Funding] Hata:', e);
        badge.style.display = 'none';
    }
};

// =============================================================
// AKTİF SEMBOLDE POZİSYON VARSA OTOMATİK İŞARET GÖSTER
// Tarih: 2026-09-18 02:16
// =============================================================

window._lastAutoCheck = 0;
window._lastActiveSymbol = '';

window.autoCheckActivePositions = async function() {
    const cObj = chartsData[activeChartId];
    if (!cObj || !cObj.symbol || !cObj.series) return;
    
    const now = Date.now();
    if (now - window._lastAutoCheck < 5000) return;  // 5 sn cache
    window._lastAutoCheck = now;
    
    const cleanSym = cObj.symbol.replace('.P', '');
    
    try {
        const res = await fetch('/api/trade/active');
        const trades = await res.json();
        if (!Array.isArray(trades)) return;
        
        const symbolPositions = trades.filter(t => t.symbol === cleanSym);
        const currentMarkerCount = (cObj.userTrades && cObj.userTrades.markers) ? cObj.userTrades.markers.length : 0;
        
        // ⚡ Sadece SEMBOL degistiginde yeniden yukle
        // Marker sayisi degistiginde (pozisyon kapandi) yeniden yukleme yapma
        // Boylece gecmis islemler kalici kalir
        const symbolChanged = (window._lastActiveSymbol !== cObj.symbol);
        
        if (symbolChanged) {
            console.log(`[AUTO] Sembol degisti: ${window._lastActiveSymbol} -> ${cObj.symbol}`);
            window._lastActiveSymbol = cObj.symbol;
            await window.showSymbolTrades(cleanSym);
        }
    } catch(e) {
        // Sessizce yut
    }
};

// 5 saniyede bir otomatik kontrol
setInterval(window.autoCheckActivePositions, 5000);

// =============================================================
// KOMISYON ORANI CACHE (frontend)
// Tarih: 2026-09-18 02:27
// =============================================================

window._commissionCache = {};  // {symbol: {taker, maker, timestamp}}

window.getCommissionRate = async function(symbol) {
    const now = Date.now();
    const cached = window._commissionCache[symbol];
    
    // 1 saat cache
    if (cached && (now - cached.timestamp) < 3600000) {
        return cached;
    }
    
    try {
        const res = await fetch(`/api/commission/${symbol}`);
        const data = await res.json();
        
        if (data.status === 'success') {
            const result = {
                taker: data.taker || 0.0004,
                maker: data.maker || 0.0002,
                timestamp: now,
            };
            window._commissionCache[symbol] = result;
            return result;
        }
    } catch(e) {
        console.warn('[Commission] Fetch hatasi:', e);
    }
    
    // Fallback: VIP 0
    return { taker: 0.0004, maker: 0.0002, timestamp: now };
};

// Toplu on-yukleme (sayfa yuklendiginde)
window.preloadCommissionRates = async function(symbols) {
    for (const sym of symbols.slice(0, 20)) {
        if (!window._commissionCache[sym]) {
            await window.getCommissionRate(sym);
        }
    }
};

// =============================================================
// GÖRÜNTÜ KOMİSYON ORANI (sembol icin taker x2)
// =============================================================
window.getDisplayCommission = function(symbol) {
    // 1. Cache'de varsa kullan (Binance'ten cekilmis gercek oran)
    const cleanSym = String(symbol).replace('.P', '');
    if (window._commissionCache && window._commissionCache[cleanSym]) {
        const taker = window._commissionCache[cleanSym].taker || 0.0004;
        return taker * 2;  // Giris (taker) + Cikis (taker)
    }
    // 2. Cache bos ise VIP 0 varsayilan: taker 0.04% x 2 = 0.08%
    return 0.0008;
};

// =============================================================
// SIDEBAR PANEL TOGGLE
// İzleme Listesi ve Sinyaller panelini bağımsız aç/kapat
// =============================================================
window.toggleSidebarPanel = function(panel, show) {
    const upper = document.getElementById('sidebar-upper');
    const wlModule = document.getElementById('watchlist-module');
    const sigModule = document.getElementById('signal-panel-module');
    
    if (!upper || !wlModule || !sigModule) return;
    
    if (panel === 'watchlist') {
        if (show) {
            wlModule.classList.remove('panel-hidden');
            upper.classList.remove('panel-hidden-watchlist');
        } else {
            wlModule.classList.add('panel-hidden');
            upper.classList.add('panel-hidden-watchlist');
        }
        localStorage.setItem('cryptoShowWatchlist', show ? '1' : '0');
    } else if (panel === 'signals') {
        if (show) {
            sigModule.classList.remove('panel-hidden');
            upper.classList.remove('panel-hidden-signals');
        } else {
            sigModule.classList.add('panel-hidden');
            upper.classList.add('panel-hidden-signals');
        }
        localStorage.setItem('cryptoShowSignals', show ? '1' : '0');
    }
    
    // Grafikleri yeniden boyutlandır (panel alanı değişti)
    setTimeout(() => {
        for (let i = 0; i < chartCount; i++) {
            const cObj = chartsData[i];
            if (cObj && cObj.chart) {
                try {
                    cObj.chart.applyOptions({ width: 0, height: 0 });
                    setTimeout(() => {
                        const container = document.getElementById(`tvchart-${i}`);
                        if (container) {
                            const rect = container.getBoundingClientRect();
                            if (rect.width > 0 && rect.height > 0) {
                                cObj.chart.applyOptions({ width: rect.width, height: rect.height });
                            }
                        }
                    }, 50);
                } catch(e) {}
            }
        }
    }, 100);
};

window.restoreSidebarPanels = function() {
    const showWl = localStorage.getItem('cryptoShowWatchlist') !== '0';
    const showSig = localStorage.getItem('cryptoShowSignals') !== '0';
    
    const wlCb = document.getElementById('toggle-watchlist');
    const sigCb = document.getElementById('toggle-signals');
    if (wlCb) wlCb.checked = showWl;
    if (sigCb) sigCb.checked = showSig;
    
    if (!showWl) window.toggleSidebarPanel('watchlist', false);
    if (!showSig) window.toggleSidebarPanel('signals', false);
};

// =============================================================
// PANEL VERTICAL RESIZER - İzleme Listesi ↔ Sinyaller
// =============================================================
(function() {
    let panelResizing = false;
    let resizer, wlMod, sigMod, panelsRow;

    function initPanelResizer() {
        resizer = document.getElementById('panel-v-resizer');
        wlMod = document.getElementById('watchlist-module');
        sigMod = document.getElementById('signal-panel-module');
        panelsRow = document.querySelector('.sidebar-panels-row');

        if (!resizer || !panelsRow || !wlMod || !sigMod) {
            console.log('[PANEL-RESIZER] Elemanlar bulunamadi, 1 sn sonra tekrar denenecek');
            setTimeout(initPanelResizer, 1000);
            return;
        }

        // Kayıtlı genişlikleri yükle
        const savedWl = localStorage.getItem('cryptoWlPanelWidth');
        const savedSig = localStorage.getItem('cryptoSigPanelWidth');
        if (savedWl) wlMod.style.flex = '0 0 ' + savedWl + 'px';
        if (savedSig) sigMod.style.flex = '0 0 ' + savedSig + 'px';

        resizer.addEventListener('mousedown', function(e) {
            panelResizing = true;
            resizer.classList.add('active');
            document.body.style.cursor = 'col-resize';
            document.body.style.userSelect = 'none';
            e.preventDefault();
        });
    }

    document.addEventListener('mousemove', function(e) {
        if (!panelResizing || !panelsRow) return;
        const rect = panelsRow.getBoundingClientRect();
        let wlWidth = e.clientX - rect.left;
        const totalWidth = rect.width - 5;  // resizer payı
        
        // Min/max sınırlar
        if (wlWidth < 150) wlWidth = 150;
        if (wlWidth > totalWidth - 180) wlWidth = totalWidth - 180;
        
        const sigWidth = totalWidth - wlWidth;
        wlMod.style.flex = '0 0 ' + wlWidth + 'px';
        sigMod.style.flex = '0 0 ' + sigWidth + 'px';
        
        // Toast'ı yeniden boyutlandır
        if (window.resizeToastContainer) window.resizeToastContainer();
    });

    document.addEventListener('mouseup', function() {
        if (panelResizing) {
            panelResizing = false;
            if (resizer) resizer.classList.remove('active');
            document.body.style.cursor = 'default';
            document.body.style.userSelect = '';
            
            // Kaydet
            if (wlMod && sigMod) {
                localStorage.setItem('cryptoWlPanelWidth', wlMod.getBoundingClientRect().width);
                localStorage.setItem('cryptoSigPanelWidth', sigMod.getBoundingClientRect().width);
            }
            
            // Toast'ı güncelle
            if (window.resizeToastContainer) window.resizeToastContainer();
            
            // Grafikleri yeniden boyutlandır
            if (window.chartsData) {
                for (let i = 0; i < (window.chartCount || 1); i++) {
                    const cObj = chartsData[i];
                    if (cObj && cObj.chart) {
                        setTimeout(function() {
                            const container = document.getElementById('tvchart-' + i);
                            if (container) {
                                const r = container.getBoundingClientRect();
                                if (r.width > 0 && r.height > 0) {
                                    cObj.chart.applyOptions({ width: r.width, height: r.height });
                                }
                            }
                        }, 50);
                    }
                }
            }
        }
    });

    // Başlat
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(initPanelResizer, 500);
        });
    } else {
        setTimeout(initPanelResizer, 500);
    }
})();

// =============================================================
// TOAST DİNAMİK BOYUTLANDIRMA
// Toast'ı Canlı Bildirimler panelinin genişliğine hizala
// =============================================================
window.resizeToastContainer = function() {
    const container = document.getElementById('toast-container');
    const signalPanel = document.getElementById('signal-panel-module');
    const sidebar = document.getElementById('sidebar');
    
    if (!container) return;
    
    // Genişlik: signal panelinin genişliği
    let targetWidth = 320;
    if (signalPanel) {
        const w = signalPanel.getBoundingClientRect().width;
        if (w > 200) targetWidth = w;
    }
    container.style.width = targetWidth + 'px';
    container.style.maxWidth = targetWidth + 'px';
    
    // Pozisyon: sağ kenar sidebar'ın hemen solunda
    // Sidebar'ın sağ tarafı = ekranın sağ tarafı
    // Toast sağ kenarı = sidebar'ın SOLUNDA
    let rightOffset = 20;
    if (sidebar && sidebar.getBoundingClientRect().width > 0) {
        const sidebarWidth = sidebar.getBoundingClientRect().width;
        const resizerWidth = 12;  // drag-me + padding
        // Toast'ı sidebar'ın soluna koy
        // Yani sağ tarafı = sidebarWidth + resizer + margin
        rightOffset = sidebarWidth + resizerWidth + 10;
    }
    
    container.style.right = rightOffset + 'px';
};

// ResizeObserver ile sidebar ve signal panelini izle
if (window.ResizeObserver) {
    const toastResizeObserver = new ResizeObserver(function() {
        window.resizeToastContainer();
    });
    
    setTimeout(function() {
        const sidebar = document.getElementById('sidebar');
        const signalPanel = document.getElementById('signal-panel-module');
        if (sidebar) toastResizeObserver.observe(sidebar);
        if (signalPanel) toastResizeObserver.observe(signalPanel);
        window.resizeToastContainer();
    }, 1000);
}

// Pencere resize'ında da tetikle
window.addEventListener('resize', function() {
    if (window.resizeToastContainer) window.resizeToastContainer();
});

// =============================================================
// PANEL GENİŞLİK AYARLARI
// =============================================================
window.defaultPanelSettings = {
    sidebarWidth: 340,
    watchlistWidth: 165,
    toastWidth: 320,
};

window.currentPanelSettings = JSON.parse(localStorage.getItem('cryptoPanelSettings_v1')) || { ...window.defaultPanelSettings };

window.applyPanelSettings = function() {
    const s = window.currentPanelSettings;
    const root = document.documentElement;
    root.style.setProperty('--sidebar-width', s.sidebarWidth + 'px');
    root.style.setProperty('--watchlist-width', s.watchlistWidth + 'px');
    root.style.setProperty('--toast-width', s.toastWidth + 'px');
    console.log('[PANEL] Genişlikler uygulandı:', s);
};

window.savePanelSettings = function() {
    const sidebarEl = document.getElementById('cs-sidebar-width');
    const watchlistEl = document.getElementById('cs-watchlist-width');
    const toastEl = document.getElementById('cs-toast-width');
    
    if (!sidebarEl || !watchlistEl || !toastEl) return;
    
    window.currentPanelSettings = {
        sidebarWidth: parseInt(sidebarEl.value) || 340,
        watchlistWidth: parseInt(watchlistEl.value) || 165,
        toastWidth: parseInt(toastEl.value) || 320,
    };
    
    localStorage.setItem('cryptoPanelSettings_v1', JSON.stringify(window.currentPanelSettings));
    window.applyPanelSettings();
    window.showToast('Panel genişlikleri güncellendi', 'success', 2000);
};

window.loadPanelSettingsToModal = function() {
    const s = window.currentPanelSettings;
    const sidebarEl = document.getElementById('cs-sidebar-width');
    const watchlistEl = document.getElementById('cs-watchlist-width');
    const toastEl = document.getElementById('cs-toast-width');
    
    if (sidebarEl) sidebarEl.value = s.sidebarWidth;
    if (watchlistEl) watchlistEl.value = s.watchlistWidth;
    if (toastEl) toastEl.value = s.toastWidth;
};

window.resetPanelWidths = function() {
    const s = window.defaultPanelSettings;
    const sidebarEl = document.getElementById('cs-sidebar-width');
    const watchlistEl = document.getElementById('cs-watchlist-width');
    const toastEl = document.getElementById('cs-toast-width');
    
    if (sidebarEl) sidebarEl.value = s.sidebarWidth;
    if (watchlistEl) watchlistEl.value = s.watchlistWidth;
    if (toastEl) toastEl.value = s.toastWidth;
};

// Sayfa açılışında uygula
window.applyPanelSettings();

// Ayarlar modalı açıldığında input'ları doldur
(function() {
    const origOpen = window.openChartSettingsModal;
    window.openChartSettingsModal = function() {
        if (origOpen) origOpen.apply(this, arguments);
        setTimeout(function() {
            window.loadPanelSettingsToModal();
        }, 50);
    };
})();

// applyChartSettings'e panel settings kaydını ekle
(function() {
    const origApply = window.applyChartSettings;
    window.applyChartSettings = function() {
        if (origApply) origApply.apply(this, arguments);
        window.savePanelSettings();
    };
})();

// =============================================================
// TELEGRAM AYARLARI
// =============================================================
window.defaultTelegramSettings = {
    notify_signals: true,
    notify_closes: true,
    notify_delisting: true,
};

window.currentTelegramSettings = JSON.parse(localStorage.getItem('cryptoTelegramSettings_v1')) || { ...window.defaultTelegramSettings };





window.saveTelegramSettings = async function() {
    const el1 = document.getElementById('cs-tg-signals');
    const el2 = document.getElementById('cs-tg-closes');
    const el3 = document.getElementById('cs-tg-delist');
    
    const tgSettings = {
        notify_signals: el1 ? el1.checked : true,
        notify_closes: el2 ? el2.checked : true,
        notify_delisting: el3 ? el3.checked : true,
    };
    
    window.currentTelegramSettings = tgSettings;
    localStorage.setItem('cryptoTelegramSettings_v1', JSON.stringify(tgSettings));
    
    // ⚡ botConfig.telegram'ı da güncelle (modal tekrar açılınca doğru yüklenir)
    if (!window.botConfig.telegram) window.botConfig.telegram = {};
    window.botConfig.telegram.notify_signals = tgSettings.notify_signals;
    window.botConfig.telegram.notify_closes = tgSettings.notify_closes;
    window.botConfig.telegram.notify_delisting = tgSettings.notify_delisting;
    
    // Backend config'e de yaz
    try {
        const cfgRes = await fetch('/api/engine/config');
        const cfg = await cfgRes.json();
        
        if (!cfg.telegram) cfg.telegram = {};
        cfg.telegram.notify_signals = tgSettings.notify_signals;
        cfg.telegram.notify_closes = tgSettings.notify_closes;
        cfg.telegram.notify_delisting = tgSettings.notify_delisting;
        
        await fetch('/api/engine/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cfg)
        });
        console.log('[TG] Ayarlar kaydedildi:', tgSettings);
    } catch(e) {
        console.warn('[TG] Config kaydetme hatası:', e);
    }
};

window.testTelegram = async function() {
    const btn = document.getElementById('tg-test-btn');
    if (btn) btn.disabled = true;
    
    try {
        const res = await fetch('/api/telegram/test', { method: 'POST' });
        const data = await res.json();
        
        if (data.status === 'success') {
            window.showToast('📤 Test mesajı Telegram\'a gönderildi', 'success', 3000);
        } else {
            window.showToast('❌ Test başarısız: ' + (data.message || 'Bilinmeyen hata'), 'error', 5000);
        }
    } catch(e) {
        window.showToast('❌ Bağlantı hatası: ' + e.message, 'error', 5000);
    } finally {
        if (btn) btn.disabled = false;
    }
};



// =============================================================
// BUGÜNÜN İŞLEM RAPORU MODALI
// =============================================================
window.openDailyReportModal = async function() {
    const modal = document.getElementById('daily-report-modal');
    const tbody = document.getElementById('daily-report-tbody');
    if (!modal || !tbody) return;
    
    modal.classList.add('active');
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; color:#848e9c; padding:30px;">Yükleniyor...</td></tr>';
    
    try {
        const res = await fetch('/api/trade/history?limit=1000');
        let trades = await res.json();
        if (!Array.isArray(trades)) trades = [];
        
        // Bugün (TR saati) filtresi
        const todayStr = new Date().toDateString();
        let todayTrades = trades.filter(function(t) {
            return new Date(t.exit_time * 1000).toDateString() === todayStr;
        });
        
        // Saat sıralaması: en yeni en üstte
        todayTrades.sort(function(a, b) { return b.exit_time - a.exit_time; });
        
        // Özet
        let totalPnl = 0, wins = 0, losses = 0;
        todayTrades.forEach(function(t) {
            totalPnl += t.pnl_amount;
            if (t.pnl_amount >= 0) wins++; else losses++;
        });
        
        const totalSign = totalPnl >= 0 ? '+' : '';
        const totalColor = totalPnl >= 0 ? '#0ECB81' : '#F6465D';
        
        const summaryEl = document.getElementById('daily-modal-summary');
        if (summaryEl) {
            summaryEl.innerText = totalSign + totalPnl.toFixed(2) + ' USDT';
            summaryEl.style.color = totalColor;
        }
        
        const countEl = document.getElementById('daily-modal-count');
        if (countEl) countEl.innerText = todayTrades.length;
        
        const winsEl = document.getElementById('daily-modal-wins');
        if (winsEl) winsEl.innerText = wins;
        
        const lossesEl = document.getElementById('daily-modal-losses');
        if (lossesEl) lossesEl.innerText = losses;
        
        const winrateEl = document.getElementById('daily-modal-winrate');
        if (winrateEl) {
            const wr = todayTrades.length > 0 ? (wins / todayTrades.length * 100).toFixed(1) : '0';
            winrateEl.innerText = wr + '%';
        }
        
        // Bugün kapanan işlem yoksa
        if (todayTrades.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; color:#848e9c; padding:40px;">Bugün kapanan işlem yok.</td></tr>';
            return;
        }
        
        // Satırlar
        let html = '';
        let running = 0;  // kümülatif kâr
        // Eskiden yeniye göre kümülatif hesaplama için ters sırala
        const chrono = [...todayTrades].reverse();
        const cumMap = {};
        chrono.forEach(function(t) {
            running += t.pnl_amount;
            cumMap[t.id] = running;
        });
        
        todayTrades.forEach(function(t, i) {
            const isLong = t.trade_type === 'BUY';
            const tagClass = isLong ? 'pos-long' : 'pos-short';
            const tagText = isLong ? '▲ LONG' : '▼ SHORT';
            const isProfit = t.pnl_amount >= 0;
            const pnlColor = isProfit ? '#0ECB81' : '#F6465D';
            const sign = isProfit ? '+' : '';
            const cum = cumMap[t.id] || 0;
            const cumSign = cum >= 0 ? '+' : '';
            const cumColor = cum >= 0 ? '#0ECB81' : '#F6465D';
            
            // Saat
            const d = new Date(t.exit_time * 1000);
            const timeStr = String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
            
            // Sebep kısalt
            let reasonShort = '—';
            const reason = (t.close_reason || '').toUpperCase();
            if (reason.includes('TRAILING')) reasonShort = 'T';
            else if (reason.includes('STOP')) reasonShort = 'SL';
            else if (reason.includes('TAKE')) reasonShort = 'TP';
            else if (reason.includes('DELIST')) reasonShort = 'DEL';
            
            // DCA rozeti
            const dcaBadge = t.dca_count > 0 ? ' <span style="color:#fcd535; font-size:10px;">DCA:' + t.dca_count + '</span>' : '';
            
            const rowNum = todayTrades.length - i;
            
            html += '<tr style="border-bottom:1px solid #1e222d;">'
                + '<td class="left" style="color:#848e9c;">#' + rowNum + '</td>'
                + '<td class="left" style="font-weight:600;">' + t.symbol + dcaBadge + '</td>'
                + '<td class="left ' + tagClass + '">' + tagText + '</td>'
                + '<td class="right">' + window.formatPrice(t.entry_price) + '</td>'
                + '<td class="right">' + window.formatPrice(t.exit_price) + '</td>'
                + '<td class="right" style="color:' + pnlColor + '; font-weight:bold;">' + sign + t.pnl_pct.toFixed(2) + '%</td>'
                + '<td class="right" style="color:' + pnlColor + '; font-weight:bold;">' + sign + t.pnl_amount.toFixed(4) + ' USDT'
                + ' <span style="color:' + cumColor + '; font-size:10px;">(Σ ' + cumSign + cum.toFixed(4) + ')</span></td>'
                + '<td class="right"><span title="' + (t.close_reason || '') + '" style="font-size:10px; padding:2px 5px; background:rgba(252,213,53,0.1); color:#fcd535; border-radius:3px; cursor:help;">' + reasonShort + '</span></td>'
                + '<td class="right" style="color:#848e9c; font-size:11px;">' + timeStr + '</td>'
                + '</tr>';
        });
        
        tbody.innerHTML = html;
        
    } catch(e) {
        console.error('[DailyReport] Hata:', e);
        tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; color:#F6465D; padding:30px;">Hata: ' + e.message + '</td></tr>';
    }
};

window.closeDailyReportModal = function() {
    const modal = document.getElementById('daily-report-modal');
    if (modal) modal.classList.remove('active');
};

// ESC ile kapatma
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const m = document.getElementById('daily-report-modal');
        if (m && m.classList.contains('active')) {
            m.classList.remove('active');
        }
    }
});

window.checkTelegramStatus = async function() {
    const badge = document.getElementById('tg-status-badge');
    if (!badge) return;
    
    badge.className = 'tg-status-badge unknown';
    badge.innerHTML = '● Kontrol ediliyor...';
    
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        const res = await fetch('/api/telegram/status', { signal: controller.signal });
        clearTimeout(timeoutId);
        
        const data = await res.json();
        
        if (data.configured) {
            badge.className = 'tg-status-badge connected';
            badge.innerHTML = '● Bağlı';
        } else {
            badge.className = 'tg-status-badge error';
            badge.innerHTML = '● .env ayarları eksik';
        }
    } catch(e) {
        console.warn('[TG] Status hatası:', e);
        badge.className = 'tg-status-badge error';
        badge.innerHTML = '● Sunucu yanıt vermedi';
    }
};

// =============================================================
// AYARLAR MODALI HOOK - Telegram
// =============================================================
(function() {
    function setupTelegramHooks() {
        const origOpen = window.openChartSettingsModal;
        if (origOpen && !origOpen._tgHooked) {
            window.openChartSettingsModal = function() {
                origOpen.apply(this, arguments);
                setTimeout(function() {
                    window.loadTelegramSettingsToModal();
                    window.checkTelegramStatus();
                }, 100);
            };
            window.openChartSettingsModal._tgHooked = true;
            console.log('[TG] openChartSettingsModal hook kuruldu');
        }
        
        const origApply = window.applyChartSettings;
        if (origApply && !origApply._tgHooked) {
            window.applyChartSettings = function() {
                window.saveTelegramSettings();  // ⚡ önce kaydet
                origApply.apply(this, arguments);
            };
            window.applyChartSettings._tgHooked = true;
            console.log('[TG] applyChartSettings hook kuruldu');
        }
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(setupTelegramHooks, 200);
        });
    } else {
        setTimeout(setupTelegramHooks, 200);
    }
})();

// =============================================================
// KÂR / ZARAR TAKVİMİ (AY GÖRÜNÜMÜ)
// =============================================================
window.calData = {};           // {YYYY-MM-DD: {trades, net_pnl}}
window.calCurrentMonth = null; // Date objesi

window.openCalendarModal = async function() {
    const modal = document.getElementById('calendar-modal');
    if (!modal) return;
    
    if (!window.calCurrentMonth) {
        window.calCurrentMonth = new Date();
    }
    
    modal.classList.add('active');
    await window.loadCalendarData();
};

window.closeCalendarModal = function() {
    const modal = document.getElementById('calendar-modal');
    if (modal) modal.classList.remove('active');
};

window.loadCalendarData = async function() {
    try {
        const res = await fetch('/api/stats/daily?days=365');
        const data = await res.json();
        
        window.calData = {};
        if (Array.isArray(data)) {
            data.forEach(function(row) {
                window.calData[row.date] = {
                    trades: row.trades || 0,
                    net_pnl: row.net_pnl || 0,
                    wins: row.wins || 0,
                    losses: row.losses || 0,
                };
            });
        }
        window.renderCalendar();
    } catch(e) {
        console.error('[CAL] Veri yüklenemedi:', e);
    }
};

window.renderCalendar = function() {
    if (!window.calCurrentMonth) window.calCurrentMonth = new Date();
    
    const year = window.calCurrentMonth.getFullYear();
    const month = window.calCurrentMonth.getMonth();
    
    // Ay başlığı
    const months_tr = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
    const titleEl = document.getElementById('cal-month-title');
    if (titleEl) titleEl.innerText = months_tr[month] + ' ' + year;
    
    // Ay başı ve son günü
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const totalDays = lastDay.getDate();
    
    // Pazartesi başlangıç: JS getDay() 0=Pazar, 1=Pazartesi...
    // Pazartesi=0 olacak şekilde offset
    let startOffset = firstDay.getDay() - 1;
    if (startOffset < 0) startOffset = 6; // Pazar -> 6
    
    // Bugün
    const now = new Date();
    const trNow = new Date(now.getTime() + (3 * 60 * 60 * 1000));
    const todayKey = trNow.getUTCFullYear() + '-' +
                     String(trNow.getUTCMonth() + 1).padStart(2, '0') + '-' +
                     String(trNow.getUTCDate()).padStart(2, '0');
    
    // Grid oluştur
    const grid = document.getElementById('cal-grid');
    if (!grid) return;
    grid.innerHTML = '';
    
    // Boş günler
    for (let i = 0; i < startOffset; i++) {
        const empty = document.createElement('div');
        empty.className = 'cal-day cal-empty';
        grid.appendChild(empty);
    }
    
    // Ay içi günler
    let monthTotal = 0;
    let monthTrades = 0;
    let monthWins = 0;
    let monthLosses = 0;
    
    for (let d = 1; d <= totalDays; d++) {
        const dateKey = year + '-' + String(month + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
        const dayData = window.calData[dateKey] || null;
        
        const dayEl = document.createElement('div');
        dayEl.className = 'cal-day';
        
        // Bugün mü?
        if (dateKey === todayKey) {
            dayEl.classList.add('cal-day-today');
        }
        
        // Veri varsa kâr/zarar class'ı
        let pnlClass = 'empty';
        let pnlText = '—';
        let countText = '';
        
        if (dayData && dayData.trades > 0) {
            const pnl = dayData.net_pnl;
            if (pnl >= 0) {
                dayEl.classList.add('cal-day-profit');
                pnlClass = 'profit';
            } else {
                dayEl.classList.add('cal-day-loss');
                pnlClass = 'loss';
            }
            const sign = pnl >= 0 ? '+' : '';
            pnlText = sign + pnl.toFixed(2);
            countText = dayData.trades + ' işlem';
            dayEl.classList.add('cal-day-clickable');
            
            monthTotal += pnl;
            monthTrades += dayData.trades;
            if (pnl >= 0) monthWins++;
            else monthLosses++;
            
            // Tıklama: o günün işlemlerini göster
            dayEl.onclick = function() {
                window.showDayDetails(dateKey, dayData);
            };
        }
        
        dayEl.innerHTML =
            '<div class="cal-day-num">' + d + '</div>' +
            '<div class="cal-day-pnl ' + pnlClass + '">' + pnlText + '</div>' +
            '<div class="cal-day-count">' + countText + '</div>';
        
        grid.appendChild(dayEl);
    }
    
    // Ay toplamı
    const totalEl = document.getElementById('cal-month-total');
    if (totalEl) {
        const sign = monthTotal >= 0 ? '+' : '';
        totalEl.innerText = sign + monthTotal.toFixed(2) + ' USDT';
        totalEl.style.color = monthTotal >= 0 ? '#0ECB81' : '#F6465D';
    }
    
    // Footer özet
    const tradesEl = document.getElementById('cal-sum-trades');
    const winsEl = document.getElementById('cal-sum-wins');
    const lossesEl = document.getElementById('cal-sum-losses');
    if (tradesEl) tradesEl.innerText = monthTrades;
    if (winsEl) winsEl.innerText = monthWins;
    if (lossesEl) lossesEl.innerText = monthLosses;
};

window.calPrevMonth = function() {
    if (!window.calCurrentMonth) window.calCurrentMonth = new Date();
    window.calCurrentMonth.setMonth(window.calCurrentMonth.getMonth() - 1);
    window.renderCalendar();
};

window.calNextMonth = function() {
    if (!window.calCurrentMonth) window.calCurrentMonth = new Date();
    window.calCurrentMonth.setMonth(window.calCurrentMonth.getMonth() + 1);
    window.renderCalendar();
};

window.calGoToday = function() {
    window.calCurrentMonth = new Date();
    window.renderCalendar();
};

// Gün detaylarını göster (basit toast + detay modalı)
window.showDayDetails = async function(dateKey, dayData) {
    // Basit yaklaşım: detaylı işlemleri fetch et ve küçük bir modal göster
    try {
        const res = await fetch('/api/trade/history?limit=1000');
        let trades = await res.json();
        if (!Array.isArray(trades)) trades = [];
        
        // O günün işlemleri (TR saati ile)
        const [y, m, d] = dateKey.split('-').map(Number);
        const dayTrades = trades.filter(function(t) {
            const exitDate = new Date(t.exit_time * 1000);
            const trDate = new Date(exitDate.getTime() + (3 * 60 * 60 * 1000));
            return trDate.getUTCFullYear() === y &&
                   (trDate.getUTCMonth() + 1) === m &&
                   trDate.getUTCDate() === d;
        });
        
        // Toast mesajı
        const sign = dayData.net_pnl >= 0 ? '+' : '';
        window.showToast(
            dateKey + ' | ' + dayData.trades + ' işlem | ' + sign + dayData.net_pnl.toFixed(2) + ' USDT',
            dayData.net_pnl >= 0 ? 'success' : 'error',
            4000
        );
        
        // İlk 3 işlemi konsola yaz (debug için)
        console.log('[CAL] ' + dateKey + ' işlemleri:', dayTrades.slice(0, 5));
        
    } catch(e) {
        console.error('[CAL] Gün detayı hatası:', e);
    }
};

// ESC ile kapatma
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const m = document.getElementById('calendar-modal');
        if (m && m.classList.contains('active')) {
            m.classList.remove('active');
        }
    }
});

// =============================================================
// TELEGRAM BILDIRIM AYARLARI v3 (TEMIZ KURULUM)
// =============================================================

window._tgSettings = { notify_signals: true, notify_closes: true, notify_delisting: true };

window.loadTelegramSettingsToModal = function() {
    var s = { notify_signals: true, notify_closes: true, notify_delisting: true };
    try {
        var stored = localStorage.getItem('cryptoTgSettings_v3');
        if (stored) {
            var parsed = JSON.parse(stored);
            s.notify_signals = parsed.notify_signals !== false;
            s.notify_closes = parsed.notify_closes !== false;
            s.notify_delisting = parsed.notify_delisting !== false;
        }
    } catch(e) {}
    
    var el1 = document.getElementById('cs-tg-signals');
    var el2 = document.getElementById('cs-tg-closes');
    var el3 = document.getElementById('cs-tg-delist');
    if (el1) el1.checked = s.notify_signals;
    if (el2) el2.checked = s.notify_closes;
    if (el3) el3.checked = s.notify_delisting;
    
    window._tgSettings = s;
    console.log('[TG] Yuklendi:', s);
};

window.saveTelegramSettings = function() {
    var el1 = document.getElementById('cs-tg-signals');
    var el2 = document.getElementById('cs-tg-closes');
    var el3 = document.getElementById('cs-tg-delist');
    
    var s = {
        notify_signals: el1 ? el1.checked : true,
        notify_closes: el2 ? el2.checked : true,
        notify_delisting: el3 ? el3.checked : true
    };
    
    window._tgSettings = s;
    localStorage.setItem('cryptoTgSettings_v3', JSON.stringify(s));
    
    if (!window.botConfig) window.botConfig = {};
    if (!window.botConfig.telegram) window.botConfig.telegram = {};
    window.botConfig.telegram.notify_signals = s.notify_signals;
    window.botConfig.telegram.notify_closes = s.notify_closes;
    window.botConfig.telegram.notify_delisting = s.notify_delisting;
    
    fetch('/api/engine/config')
        .then(function(r) { return r.json(); })
        .then(function(cfg) {
            if (!cfg.telegram) cfg.telegram = {};
            cfg.telegram.notify_signals = s.notify_signals;
            cfg.telegram.notify_closes = s.notify_closes;
            cfg.telegram.notify_delisting = s.notify_delisting;
            return fetch('/api/engine/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cfg)
            });
        })
        .then(function() {
            console.log('[TG] Kaydedildi:', s);
        })
        .catch(function(e) {
            console.warn('[TG] Backend kaydetme hatasi:', e);
        });
};

(function() {
    function installHooks() {
        if (typeof window.openChartSettingsModal !== 'function') {
            setTimeout(installHooks, 300);
            return;
        }
        if (window.openChartSettingsModal._tgHooked) return;
        
        var origOpen = window.openChartSettingsModal;
        window.openChartSettingsModal = function() {
            origOpen.apply(this, arguments);
            setTimeout(function() {
                window.loadTelegramSettingsToModal();
                if (typeof window.checkTelegramStatus === 'function') {
                    window.checkTelegramStatus();
                }
            }, 150);
        };
        window.openChartSettingsModal._tgHooked = true;
        console.log('[TG] Open hook kuruldu');
        
        if (typeof window.applyChartSettings === 'function' && !window.applyChartSettings._tgHooked) {
            var origApply = window.applyChartSettings;
            window.applyChartSettings = function() {
                window.saveTelegramSettings();
                origApply.apply(this, arguments);
            };
            window.applyChartSettings._tgHooked = true;
            console.log('[TG] Apply hook kuruldu');
        }
    }
    installHooks();
})();

// =============================================================
// İSTATİSTİK MODAL
// =============================================================
window.statsCurrentTab = 'strategy';
window.statsData = { strategy: null, symbol: null, reason: null };

window.openStatsModal = function() {
    const modal = document.getElementById('stats-modal');
    if (!modal) return;
    modal.classList.add('active');
    window.switchStatsTab('strategy');
};

window.closeStatsModal = function() {
    const modal = document.getElementById('stats-modal');
    if (modal) modal.classList.remove('active');
};

window.switchStatsTab = function(tab) {
    window.statsCurrentTab = tab;
    
    document.querySelectorAll('.stats-tab').forEach(function(el) {
        if (el.dataset.tab === tab) el.classList.add('active');
        else el.classList.remove('active');
    });
    
    window.loadStatsContent(tab);
};

window.loadStatsContent = async function(tab) {
    const content = document.getElementById('stats-content');
    if (!content) return;
    content.innerHTML = '<div style="text-align:center; color:#848e9c; padding:40px;">Yükleniyor...</div>';
    
    try {
        // ⚡ ÖZET BAR: her zaman tüm verilerden hesapla
        const histRes = await fetch('/api/trade/history?limit=2000');
        const allTrades = await histRes.json();
        
        if (Array.isArray(allTrades) && allTrades.length > 0) {
            const validTrades = allTrades.filter(function(t) {
                return Math.abs(t.pnl_amount) < (t.total_vol * 5);
            });
            
            let totalTrades = validTrades.length;
            let totalPnl = 0;
            let wins = 0;
            validTrades.forEach(function(t) {
                totalPnl += t.pnl_amount;
                if (t.pnl_amount >= 0) wins++;
            });
            let wr = totalTrades > 0 ? (wins / totalTrades * 100) : 0;
            
            document.getElementById('stats-total-trades').innerText = totalTrades;
            const pnlEl = document.getElementById('stats-total-pnl');
            pnlEl.innerText = (totalPnl >= 0 ? '+' : '') + totalPnl.toFixed(2) + ' USDT';
            pnlEl.style.color = totalPnl >= 0 ? '#0ECB81' : '#F6465D';
            document.getElementById('stats-total-wr').innerText = wr.toFixed(1) + '%';
            
            // Gün sayısı
            const dailyRes = await fetch('/api/stats/daily?days=365');
            const dailyData = await dailyRes.json();
            let winDays = 0, lossDays = 0;
            if (Array.isArray(dailyData)) {
                dailyData.forEach(function(d) {
                    if (d.net_pnl > 0) winDays++;
                    else if (d.net_pnl < 0) lossDays++;
                });
            }
            document.getElementById('stats-days').innerText = winDays + ' / ' + lossDays;
        }
        
        // ⚡ TAB İÇERİĞİ
        if (tab === 'strategy') {
            const res = await fetch('/api/stats/strategies');
            const data = await res.json();
            if (!Array.isArray(data) || data.length === 0) {
                content.innerHTML = '<div style="text-align:center; color:#848e9c; padding:40px;">Henüz yeterli veri yok.</div>';
                return;
            }
            content.innerHTML = window.renderStrategyStats(data);
            
        } else if (tab === 'symbol') {
            const res = await fetch('/api/stats/symbols?min_trades=1');
            const data = await res.json();
            if (!Array.isArray(data) || data.length === 0) {
                content.innerHTML = '<div style="text-align:center; color:#848e9c; padding:40px;">Henüz yeterli veri yok.</div>';
                return;
            }
            content.innerHTML = window.renderSymbolStats(data);
            
        } else if (tab === 'reason') {
            const res = await fetch('/api/stats/close-reasons');
            const data = await res.json();
            if (!Array.isArray(data) || data.length === 0) {
                content.innerHTML = '<div style="text-align:center; color:#848e9c; padding:40px;">Henüz yeterli veri yok.</div>';
                return;
            }
            content.innerHTML = window.renderReasonStats(data);
        } else if (tab === 'count') {
            const res = await fetch('/api/stats/symbols-by-count?min_trades=1');
            const data = await res.json();
            if (!Array.isArray(data) || data.length === 0) {
                content.innerHTML = '<div style="text-align:center; color:#848e9c; padding:40px;">Henüz yeterli veri yok.</div>';
                return;
            }
            content.innerHTML = window.renderCountStats(data);
        }
        
    } catch(e) {
        console.error('[STATS] Hata:', e);
        content.innerHTML = '<div style="text-align:center; color:#F6465D; padding:40px;">Hata: ' + e.message + '</div>';
    }
};

window.wrBar = function(wr) {
    const cls = wr >= 60 ? 'good' : (wr >= 40 ? 'mid' : 'bad');
    return '<span class="wr-bar ' + cls + '"><div style="width:' + Math.min(100, wr) + '%"></div></span>' + wr.toFixed(1) + '%';
};

window.renderStrategyStats = function(data) {
    let html = '<table class="stats-table"><thead><tr>'
        + '<th class="left">Strateji</th>'
        + '<th>İşlem</th>'
        + '<th>Kârlı</th>'
        + '<th>Zararlı</th>'
        + '<th>Win Rate</th>'
        + '<th>Toplam PnL</th>'
        + '<th>Ort. PnL %</th>'
        + '<th>En İyi</th>'
        + '<th>En Kötü</th>'
        + '<th>Ort. DCA</th>'
        + '</tr></thead><tbody>';
    
    data.forEach(function(d) {
        const pnlCls = d.total_pnl >= 0 ? 'pnl-pos' : 'pnl-neg';
        const sign = d.total_pnl >= 0 ? '+' : '';
        html += '<tr>'
            + '<td class="left">' + (d.strategy_name || 'UNKNOWN') + '</td>'
            + '<td>' + d.total_trades + '</td>'
            + '<td style="color:#0ECB81;">' + d.wins + '</td>'
            + '<td style="color:#F6465D;">' + d.losses + '</td>'
            + '<td>' + window.wrBar(d.win_rate) + '</td>'
            + '<td class="' + pnlCls + '">' + sign + d.total_pnl.toFixed(4) + '</td>'
            + '<td>' + (d.avg_pnl_pct >= 0 ? '+' : '') + d.avg_pnl_pct.toFixed(2) + '%</td>'
            + '<td style="color:#0ECB81;">+' + d.best_trade.toFixed(4) + '</td>'
            + '<td style="color:#F6465D;">' + d.worst_trade.toFixed(4) + '</td>'
            + '<td>' + (d.avg_dca || 0).toFixed(2) + '</td>'
            + '</tr>';
    });
    
    html += '</tbody></table>';
    return html;
};

window.renderSymbolStats = function(data) {
    let html = '<table class="stats-table"><thead><tr>'
        + '<th class="left">#</th>'
        + '<th class="left">Sembol</th>'
        + '<th>İşlem</th>'
        + '<th>Kârlı</th>'
        + '<th>Zararlı</th>'
        + '<th>Win Rate</th>'
        + '<th>Toplam PnL</th>'
        + '<th>Ort. PnL %</th>'
        + '<th>En İyi</th>'
        + '<th>En Kötü</th>'
        + '</tr></thead><tbody>';
    
    data.forEach(function(d, i) {
        const pnlCls = d.total_pnl >= 0 ? 'pnl-pos' : 'pnl-neg';
        const sign = d.total_pnl >= 0 ? '+' : '';
        let rankCls = '';
        if (i === 0) rankCls = 'gold';
        else if (i === 1) rankCls = 'silver';
        else if (i === 2) rankCls = 'bronze';
        
        html += '<tr>'
            + '<td class="left"><span class="rank-badge ' + rankCls + '">' + (i + 1) + '</span></td>'
            + '<td class="left">' + d.symbol + '</td>'
            + '<td>' + d.trades + '</td>'
            + '<td style="color:#0ECB81;">' + d.wins + '</td>'
            + '<td style="color:#F6465D;">' + d.losses + '</td>'
            + '<td>' + window.wrBar(d.win_rate) + '</td>'
            + '<td class="' + pnlCls + '">' + sign + d.total_pnl.toFixed(4) + '</td>'
            + '<td>' + (d.avg_pnl_pct >= 0 ? '+' : '') + d.avg_pnl_pct.toFixed(2) + '%</td>'
            + '<td style="color:#0ECB81;">+' + d.best.toFixed(4) + '</td>'
            + '<td style="color:#F6465D;">' + d.worst.toFixed(4) + '</td>'
            + '</tr>';
    });
    
    html += '</tbody></table>';
    return html;
};

window.renderReasonStats = function(data) {
    let html = '<table class="stats-table"><thead><tr>'
        + '<th class="left">Kapanış Sebebi</th>'
        + '<th>İşlem</th>'
        + '<th>Kârlı</th>'
        + '<th>Win Rate</th>'
        + '<th>Toplam PnL</th>'
        + '<th>Ort. PnL %</th>'
        + '</tr></thead><tbody>';
    
    data.forEach(function(d) {
        const pnlCls = d.total_pnl >= 0 ? 'pnl-pos' : 'pnl-neg';
        const sign = d.total_pnl >= 0 ? '+' : '';
        const reasonEmoji = {
            'PARTIAL TP': '⚡',
            'TRAILING': '🎯',
            'STOP LOSS': '🛑',
            'DELISTED': '🚫',
            'TIME LIMIT': '⏰',
            'TAKE PROFIT': '✅',
            'DIGER': '❓'
        };
        const emoji = reasonEmoji[d.reason] || '❓';
        
        html += '<tr>'
            + '<td class="left">' + emoji + ' ' + d.reason + '</td>'
            + '<td>' + d.trades + '</td>'
            + '<td style="color:#0ECB81;">' + d.wins + '</td>'
            + '<td>' + window.wrBar(d.win_rate) + '</td>'
            + '<td class="' + pnlCls + '">' + sign + d.total_pnl.toFixed(4) + '</td>'
            + '<td>' + (d.avg_pnl_pct >= 0 ? '+' : '') + d.avg_pnl_pct.toFixed(2) + '%</td>'
            + '</tr>';
    });
    
    html += '</tbody></table>';
    return html;
};

// ESC ile kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const m = document.getElementById('stats-modal');
        if (m && m.classList.contains('active')) m.classList.remove('active');
    }
});

// =============================================================
// CFG LABEL TOOLTIP v2 (Event Delegation + JS Sozluk)
// =============================================================
(function setupCfgTooltipsV2() {
    const CFG_TIPS = {
        "Tarama Süresi": "Sembollerin kac saniyede bir taranacagi. Kucuk deger = daha sik tarama, daha fazla API kullanimi.",
        "Pozisyon Kontrol": "Acik pozisyonlarin TP/SL/Trailing icin kac saniyede bir kontrol edilecegi.",
        "Maks Sembol": "Taranacak maksimum sembol sayisi. Likiditeye gore en aktif USDT pariteleri secilir.",
        "Delist Kapat": "Bir sembol borsadan cikarilirsa otomatik olarak pozisyonu kapatir.",
        "Zaman Dilimi": "Stratejinin hangi mum periyodunda calisacagi (1m, 5m, 15m, 1h, 4h).",
        "RSI Period": "RSI hesaplama periyodu. Kucuk = daha hassas, buyuk = daha guvenilir.",
        "HMA Length": "Hull Hareketli Ortalama periyodu. Trend yonunu belirler.",
        "Kaynak": "HMA hesaplamasinda kullanilacak fiyat kaynagi (hl2, close, open).",
        "Long Trade": "Yukari yonlu (alis) sinyalleri acilsin mi?",
        "Min Volatilite (ATR %)": "Minimum ATR% volatilite. Bu degerin altindaki coinlerde sinyal uretilmez. 0 = filtre kapali.",
        "Short Trade": "Asagi yonlu (satis) sinyalleri acilsin mi?",
        "Geriye Dönük Tarama": "Pivot noktalarini bulmak icin geriye bakilacak mum sayisi.",
        "Izgara Tipi": "Geometrik: esit % araliklarla. Aritmetik: esit mutlak araliklarla.",
        "Izgara Sayısı": "Toplam izgara seviyesi sayisi (merkez alti + ustu). 20 = 10 BUY + 10 SELL.",
        "SMA Periyot": "Izgara merkezini belirleyen SMA periyodu. Buyuk deger = daha stabil merkez.",
        "ATR Periyot": "ATR periyodu. Piyasa volatilitesini olcer.",
        "ATR Çarpan": "Izgara genisligi carpani. Genislik = ATR x bu deger.",
        "İlk İşlem": "Pozisyon acilisinda kullanilacak USDT miktari (kaldiracli degil, saf teminat).",
        "Kaldıraç": "1 = kaldiracli degil. 5x = 5 kat. Kar/zarar kaldiracli oraninda buyur, tasfiye riski artar.",
        "Marjin": "Bu pozisyon icin hesabinizda kilitlenen gercek teminat = Ilk Islem / Kaldiracli.",
        "Hedef Kâr": "Pozisyon bu kar yuzdesine ulastiginda Izleyen Stop aktif olur. Ornek: 1.5 = %1.5 kar.",
        "İzleyen Stop": "Fiyat tepe noktasindan bu yuzde kadar geri cekilirse pozisyon kapatilir. Kari korur.",
        "Stop Loss": "Fiyat girise gore bu yuzde ters giderse pozisyon otomatik kapanir. Zarari sinirlar.",
        "DCA Aktif": "Kademeli alim. Fiyat ters giderse ek alim yapar ve ortalama maliyeti dusurur.",
        "Hacim Çarpanı": "Her DCA kademesinde eklenecek hacim carpani. 1.2 = her kademe 1.2x onceki hacim.",
        "Düşüş Adımları": "Her DCA kademesinin hangi yuzde dususte tetiklenecegi. Ornek: 5,10,15,20.",
        "Kısmi TP Aktif": "Pozisyon kara gectiginde tamamini kapatmak yerine bir kismini kapatir, kalani trendde tutar.",
        "Kapatma Oranı": "Kismi TP'de kapatilacak pozisyon yuzdesi. 50 = pozisyonun yarisi kapatilir.",
        "PT Sonrası DCA": "Kismi TP sonrasi kalan pozisyon icin DCA kademeleri aktif kalsin mi?",
        "Günlük Max Zarar": "Bugunun toplam net zarari bu degeri asarsa yeni sinyaller acilmaz. 0 = devre disi.",
        "Max Açık Pozisyon": "Ayni anda acik olabilecek maksimum pozisyon sayisi. 0 = sinirsiz.",
    };

    function getTooltip() {
        let tip = document.getElementById('cfg-tooltip');
        if (!tip) {
            tip = document.createElement('div');
            tip.id = 'cfg-tooltip';
            document.body.appendChild(tip);
        }
        return tip;
    }

    function findTipText(el) {
        // 1) data-tip varsa onu kullan
        const dt = el.getAttribute('data-tip');
        if (dt) return dt;
        // 2) Yoksa metinden sozluge bak
        const txt = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (CFG_TIPS[txt]) return CFG_TIPS[txt];
        for (const key in CFG_TIPS) {
            if (txt.startsWith(key)) return CFG_TIPS[key];
        }
        return null;
    }

    function positionTooltip(el, tip) {
        const rect = el.getBoundingClientRect();
        const tipRect = tip.getBoundingClientRect();
        const spaceAbove = rect.top;
        const spaceBelow = window.innerHeight - rect.bottom;

        let top, posClass;
        if (spaceAbove >= tipRect.height + 12 || spaceAbove >= spaceBelow) {
            top = rect.top - tipRect.height - 10;
            posClass = 'pos-top';
        } else {
            top = rect.bottom + 10;
            posClass = 'pos-bottom';
        }

        let left = rect.left;
        if (left + tipRect.width > window.innerWidth - 15) {
            left = window.innerWidth - tipRect.width - 15;
        }
        if (left < 10) left = 10;

        tip.style.top = top + 'px';
        tip.style.left = left + 'px';
        tip.className = posClass;

        const arrowLeft = Math.max(10, Math.min(tipRect.width - 20, rect.left - left + 10));
        tip.style.setProperty('--arrow-left', arrowLeft + 'px');
    }

    let currentEl = null;

    function showTip(el, text) {
        const tip = getTooltip();
        tip.textContent = text;
        tip.style.display = 'block';
        tip.style.opacity = '0';
        positionTooltip(el, tip);
        requestAnimationFrame(function() {
            tip.classList.add('show');
            tip.style.opacity = '';
        });
        currentEl = el;
    }

    function hideTip() {
        const tip = document.getElementById('cfg-tooltip');
        if (tip) {
            tip.classList.remove('show');
            setTimeout(function() { tip.style.display = 'none'; }, 150);
        }
        currentEl = null;
    }

    // ⚡ EVENT DELEGATION - document seviyesinde dinle
    document.addEventListener('mouseover', function(e) {
        const el = e.target.closest ? e.target.closest('.cfg-label') : null;
        if (!el) return;
        if (el === currentEl) return;
        const txt = findTipText(el);
        if (!txt) return;
        if (currentEl) hideTip();
        showTip(el, txt);
    }, true);

    document.addEventListener('mouseout', function(e) {
        const el = e.target.closest ? e.target.closest('.cfg-label') : null;
        if (!el) return;
        // Ilgili baska bir cfg-label'a gecmediyse kapat
        const related = e.relatedTarget && e.relatedTarget.closest ? e.relatedTarget.closest('.cfg-label') : null;
        if (related === el) return;
        if (currentEl === el) hideTip();
    }, true);

    console.log('[TOOLTIP v2] Event delegation kuruldu. Sozluk:', Object.keys(CFG_TIPS).length, 'alan');
})();

// =============================================================
// DEV TOOLS - Backend restart / stop / reload
// =============================================================
// ⚠️ DEPRECATED: --reload modunda calismaz, buton kaldirildi.
// Terminalden Ctrl+C ile durdurun.
window.devStopBackend = async function() {
    const ok = await window.showConfirm(
        '⏹ BACKEND DURDUR',
        'Backend kapatılsın mı?\n\n' +
        '• Bot çalışıyorsa durur\n' +
        '• Sayfa veri çekemez hale gelir\n' +
        '• Yeniden başlatmak için terminalden:\n' +
        '   py -m uvicorn backend.main:app --reload',
        'DURDUR',
        'İPTAL',
        'danger'
    );
    if (!ok) return;
    try {
        window.showToast('⏹ Backend kapatılıyor...', 'warning', 3000);
        await fetch('/api/dev/stop', { method: 'POST' });
    } catch(e) {
        // Beklenen: process öldüğü için bağlantı kesilir
        console.log('[DEV] Stop response alinamadi (beklenen)');
    }
};

window.devRestartBackend = async function() {
    try {
        const res = await fetch('/api/dev/restart', { method: 'POST' });
        const data = await res.json();
        if (data.status === 'success') {
            window.showToast('🔄 Backend yeniden başlatılıyor... (3-5 sn)', 'info', 3500);
        } else {
            window.showToast('❌ Restart hatası: ' + (data.message || 'bilinmeyen'), 'error', 4000);
        }
    } catch(e) {
        window.showToast('❌ Restart başarısız: ' + e.message, 'error', 4000);
    }
};

window.devHardReload = function() {
    window.showToast('⚡ Sayfa yenileniyor...', 'info', 1200);
    setTimeout(function() {
        try {
            location.reload(true);
        } catch(e) {
            location.reload();
        }
    }, 300);
};

// =============================================================
// COIN ISLEM SAYISI (Istatistik - Yeni Sekme)
// =============================================================
window.renderCountStats = function(data) {
    let html = '<table class="stats-table"><thead><tr>'
        + '<th class="left">#</th>'
        + '<th class="left">Sembol</th>'
        + '<th>İşlem</th>'
        + '<th>Kârlı</th>'
        + '<th>Zararlı</th>'
        + '<th>Win Rate</th>'
        + '<th>Toplam PnL</th>'
        + '<th>Ort. PnL %</th>'
        + '<th>En İyi</th>'
        + '<th>En Kötü</th>'
        + '</tr></thead><tbody>';
    
    data.forEach(function(d, i) {
        const pnlCls = d.total_pnl >= 0 ? 'pnl-pos' : 'pnl-neg';
        const sign = d.total_pnl >= 0 ? '+' : '';
        let rankCls = '';
        if (i === 0) rankCls = 'gold';
        else if (i === 1) rankCls = 'silver';
        else if (i === 2) rankCls = 'bronze';
        
        html += '<tr>'
            + '<td class="left"><span class="rank-badge ' + rankCls + '">' + (i + 1) + '</span></td>'
            + '<td class="left" style="cursor:pointer; color:#79a0ff; font-weight:600;" onclick="window.changeSymbol(\'' + d.symbol + '.P\')">' + d.symbol + '</td>'
            + '<td style="color:#fcd535; font-weight:bold; font-size:13px;">' + d.trades + '</td>'
            + '<td style="color:#0ECB81;">' + d.wins + '</td>'
            + '<td style="color:#F6465D;">' + d.losses + '</td>'
            + '<td>' + window.wrBar(d.win_rate) + '</td>'
            + '<td class="' + pnlCls + '">' + sign + d.total_pnl.toFixed(4) + '</td>'
            + '<td>' + (d.avg_pnl_pct >= 0 ? '+' : '') + d.avg_pnl_pct.toFixed(2) + '%</td>'
            + '<td style="color:#0ECB81;">+' + d.best.toFixed(4) + '</td>'
            + '<td style="color:#F6465D;">' + d.worst.toFixed(4) + '</td>'
            + '</tr>';
    });
    
    html += '</tbody></table>';
    return html;
};

// =============================================================
// GRID V2 - SMA + ATR tabanli gercek grid (chart visualization)
// Backend'deki gridbot.py ile ayni formulu kullanir
// =============================================================
(function() {
    // Eski tanimi sakla (fallback icin)
    window._calcGridbotScalperOriginal = window.calcGridbotScalper;

    // --- Yardimci: SMA ---
    function _gridCalcSMA(closes, period) {
        const result = [];
        for (let i = 0; i < closes.length; i++) {
            if (i < period - 1) { result.push(null); continue; }
            let sum = 0;
            for (let j = 0; j < period; j++) sum += closes[i - j];
            result.push(sum / period);
        }
        return result;
    }

    // --- Yardimci: ATR (Wilder smoothing) ---
    function _gridCalcATR(data, period) {
        const result = [];
        const trs = [null];
        for (let i = 1; i < data.length; i++) {
            const tr = Math.max(
                data[i].high - data[i].low,
                Math.abs(data[i].high - data[i-1].close),
                Math.abs(data[i].low - data[i-1].close)
            );
            trs.push(tr);
        }
        let atr = null;
        for (let i = 0; i < data.length; i++) {
            if (i < period) { result.push(null); continue; }
            if (i === period) {
                let sum = 0;
                for (let j = 1; j <= period; j++) sum += trs[j];
                atr = sum / period;
                result.push(atr);
            } else {
                atr = (atr * (period - 1) + trs[i]) / period;
                result.push(atr);
            }
        }
        return result;
    }

    // --- Yardimci: Grid seviyeleri ---
    function _buildGridLevels(center, width, count, type) {
        const levels = [];
        const half = Math.max(1, Math.floor(count / 2));

        if (type === 'geometric') {
            const halfPct = (width / 2) / center;
            const stepPct = halfPct / half;
            for (let i = -half; i <= half; i++) {
                const price = center * Math.pow(1 + stepPct, i);
                levels.push({
                    index: i,
                    price: price,
                    side: i < 0 ? 'BUY' : (i > 0 ? 'SELL' : 'CENTER')
                });
            }
        } else {
            const step = (width / 2) / half;
            for (let i = -half; i <= half; i++) {
                const price = center + (i * step);
                if (price <= 0) continue;
                levels.push({
                    index: i,
                    price: price,
                    side: i < 0 ? 'BUY' : (i > 0 ? 'SELL' : 'CENTER')
                });
            }
        }
        return levels;
    }

    // --- Ana Fonksiyon ---
    window.calcGridbotScalper = function(data, params, cObj, isBackground) {
        if (!cObj.gridLineSeries) cObj.gridLineSeries = [];

        // Onceki grid cizgilerini temizle
        if (cObj.chart && cObj.gridLineSeries.length > 0) {
            cObj.gridLineSeries.forEach(function(ls) {
                try { cObj.chart.removeSeries(ls); } catch(e) {}
            });
            cObj.gridLineSeries = [];
        }

        const markers = [];
        const tradeLabels = [];
        const generatedHistory = [];

        // Parametreler
        const gridType = params.gridType || 'geometric';
        const gridCount = parseInt(params.gridCount) || 20;
        const smaPeriod = parseInt(params.smaPeriod) || 100;
        const atrPeriod = parseInt(params.atrPeriod) || 14;
        const atrMultiplier = parseFloat(params.atrMultiplier) || 5;

        const minNeeded = Math.max(smaPeriod, atrPeriod) + 5;
        if (!data || data.length < minNeeded) {
            return { markers: markers, lastTrade: null, tradeLabels: tradeLabels };
        }

        // Hesapla
        const closes = data.map(function(d) { return d.close; });
        const sma = _gridCalcSMA(closes, smaPeriod);
        const atr = _gridCalcATR(data, atrPeriod);

        const lastIdx = data.length - 1;
        const center = sma[lastIdx];
        const curATR = atr[lastIdx];

        if (center === null || curATR === null || center <= 0) {
            return { markers: markers, lastTrade: null, tradeLabels: tradeLabels };
        }

        // Grid seviyeleri
        const width = curATR * atrMultiplier;
        const levels = _buildGridLevels(center, width, gridCount, gridType);

        // Cizim
        if (cObj.chart && data.length > 0) {
            const startTime = data[Math.max(0, lastIdx - 100)].time;
            const endTime = data[lastIdx].time;

            for (let k = 0; k < levels.length; k++) {
                const lvl = levels[k];
                let color, lw, dashed;

                if (lvl.side === 'BUY') {
                    color = 'rgba(14, 203, 129, 0.35)';
                    lw = 1;
                    dashed = true;
                } else if (lvl.side === 'SELL') {
                    color = 'rgba(246, 70, 93, 0.35)';
                    lw = 1;
                    dashed = true;
                } else {
                    color = 'rgba(41, 98, 255, 0.9)';
                    lw = 2;
                    dashed = false;
                }

                try {
                    const ls = cObj.chart.addLineSeries({
                        color: color,
                        lineWidth: lw,
                        lineStyle: dashed ? 2 : 0,
                        crosshairMarkerVisible: false,
                        lastValueVisible: false,
                        priceLineVisible: false,
                        autoscaleInfoProvider: function() { return null; }
                    });
                    ls.setData([
                        { time: startTime, value: lvl.price },
                        { time: endTime, value: lvl.price }
                    ]);
                    cObj.gridLineSeries.push(ls);
                } catch(e) {}
            }
        }

        // Meta bilgiyi cObj'e kaydet
        cObj.gridMeta = {
            center: center,
            width: width,
            levels: levels,
            sma: center,
            atr: curATR,
            gridType: gridType,
            gridCount: gridCount
        };

        window.syncHistoricalTrades(generatedHistory);
        return { markers: markers, lastTrade: null, tradeLabels: tradeLabels };
    };

    console.log('[GRID-V2] Grid visualization aktif - SMA+ATR tabanli');
})();

// =============================================================
// GRID DIM MODE - Marker soluklastirma
// =============================================================
window._dimColor = function(hex, alpha) {
    if (!hex) return hex;
    if (hex.indexOf('rgba') === 0 || hex.indexOf('rgb') === 0) return hex;
    if (hex.charAt(0) !== '#') return hex;
    try {
        const r = parseInt(hex.substr(1, 2), 16);
        const g = parseInt(hex.substr(3, 2), 16);
        const b = parseInt(hex.substr(5, 2), 16);
        return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
    } catch(e) {
        return hex;
    }
};

window._gridDimDefault = (localStorage.getItem('cryptoGridDimMode') !== '0'); // default: true

window.toggleGridDim = function(idx) {
    const cObj = chartsData[idx];
    if (!cObj) return;
    const current = (cObj.gridDimMode !== undefined) ? cObj.gridDimMode : window._gridDimDefault;
    cObj.gridDimMode = !current;
    localStorage.setItem('cryptoGridDimMode', cObj.gridDimMode ? '1' : '0');
    window.recalculateAllIndicators(idx);
    if (window.showToast) {
        window.showToast(
            cObj.gridDimMode ? '🎨 Grid vurgusu: AÇIK (markerlar soluk)' : '🎨 Grid vurgusu: KAPALI (markerlar net)',
            'info',
            1500
        );
    }
};

// =============================================================
// BACKTEST MODAL - JS Logic
// =============================================================
window._btState = { taskId: null, interval: null, currentResult: null, mode: 'futures' };

window.openBacktestModal = function() {
    document.getElementById('backtest-modal').classList.add('active');
    // Form sifirla
    document.getElementById('bt-form-section').style.display = 'block';
    document.getElementById('bt-progress-section').style.display = 'none';
    document.getElementById('bt-result-section').style.display = 'none';

    // Aktif tab'a gore mode sec
    const _at = (typeof activeTab !== 'undefined') ? activeTab : 'futures';
    window._btState.mode = (_at === 'spot') ? 'spot' : 'futures';

    // Mode butonlarini guncelle
    document.querySelectorAll('.bt-mode-btn').forEach(function(btn) {
        if (btn.dataset.mode === window._btState.mode) btn.classList.add('active');
        else btn.classList.remove('active');
    });

    // Sembol listesini doldur
    window._populateBtSymbols();

    // Placeholder
    const symEl = document.getElementById('bt-symbol');
    if (symEl) {
        symEl.placeholder = window._btState.mode === 'futures' ? 'Vadeli sembol ara...' : 'Spot sembol ara...';
    }

    // Varsayilan strateji parametrelerini yukle
    window.onBtStrategyChange();
};

window.setBtMode = function(mode) {
    window._btState.mode = mode;
    document.querySelectorAll('.bt-mode-btn').forEach(function(btn) {
        if (btn.dataset.mode === mode) btn.classList.add('active');
        else btn.classList.remove('active');
    });
    // Listeyi yeniden doldur
    window._populateBtSymbols();
    // Sembol input'u temizle
    const symEl = document.getElementById('bt-symbol');
    if (symEl) {
        symEl.value = '';
        symEl.placeholder = mode === 'futures' ? 'Vadeli sembol ara...' : 'Spot sembol ara...';
    }
};

window._populateBtSymbols = function() {
    const listEl = document.getElementById('bt-symbol-list');
    if (!listEl) return;

    const mode = window._btState.mode || 'futures';
    let symbols = [];

    // ⚡ Onemli: Bu degiskenler modul scope'unda (let ile) tanimli.
    // window. ile erisilemiyorlar. Dogrudan kullan.
    try {
        if (mode === 'futures') {
            // 1) Oncelik: canli sembol seti (exchange info'dan)
            try {
                if (typeof activeFuturesSymbols !== 'undefined' &&
                    activeFuturesSymbols && activeFuturesSymbols.size > 0) {
                    symbols = Array.from(activeFuturesSymbols);
                }
            } catch(e1) {}

            // 2) Fallback: futuresData array'i (WS ticker'lari)
            if (symbols.length === 0) {
                try {
                    if (typeof futuresData !== 'undefined' && Array.isArray(futuresData)) {
                        symbols = futuresData.map(function(d) { return d.symbol; });
                    }
                } catch(e2) {}
            }
        } else {
            try {
                if (typeof activeSpotSymbols !== 'undefined' &&
                    activeSpotSymbols && activeSpotSymbols.size > 0) {
                    symbols = Array.from(activeSpotSymbols);
                }
            } catch(e1) {}

            if (symbols.length === 0) {
                try {
                    if (typeof spotData !== 'undefined' && Array.isArray(spotData)) {
                        symbols = spotData.map(function(d) { return d.symbol; });
                    }
                } catch(e2) {}
            }
        }
    } catch(e) { console.warn('[BT] Sym populate error:', e); }

    if (symbols.length === 0) {
        symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT',
                   'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT', 'LINKUSDT', 'MATICUSDT'];
    }

    symbols = symbols.filter(function(s) { return s && typeof s === 'string' && s.endsWith('USDT'); });
    // Duplicate temizle
    symbols = Array.from(new Set(symbols));
    symbols.sort();

    listEl.innerHTML = symbols.map(function(s) {
        return '<option value="' + s + '"></option>';
    }).join('');
    console.log('[BT] ' + symbols.length + ' ' + mode + ' sembol yuklendi');
};

window.closeBacktestModal = function() {
    document.getElementById('backtest-modal').classList.remove('active');
    if (window._btState.interval) {
        clearInterval(window._btState.interval);
        window._btState.interval = null;
    }
};

window.onBtStrategyChange = function() {
    const strat = document.getElementById('bt-strategy').value;
    const content = document.getElementById('bt-params-content');
    
    // Config'den mevcut strateji parametrelerini al
    let params = {};
    try {
        const cfgRes = window.botConfig || {};
        const stratCfg = (cfgRes.strategies || {})[strat] || {};
        params = { ...stratCfg };
    } catch(e) {}
    
    let html = '';
    
    if (strat === 'RSI_SCALPER') {
        html = `
            <div class="bt-param-row"><label>RSI Period</label><input type="number" id="btp-period" value="${params.period || 7}"></div>
            <div class="bt-param-row"><label>LONG Eşik</label><input type="number" id="btp-longVal" value="${params.longVal || 20}"></div>
            <div class="bt-param-row"><label>SHORT Eşik</label><input type="number" id="btp-shortVal" value="${params.shortVal || 80}"></div>
        `;
    } else if (strat === 'HULL_SRP') {
        html = `
            <div class="bt-param-row"><label>HMA Period</label><input type="number" id="btp-period" value="${params.period || 10}"></div>
            <div class="bt-param-row"><label>Kaynak</label>
                <select id="btp-source">
                    <option value="hl2" ${params.source === 'hl2' ? 'selected' : ''}>HL2</option>
                    <option value="close" ${params.source === 'close' ? 'selected' : ''}>Close</option>
                    <option value="open" ${params.source === 'open' ? 'selected' : ''}>Open</option>
                </select>
            </div>
        `;
    } else if (strat === 'GRIDBOT') {
        html = `
            <div class="bt-param-row"><label>Izgara Tipi</label>
                <select id="btp-gridType">
                    <option value="geometric" ${params.gridType === 'geometric' ? 'selected' : ''}>Geometrik</option>
                    <option value="arithmetic" ${params.gridType === 'arithmetic' ? 'selected' : ''}>Aritmetik</option>
                </select>
            </div>
            <div class="bt-param-row"><label>Izgara Sayısı</label><input type="number" id="btp-gridCount" value="${params.gridCount || 20}"></div>
            <div class="bt-param-row"><label>SMA Period</label><input type="number" id="btp-smaPeriod" value="${params.smaPeriod || 100}"></div>
            <div class="bt-param-row"><label>ATR Period</label><input type="number" id="btp-atrPeriod" value="${params.atrPeriod || 14}"></div>
            <div class="bt-param-row"><label>ATR Çarpan</label><input type="number" id="btp-atrMultiplier" value="${params.atrMultiplier || 5}" step="0.5"></div>
        `;
    }
    
    // Ortak parametreler
    const _dir = params.tradeDirection || 'both';
    html += `
        <div class="bt-param-row" style="grid-column: span 3; border-bottom: 1px dashed #2a2e39; padding-bottom: 8px; margin-bottom: 4px;">
            <label style="color:#fcd535;">İşlem Yönü</label>
            <select id="btp-tradeDirection" style="max-width: 200px;">
                <option value="long" ${_dir === 'long' ? 'selected' : ''}>▲ Long (Sadece Alış)</option>
                <option value="short" ${_dir === 'short' ? 'selected' : ''}>▼ Short (Sadece Satış)</option>
                <option value="both" ${_dir === 'both' ? 'selected' : ''}>◆ Tümü (Long + Short)</option>
            </select>
        </div>
        <div class="bt-param-row"><label>İlk İşlem (USDT)</label><input type="number" id="btp-baseOrder" value="${params.baseOrder || 10}"></div>
        <div class="bt-param-row"><label>Kaldıraç</label><input type="number" id="btp-leverage" value="${params.leverage || 1}"></div>
        <div class="bt-param-row"><label>Hedef Kâr (%)</label><input type="number" id="btp-takeProfit" value="${params.takeProfit || 1.5}" step="0.1"></div>
        <div class="bt-param-row"><label>İzleyen Stop (%)</label><input type="number" id="btp-trailing" value="${params.trailing || 0.3}" step="0.1"></div>
        <div class="bt-param-row"><label>Stop Loss (%)</label><input type="number" id="btp-stopLoss" value="${params.stopLoss || 3}" step="0.1"></div>
        <div class="bt-param-row"><label>DCA Aktif</label>
            <select id="btp-useDCA">
                <option value="true" ${params.useDCA ? 'selected' : ''}>Evet</option>
                <option value="false" ${!params.useDCA ? 'selected' : ''}>Hayır</option>
            </select>
        </div>
        <div class="bt-param-row"><label>Hacim Çarpanı</label><input type="number" id="btp-volMultiplier" value="${params.volMultiplier || 1.2}" step="0.1"></div>
        <div class="bt-param-row"><label>Düşüş Adımları</label><input type="text" id="btp-steps" value="${params.steps || '1.5, 3, 5'}"></div>
    `;
    
    content.innerHTML = html;
};

window._collectBtParams = function() {
    const strat = document.getElementById('bt-strategy').value;
    const params = {};
    
    // Common
    const common = ['baseOrder', 'leverage', 'takeProfit', 'trailing', 'stopLoss', 'volMultiplier', 'steps'];
    common.forEach(k => {
        const el = document.getElementById('btp-' + k);
        if (el) {
            const v = el.value;
            if (k === 'steps') params[k] = v;
            else if (k === 'leverage' || k === 'baseOrder') params[k] = parseInt(v) || 0;
            else params[k] = parseFloat(v) || 0;
        }
    });
    
    const dcaEl = document.getElementById('btp-useDCA');
    if (dcaEl) params.useDCA = dcaEl.value === 'true';

    const dirEl = document.getElementById('btp-tradeDirection');
    if (dirEl) params.tradeDirection = dirEl.value || 'both';
    
    // Strategy-specific
    if (strat === 'RSI_SCALPER') {
        params.period = parseInt(document.getElementById('btp-period')?.value) || 7;
        params.longOp = '<';
        params.longVal = parseInt(document.getElementById('btp-longVal')?.value) || 20;
        params.shortOp = '>';
        params.shortVal = parseInt(document.getElementById('btp-shortVal')?.value) || 80;
    } else if (strat === 'HULL_SRP') {
        params.period = parseInt(document.getElementById('btp-period')?.value) || 10;
        params.source = document.getElementById('btp-source')?.value || 'hl2';
        // longTrade/shortTrade artik tradeDirection ile yonetiliyor
    } else if (strat === 'GRIDBOT') {
        params.gridType = document.getElementById('btp-gridType')?.value || 'geometric';
        params.gridCount = parseInt(document.getElementById('btp-gridCount')?.value) || 20;
        params.smaPeriod = parseInt(document.getElementById('btp-smaPeriod')?.value) || 100;
        params.atrPeriod = parseInt(document.getElementById('btp-atrPeriod')?.value) || 14;
        params.atrMultiplier = parseFloat(document.getElementById('btp-atrMultiplier')?.value) || 5;
    }
    
    return params;
};

window.startBacktest = async function() {
    const symbol = document.getElementById('bt-symbol').value.trim().toUpperCase();
    const strategy = document.getElementById('bt-strategy').value;
    const interval = document.getElementById('bt-interval').value;
    const initialBalance = parseFloat(document.getElementById('bt-balance').value) || 1000;
    const startDateVal = document.getElementById('bt-start-date').value;
    
    if (!symbol) {
        window.showToast('❌ Sembol gerekli', 'error');
        return;
    }
    
    const params = window._collectBtParams();
    
    let startDate = null;
    if (startDateVal && startDateVal.trim()) {
        // GG-AA-YYYY parse
        const _parts = startDateVal.trim().split(/[\-\/\.]/);
        if (_parts.length === 3) {
            const _d = parseInt(_parts[0]);
            const _m = parseInt(_parts[1]) - 1;
            const _y = parseInt(_parts[2]);
            if (_d > 0 && _m >= 0 && _m <= 11 && _y > 2000) {
                startDate = new Date(_y, _m, _d, 0, 0, 0).getTime();
            }
        }
        if (!startDate) {
            window.showToast('❌ Tarih formati: GG-AA-YYYY (ornek: 15-03-2024)', 'error', 4000);
            return;
        }
    }
    
    // UI: form gizle, progress goster
    document.getElementById('bt-form-section').style.display = 'none';
    document.getElementById('bt-progress-section').style.display = 'flex';
    document.getElementById('bt-result-section').style.display = 'none';
    document.getElementById('bt-progress-fill').style.width = '0%';
    const _pctReset = document.getElementById('bt-progress-pct');
    if (_pctReset) _pctReset.innerText = '0%';
    document.getElementById('bt-progress-msg').innerText = 'Başlatılıyor...';
    
    try {
        const res = await fetch('/api/backtest/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                symbol, strategy, params, initial_balance: initialBalance,
                interval, start_date: startDate, end_date: null,
                mode: window._btState.mode || 'futures'
            })
        });
        const data = await res.json();
        
        if (data.status !== 'success') {
            window.showToast('❌ Başlatma hatası: ' + (data.message || ''), 'error');
            document.getElementById('bt-form-section').style.display = 'block';
            document.getElementById('bt-progress-section').style.display = 'none';
            return;
        }
        
        window._btState.taskId = data.task_id;
        window._btState.interval = setInterval(() => window._pollBtStatus(), 2000);
    } catch(e) {
        window.showToast('❌ Hata: ' + e.message, 'error');
        document.getElementById('bt-form-section').style.display = 'block';
        document.getElementById('bt-progress-section').style.display = 'none';
    }
};

window._pollBtStatus = async function() {
    const taskId = window._btState.taskId;
    if (!taskId) return;
    
    try {
        const res = await fetch(`/api/backtest/status/${taskId}`);
        const data = await res.json();
        
        if (data.status === 'not_found') {
            clearInterval(window._btState.interval);
            window.showToast('❌ Task bulunamadı', 'error');
            return;
        }
        
        const _pct = data.progress || 0;
        document.getElementById('bt-progress-fill').style.width = _pct + '%';
        const pctEl = document.getElementById('bt-progress-pct');
        if (pctEl) pctEl.innerText = _pct + '%';
        document.getElementById('bt-progress-msg').innerText = data.message || 'Test devam ediyor...';
        
        if (data.status === 'done') {
            clearInterval(window._btState.interval);
            window._btState.interval = null;
            window._loadBtResult(taskId);
        } else if (data.status === 'error') {
            clearInterval(window._btState.interval);
            window._btState.interval = null;
            window.showToast('❌ Backtest hatası: ' + (data.message || ''), 'error', 6000);
            document.getElementById('bt-form-section').style.display = 'block';
            document.getElementById('bt-progress-section').style.display = 'none';
        }
    } catch(e) {
        console.warn('[BT] Poll hata:', e);
    }
};

window._loadBtResult = async function(taskId) {
    try {
        const res = await fetch(`/api/backtest/result/${taskId}`);
        const data = await res.json();
        
        if (data.status !== 'done') {
            window.showToast('❌ Sonuç alınamadı: ' + (data.message || ''), 'error');
            return;
        }
        
        window._btState.currentResult = data.result;
        window._renderBtResult(data.result);
        document.getElementById('bt-progress-section').style.display = 'none';
        document.getElementById('bt-result-section').style.display = 'block';
    } catch(e) {
        window.showToast('❌ Sonuç yükleme hatası: ' + e.message, 'error');
    }
};

window._renderBtResult = function(r) {
    // Metrics
    const pnlEl = document.getElementById('bt-m-pnl');
    const pctEl = document.getElementById('bt-m-pct');
    const ddEl = document.getElementById('bt-m-dd');
    
    document.getElementById('bt-m-trades').innerText = r.total_trades;
    
    const sign = r.total_pnl >= 0 ? '+' : '';
    pnlEl.innerText = sign + r.total_pnl.toFixed(2) + ' USDT';
    pnlEl.style.color = r.total_pnl >= 0 ? '#0ECB81' : '#F6465D';
    
    pctEl.innerText = sign + r.total_pnl_pct.toFixed(2) + '%';
    pctEl.style.color = r.total_pnl_pct >= 0 ? '#0ECB81' : '#F6465D';
    
    document.getElementById('bt-m-wr').innerText = r.win_rate.toFixed(1) + '%';
    
    ddEl.innerText = '-' + r.max_drawdown.toFixed(2) + '%';
    ddEl.style.color = '#F6465D';
    
    document.getElementById('bt-m-final').innerText = r.final_balance.toFixed(2);
    
    // Equity curve (lightweight-charts)
    window._drawBtEquity(r.equity_curve);
    
    // Trades table
    document.getElementById('bt-trades-total').innerText = r.trades_total;
    window._drawBtTrades(r.trades);
};

window._drawBtEquity = function(curve) {
    const container = document.getElementById('bt-equity-chart');
    if (!container) return;
    container.innerHTML = '';
    
    if (!curve || curve.length === 0) return;
    
    const chart = LightweightCharts.createChart(container, {
        width: container.clientWidth,
        height: container.clientHeight,
        layout: { background: { type: 'solid', color: '#131722' }, textColor: '#d1d4dc' },
        grid: { vertLines: { color: '#1e222d' }, horzLines: { color: '#1e222d' } },
        rightPriceScale: { borderColor: '#2a2e39' },
        timeScale: { borderColor: '#2a2e39', timeVisible: true },
        crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
    });
    
    const series = chart.addAreaSeries({
        lineColor: '#2962ff',
        topColor: 'rgba(41, 98, 255, 0.4)',
        bottomColor: 'rgba(41, 98, 255, 0.0)',
        lineWidth: 2,
    });
    
    const data = curve.map(p => ({ time: p.time, value: p.value }));
    series.setData(data);
    chart.timeScale().fitContent();
};

window._drawBtTrades = function(trades) {
    const container = document.getElementById('bt-trades-table');
    if (!trades || trades.length === 0) {
        container.innerHTML = '<div style="text-align:center; color:#848e9c; padding:20px;">İşlem yok</div>';
        return;
    }
    
    let html = '<table class="bt-trades-tbl"><thead><tr>'
        + '<th class="left">#</th>'
        + '<th class="left">Yön</th>'
        + '<th class="left">Giriş</th>'
        + '<th class="left">Çıkış</th>'
        + '<th>Büyüklük</th>'
        + '<th>K/Z %</th>'
        + '<th>K/Z USDT</th>'
        + '<th class="left">Sebep</th>'
        + '<th>DCA</th>'
        + '</tr></thead><tbody>';
    
    trades.forEach((t, i) => {
        const isProfit = t.pnl_amount >= 0;
        const sign = isProfit ? '+' : '';
        const color = isProfit ? '#0ECB81' : '#F6465D';
        
        html += '<tr>'
            + '<td class="left">' + (i + 1) + '</td>'
            + '<td class="left" style="color:' + (t.side === 'BUY' ? '#0ECB81' : '#F6465D') + ';">' + (t.side === 'BUY' ? '▲ LONG' : '▼ SHORT') + '</td>'
            + '<td class="left">' + t.entry_price + '</td>'
            + '<td class="left">' + t.exit_price + '</td>'
            + '<td>' + t.total_vol.toFixed(2) + '</td>'
            + '<td style="color:' + color + '; font-weight:bold;">' + sign + t.pnl_pct.toFixed(2) + '%</td>'
            + '<td style="color:' + color + '; font-weight:bold;">' + sign + t.pnl_amount.toFixed(4) + '</td>'
            + '<td class="left" style="font-size:10px; color:#848e9c;">' + t.reason + '</td>'
            + '<td>' + (t.dca_count > 0 ? t.dca_count : '—') + '</td>'
            + '</tr>';
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
};

window.downloadBtCsv = function() {
    const taskId = window._btState.taskId;
    if (!taskId) return;
    window.open(`/api/backtest/csv/${taskId}`, '_blank');
};

window.resetBacktestForm = function() {
    document.getElementById('bt-form-section').style.display = 'block';
    document.getElementById('bt-progress-section').style.display = 'none';
    document.getElementById('bt-result-section').style.display = 'none';
    window._btState.taskId = null;
    window._btState.currentResult = null;
};
